shader_type canvas_item;
render_mode unshaded;
// Echo look: cyan ghost, horizontal scanline wobble, faint chromatic split and flicker.
// Unshaded so Echoes glow in the dark.

uniform float seed = 0.0;
uniform vec4 tint : source_color = vec4(0.35, 0.95, 1.0, 1.0);

void fragment() {
	float t = TIME * 3.0 + seed;
	vec2 uv = UV;
	float line = floor(UV.y * 32.0);
	uv.x += sin(t * 2.3 + line * 1.7) * 0.004 * step(0.82, fract(sin(line * 12.9898 + floor(t * 4.0)) * 43758.5453));
	vec4 c = texture(TEXTURE, uv);
	float split = texture(TEXTURE, uv + vec2(0.012, 0.0)).a;
	// The echo sheet is already cyan-tinted; keep its shading and push it toward the tint.
	vec3 col = mix(c.rgb, tint.rgb, 0.15) * 1.08;
	float scan = 0.85 + 0.15 * sin(UV.y * 180.0 + t * 6.0);
	float flick = 0.9 + 0.1 * sin(t * 13.0 + seed * 3.0);
	float a = max(c.a, split * 0.35) * scan * flick;
	COLOR = vec4(col, a * COLOR.a);
}
