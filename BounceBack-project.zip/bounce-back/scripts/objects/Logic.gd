class_name Logic
extends LevelObject
## Invisible logic gate: ANY (default) or ALL (`require_all`) of its inputs, forwarded to
## its targets. Used where a door needs "both plates" OR "the inside lever".


func _on_active_changed(on: bool) -> void:
	emit_output(on)
