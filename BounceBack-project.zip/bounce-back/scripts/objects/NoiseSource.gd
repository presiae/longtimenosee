class_name NoiseSource
extends Interactable
## Something to deliberately make a racket with: rattle the cell bars, kick a dumpster.
## Echo-compatible — the classic Echo distraction. `emit_at` moves the sound's origin
## (e.g. to the corridor side of the bars).

var loudness := 1.0
var _cd := 0.0


func _ready() -> void:
	loudness = float(cfg("loudness", 1.0))
	prompt = str(cfg("prompt", "Make noise"))
	echo_compatible = true
	super._ready()


func can_interact(_actor: Node) -> bool:
	return _cd <= 0.0


func _interact(_actor: Node) -> void:
	_cd = 0.8
	var at := global_position
	var e: Variant = cfg("emit_at", null)
	if e is Array:
		at = MapBuilder.cell_feet(Vector2i(int(e[0]), int(e[1])))
	play_sfx(str(cfg("sfx", "bang")))
	var nm := get_node_or_null("/root/NoiseManager")
	if nm:
		nm.emit_noise(at, loudness, self, "bang")
	if level and level.has_method("shake_camera"):
		level.shake_camera(0.18, global_position)


func _physics_process(delta: float) -> void:
	_cd -= delta
