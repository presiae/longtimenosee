class_name Projectile
extends Node2D
## A thrown bottle: flies in an arc toward its target, stops at walls, shatters loudly and
## smashes any lamp it lands under. Echo-thrown bottles make exactly the same noise.

const FLIGHT_TIME := 0.5
const ARC_HEIGHT := 22.0

var start := Vector2.ZERO
var target := Vector2.ZERO
var from_echo := false
var sprite: Sprite2D
var shadow: Sprite2D
var _t := 0.0


func _ready() -> void:
	# Clip the flight at the first wall.
	var q := PhysicsRayQueryParameters2D.create(start, target, 1 | 16)
	var hit := get_world_2d().direct_space_state.intersect_ray(q)
	if not hit.is_empty():
		target = hit.position - (target - start).normalized() * 6.0
	global_position = start
	sprite = SpriteLib.prop_sprite("bottle")
	sprite.offset = Vector2(-6, -6)
	add_child(sprite)
	z_index = 5
	if from_echo:
		sprite.modulate = Color(0.5, 1.0, 1.0, 0.8)


func _physics_process(delta: float) -> void:
	_t += delta
	var k := clampf(_t / FLIGHT_TIME, 0.0, 1.0)
	global_position = start.lerp(target, k)
	sprite.position.y = -sin(k * PI) * ARC_HEIGHT
	sprite.rotation += delta * 14.0
	if k >= 1.0:
		_shatter()


func _shatter() -> void:
	var at := global_position
	for lamp in get_tree().get_nodes_in_group("breakable"):
		if lamp.global_position.distance_to(at) < 30.0:
			lamp.smash()
	var nm := get_node_or_null("/root/NoiseManager")
	if nm:
		nm.emit_noise(at, 1.0, self, "glass")
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.play_at("glass", at)
	var fx := get_node_or_null("/root/Effects")
	if fx:
		fx.burst(at, "glass")
	queue_free()
