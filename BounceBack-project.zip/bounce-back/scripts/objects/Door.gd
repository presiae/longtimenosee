class_name Door
extends Interactable
## Sliding door in a wall gap. Orientation comes from the map: walls left/right of the gap
## make a horizontal door (seen as a face), walls above/below a vertical one (seen from above).
##   mode "switch": opened by linked inputs     mode "key": needs a keycard (player only)
##   mode "manual": [E] opens/closes, Echo-compatible, noisy     mode "locked": never opens
## `hold_time` keeps a switch door open N seconds after its inputs drop (a timed gate).
## Bars doors block movement but not sight, light or sound.

signal opened
signal closed

const T := 32
var mode := "switch"
var key_color := ""
var hold_time := 0.0
var style := "steel"
var vertical := false
var is_open := false
var width_cells := 1
var body: StaticBody2D
var occluder: LightOccluder2D
var sprite: Sprite2D
var status: StatusLamp
var _progress := 0.0
var _target := 0.0
var _hold_t := 0.0
var _pending_close := false


func _ready() -> void:
	mode = str(cfg("mode", "switch"))
	key_color = str(cfg("key", ""))
	hold_time = float(cfg("hold_time", 0.0))
	style = str(cfg("style", key_color if mode == "key" else "steel"))
	width_cells = 3 if style == "gate" else 1
	var m: MapGen = level.map if level else null
	if m and style != "gate":
		# Gap in a vertical wall (passage runs east-west): door seen from above.
		vertical = m.is_floor(cell.x - 1, cell.y) and m.is_floor(cell.x + 1, cell.y) \
			and not m.is_floor(cell.x, cell.y - 1)
	echo_compatible = mode == "manual"
	prompt = "Open" if mode != "key" else "Unlock (%s keycard)" % key_color
	area_size = Vector2(40, 40) if not vertical else Vector2(44, 36)
	area_offset = Vector2.ZERO
	super._ready()
	# Origin = cell centre.
	var size := Vector2(T * width_cells, T)
	var tex_name := "gate" if style == "gate" else ("door_%s_%s" % ["v" if vertical else "h", style])
	sprite = Sprite2D.new()
	sprite.texture = SpriteLib.prop(tex_name)
	sprite.centered = false
	sprite.region_enabled = true
	var th := sprite.texture.get_height()
	sprite.position = Vector2(-size.x * 0.5, T * 0.5 - th)
	add_child(sprite)

	body = StaticBody2D.new()
	body.collision_layer = 128 if style == "bars" else 16
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = size if not vertical else Vector2(12, T)
	cs.shape = r
	body.add_child(cs)
	add_child(body)

	if style != "bars":
		occluder = LightOccluder2D.new()
		var poly := OccluderPolygon2D.new()
		var hw := size.x * 0.5 if not vertical else 6.0
		poly.polygon = PackedVector2Array([Vector2(-hw, -T * 0.5), Vector2(hw, -T * 0.5), Vector2(hw, -T * 0.5 + 6), Vector2(-hw, -T * 0.5 + 6)]) \
			if not vertical else PackedVector2Array([Vector2(-hw, -T * 0.5), Vector2(hw, -T * 0.5), Vector2(hw, T * 0.5), Vector2(-hw, T * 0.5)])
		occluder.occluder = poly
		add_child(occluder)

	if mode in ["switch", "key"]:
		status = StatusLamp.new()
		status.position = Vector2(0, -T * 0.5 + 2)
		add_child(status)
	if bool(cfg("start_open", false)):
		is_open = true
		_target = 1.0
		_progress = 1.0
	_update_visual()


func can_interact(actor: Node) -> bool:
	match mode:
		"manual":
			return not _blocked() or not is_open
		"key":
			return not is_open and actor.is_in_group("player") and _has_key()
	return false


func get_prompt(_actor: Node) -> String:
	if mode == "manual":
		return "Close door" if is_open else "Open door"
	return prompt


func _has_key() -> bool:
	var lm := get_node_or_null("/root/LevelManager")
	return lm != null and lm.has_key(key_color)


func _interact(_actor: Node) -> void:
	match mode:
		"manual":
			set_open(not is_open)
			play_sfx("door_manual", -4.0)
			make_noise(0.5, "door")
		"key":
			set_open(true)
			play_sfx("keycard")


func _on_active_changed(on: bool) -> void:
	if mode != "switch":
		return
	if on:
		_hold_t = 0.0
		set_open(true)
	elif hold_time > 0.0:
		_hold_t = hold_time
	else:
		set_open(false)


func set_open(v: bool) -> void:
	if v == is_open and not _pending_close:
		return
	if not v and _blocked():
		_pending_close = true
		return
	_pending_close = false
	is_open = v
	_target = 1.0 if v else 0.0
	play_sfx("door_open" if v else "door_close", -3.0)
	if v:
		opened.emit()
	else:
		closed.emit()


func _blocked() -> bool:
	var params := PhysicsShapeQueryParameters2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(T * width_cells - 4, T - 4)
	params.shape = r
	params.transform = Transform2D(0.0, global_position)
	params.collision_mask = 2 | 8
	params.collide_with_areas = true
	return not get_world_2d().direct_space_state.intersect_shape(params, 1).is_empty()


func _physics_process(delta: float) -> void:
	if _hold_t > 0.0:
		_hold_t -= delta
		if _hold_t <= 0.0 and not is_active():
			set_open(false)
	if _pending_close:
		set_open(false)
	if not is_equal_approx(_progress, _target):
		_progress = move_toward(_progress, _target, delta * 3.5)
		_update_visual()


func _update_visual() -> void:
	var tw := float(sprite.texture.get_width())
	var th := float(sprite.texture.get_height())
	var shown := roundf(th * (1.0 - _progress * 0.85))
	sprite.region_rect = Rect2(0, th - shown, tw, shown)
	sprite.position.y = T * 0.5 - th
	sprite.modulate.a = 1.0 if _progress < 0.95 else 0.55
	var solid := _progress < 0.6
	body.get_child(0).set_deferred("disabled", not solid)
	if occluder:
		occluder.visible = solid
	if status:
		if hold_time > 0.0 and is_open and _hold_t > 0.0:
			status.set_color(Color(1.0, 0.75, 0.2))
		else:
			status.set_color(Color(0.3, 1.0, 0.45) if is_open else Color(1.0, 0.25, 0.25))


## Tiny glowing indicator (unshaded, so it reads in the dark without costing a light).
class StatusLamp:
	extends Node2D
	var col := Color.RED

	func _ready() -> void:
		var m := CanvasItemMaterial.new()
		m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		material = m
		z_index = 3

	func set_color(c: Color) -> void:
		if c != col:
			col = c
			queue_redraw()

	func _draw() -> void:
		draw_rect(Rect2(-3, -2, 6, 3), Color(0.05, 0.05, 0.08))
		draw_rect(Rect2(-2, -1, 4, 1), col)


func hold_fraction() -> float:
	return clampf(_hold_t / hold_time, 0.0, 1.0) if hold_time > 0.0 else 0.0
