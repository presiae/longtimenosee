class_name Hint
extends LevelObject
## Invisible tutorial trigger: shows its text in the HUD while the player stands in it.

signal shown(text: String)
signal hidden_hint(text: String)

var text := ""


func _ready() -> void:
	text = str(cfg("text", ""))
	var w := float(cfg("w", 3)) * 32.0
	var h := float(cfg("h", 3)) * 32.0
	var a := Area2D.new()
	a.collision_layer = 0
	a.collision_mask = 2
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(w, h)
	cs.shape = r
	# Anchored at the cell's top-left so w/h extend right and down from the cell.
	cs.position = Vector2(w * 0.5 - 16, h * 0.5 - 22)
	a.add_child(cs)
	add_child(a)
	a.body_entered.connect(func(b: Node) -> void:
		if b.is_in_group("player"):
			shown.emit(text))
	a.body_exited.connect(func(b: Node) -> void:
		if b.is_in_group("player"):
			hidden_hint.emit(text))
