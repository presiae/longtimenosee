class_name Vent
extends Interactable
## Vent grate covering a crawlspace entrance. Prying it open is noisy. Echo-compatible,
## so an Echo replaying your escape opens it too.

var is_open := false
var sprite: Sprite2D
var body: StaticBody2D


func _ready() -> void:
	echo_compatible = true
	prompt = "Pry open the vent grate"
	area_size = Vector2(44, 44)
	area_offset = Vector2.ZERO
	super._ready()
	sprite = SpriteLib.prop_sprite("vent", 2)
	sprite.offset.y = -14
	z_index = -12
	add_child(sprite)
	body = StaticBody2D.new()
	body.collision_layer = 16
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(32, 32)
	cs.shape = r
	body.add_child(cs)
	add_child(body)
	if bool(cfg("start_open", false)):
		_set_open(true)


func can_interact(_actor: Node) -> bool:
	return not is_open


func _interact(_actor: Node) -> void:
	_set_open(true)
	play_sfx("vent")
	make_noise(0.35, "vent")


func _set_open(v: bool) -> void:
	is_open = v
	sprite.frame = 1 if v else 0
	body.get_child(0).set_deferred("disabled", v)
