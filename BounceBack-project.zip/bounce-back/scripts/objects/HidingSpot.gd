class_name HidingSpot
extends Interactable
## Locker or bed. Inside, you are invisible to guards and cameras — unless a guard who
## is chasing you saw you get in.

var kind := "locker"
var sprite: Sprite2D
var occupant: Node = null
var body: StaticBody2D


func _ready() -> void:
	kind = str(cfg("kind", "locker"))
	prompt = "Hide"
	area_size = Vector2(34, 34)
	area_offset = Vector2(0, -8)
	super._ready()
	sprite = SpriteLib.prop_sprite(kind, 2)
	add_child(sprite)
	body = StaticBody2D.new()
	body.collision_layer = 1 | 32
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(20, 10) if kind == "locker" else Vector2(20, 34)
	cs.shape = r
	cs.position = Vector2(0, -6) if kind == "locker" else Vector2(0, -20)
	body.add_child(cs)
	add_child(body)


func get_prompt(actor: Node) -> String:
	return "Leave" if occupant == actor else ("Hide under the bed" if kind == "bed" else "Hide in locker")


func can_interact(actor: Node) -> bool:
	return actor.is_in_group("player") and (occupant == null or occupant == actor)


func _interact(actor: Node) -> void:
	if occupant == actor:
		exit_spot()
	else:
		enter_spot(actor)


func enter_spot(actor: Node) -> void:
	occupant = actor
	actor.set_meta("pre_hide_pos", actor.global_position)
	actor.global_position = global_position + Vector2(0, 2)
	actor.velocity = Vector2.ZERO
	actor.is_hidden = true
	actor.hiding_spot = self
	actor.visible = false
	actor.collision_layer = 0
	sprite.frame = 1
	play_sfx("locker" if kind == "locker" else "cloth", -2.0)
	make_noise(0.1, "hide")


func exit_spot() -> void:
	if occupant == null:
		return
	var a := occupant
	a.is_hidden = false
	a.hiding_spot = null
	a.visible = true
	a.collision_layer = 2
	a.global_position = a.get_meta("pre_hide_pos", global_position + Vector2(0, 14))
	occupant = null
	sprite.frame = 0
	play_sfx("locker" if kind == "locker" else "cloth", -6.0)
