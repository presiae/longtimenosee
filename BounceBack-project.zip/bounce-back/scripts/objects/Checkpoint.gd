class_name Checkpoint
extends LevelObject
## A chalk circle on the floor. Stepping in moves your restart point here. Echo
## recordings are tied to where they started, so a NEW checkpoint releases your Echoes.

signal reached(index: int)

var index := 1
var sprite: Sprite2D
var light: PointLight2D
var activated := false


func _ready() -> void:
	index = int(cfg("index", 1))
	z_index = -12
	sprite = SpriteLib.prop_sprite("checkpoint", 2)
	sprite.offset.y = -14
	add_child(sprite)
	light = PointLight2D.new()
	light.texture = SpriteLib.light_texture()
	light.texture_scale = 0.35
	light.color = Color(0.35, 0.95, 1.0)
	light.energy = 0.0
	light.enabled = false
	add_child(light)
	var a := Area2D.new()
	a.collision_layer = 0
	a.collision_mask = 2
	var cs := CollisionShape2D.new()
	var r := CircleShape2D.new()
	r.radius = 16
	cs.shape = r
	a.add_child(cs)
	add_child(a)
	a.body_entered.connect(_on_body)
	var lm := get_node_or_null("/root/LevelManager")
	if lm and lm.checkpoint >= index:
		_set_active(false)


func _on_body(b: Node) -> void:
	if activated or not b.is_in_group("player"):
		return
	_set_active(true)
	reached.emit(index)


func _set_active(fx: bool) -> void:
	activated = true
	sprite.frame = 1
	light.energy = 1.0
	light.enabled = true
	if fx:
		play_sfx("checkpoint")
