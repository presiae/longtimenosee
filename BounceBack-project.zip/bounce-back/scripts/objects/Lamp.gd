class_name Lamp
extends LevelObject
## Ceiling lamp lighting a room. Guards spot you from far away in light; in darkness only
## at close range or in their flashlight. A linked input turns the lamp OFF (power cut);
## a thrown bottle smashes it for the rest of the attempt.

## Wall shadows from every lamp look great but cost GPU time; turn off for weak machines.
const LAMP_SHADOWS := true

var radius := 110.0
var on := true
var broken := false
var flicker := false
var sprite: Sprite2D
var light: PointLight2D
var _flick_t := 0.0
var _base_energy := 1.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	add_to_group("lamps")
	add_to_group("breakable")
	radius = float(cfg("radius", 110.0))
	flicker = bool(cfg("flicker", false))
	on = not bool(cfg("start_off", false))
	_base_energy = float(cfg("energy", 1.0)) * 1.35
	_rng.seed = hash(object_id + str(cell))
	sprite = SpriteLib.prop_sprite("lamp", 3)
	sprite.position = Vector2(0, -12)
	z_index = 20   # ceiling fixture draws above everything
	add_child(sprite)
	light = PointLight2D.new()
	light.texture = SpriteLib.light_texture()
	light.texture_scale = radius * 2.0 / 256.0 * 1.25
	light.color = Color(str(cfg("color", "#ffd890")))
	light.energy = _base_energy
	light.shadow_enabled = LAMP_SHADOWS
	light.shadow_filter = PointLight2D.SHADOW_FILTER_NONE
	light.shadow_color = Color(0, 0, 0, 0.85)
	add_child(light)
	_update()


func _on_active_changed(active: bool) -> void:
	on = not active
	_update()


func smash() -> void:
	if broken:
		return
	broken = true
	play_sfx("glass")
	make_noise(0.6, "glass")
	_update()


func is_lit() -> bool:
	return on and not broken


## 0..1 light at a world point (respecting walls, so light doesn't leak between rooms).
func light_at(p: Vector2) -> float:
	if not is_lit():
		return 0.0
	var d := p.distance_to(global_position)
	if d >= radius:
		return 0.0
	var q := PhysicsRayQueryParameters2D.create(global_position, p, 1 | 16)
	if not get_world_2d().direct_space_state.intersect_ray(q).is_empty():
		return 0.0
	return clampf(1.15 - d / radius, 0.0, 1.0)


func _process(delta: float) -> void:
	if not flicker or not is_lit():
		return
	_flick_t -= delta
	if _flick_t <= 0.0:
		_flick_t = _rng.randf_range(0.05, 0.7)
		var dim := _rng.randf() < 0.22
		light.energy = _base_energy * (0.25 if dim else 1.0)
		sprite.frame = 1 if dim else 0


func _update() -> void:
	light.enabled = is_lit()
	sprite.frame = 2 if broken else (0 if on else 1)
