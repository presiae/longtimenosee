class_name LevelExit
extends LevelObject
## The end of the road. Only the real prisoner can leave.

signal player_exited

var _done := false


func _ready() -> void:
	var a := Area2D.new()
	a.collision_layer = 0
	a.collision_mask = 2
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(40, 110)
	cs.shape = r
	a.add_child(cs)
	add_child(a)
	a.body_entered.connect(_on_body)


func _on_body(b: Node) -> void:
	if _done or not b.is_in_group("player"):
		return
	_done = true
	player_exited.emit()
