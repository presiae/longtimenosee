class_name Prop
extends LevelObject
## Scenery. Bulky props have a solid footprint that blocks movement and line of sight,
## so you can hide behind a crate or a car. Guards path around them.

## art -> footprint size (px) of the solid base; absent = walk-through decoration.
const FOOTPRINTS := {
	"crate": Vector2(26, 14), "barrel": Vector2(18, 10), "table": Vector2(38, 12),
	"desk": Vector2(46, 14), "generator": Vector2(38, 14), "car": Vector2(60, 22),
	"tree": Vector2(10, 8), "toilet": Vector2(16, 10), "sink": Vector2(18, 8),
	"bench": Vector2(38, 8), "hoop": Vector2(6, 6), "sign": Vector2(6, 6), "weights": Vector2(30, 8),
}
## Props that also cast light shadows.
const OCCLUDES := ["crate", "desk", "generator", "car", "tree"]

var sprite: Sprite2D
var footprint := Vector2.ZERO


func _ready() -> void:
	var art := str(cfg("art", "crate"))
	sprite = SpriteLib.prop_sprite(art, int(cfg("frames", 1)))
	sprite.flip_h = bool(cfg("flip", false))
	add_child(sprite)
	if art == "bush":
		sprite.z_index = 1
	if FOOTPRINTS.has(art):
		footprint = FOOTPRINTS[art]
		var body := StaticBody2D.new()
		body.collision_layer = 1 | 32
		var cs := CollisionShape2D.new()
		var r := RectangleShape2D.new()
		r.size = footprint
		cs.shape = r
		cs.position = Vector2(0, -footprint.y * 0.5)
		body.add_child(cs)
		add_child(body)
		if art in OCCLUDES:
			var occ := LightOccluder2D.new()
			var poly := OccluderPolygon2D.new()
			var hw := footprint.x * 0.5
			poly.polygon = PackedVector2Array([Vector2(-hw, -footprint.y), Vector2(hw, -footprint.y), Vector2(hw, 0), Vector2(-hw, 0)])
			occ.occluder = poly
			add_child(occ)
	if int(cfg("frames", 1)) > 1:
		var t := Timer.new()
		t.wait_time = 0.6
		t.autostart = true
		t.timeout.connect(func() -> void: sprite.frame = (sprite.frame + 1) % sprite.hframes)
		add_child(t)


## Grid cells blocked by this prop's footprint (for guard pathfinding).
func blocked_cells() -> Array[Vector2i]:
	var out: Array[Vector2i] = []
	if footprint == Vector2.ZERO or footprint.x < 16:
		return out
	var r := Rect2(global_position - Vector2(footprint.x * 0.5, footprint.y), footprint)
	for y in range(floori(r.position.y / 32), floori(r.end.y / 32) + 1):
		for x in range(floori(r.position.x / 32), floori((r.end.x - 1) / 32) + 1):
			out.append(Vector2i(x, y))
	return out
