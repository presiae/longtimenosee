class_name PressurePlate
extends LevelObject
## Floor plate, active while the player, an Echo or a guard stands on it.

var sprite: Sprite2D
var glow: PointLight2D
var _occupants := {}


func _ready() -> void:
	sprite = SpriteLib.prop_sprite("plate", 2)
	sprite.offset.y = -14
	sprite.position.y = 0
	z_index = -12
	add_child(sprite)
	glow = PointLight2D.new()
	glow.texture = SpriteLib.light_texture()
	glow.texture_scale = 0.18
	glow.color = Color(0.35, 0.95, 1.0)
	glow.energy = 0.0
	glow.enabled = false
	add_child(glow)
	var a := Area2D.new()
	a.collision_layer = 0
	a.collision_mask = 2 | 4 | 8
	a.monitorable = false
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(22, 22)
	cs.shape = r
	a.add_child(cs)
	add_child(a)
	a.body_entered.connect(_enter)
	a.body_exited.connect(_exit)
	a.area_entered.connect(_enter)
	a.area_exited.connect(_exit)


func _enter(n: Node) -> void:
	var was := not _occupants.is_empty()
	_occupants[n.get_instance_id()] = true
	if not was:
		sprite.frame = 1
		glow.energy = 1.2
		glow.enabled = true
		emit_output(true)
		play_sfx("plate", -4.0)


func _exit(n: Node) -> void:
	_occupants.erase(n.get_instance_id())
	if _occupants.is_empty():
		sprite.frame = 0
		glow.energy = 0.0
		glow.enabled = false
		emit_output(false)


func is_pressed() -> bool:
	return not _occupants.is_empty()
