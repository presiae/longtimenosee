class_name Pickup
extends Interactable
## Collectable item. Echoes can never collect anything.
##   keycard (key colour) — persists for the run   note — optional lore, saved
##   shard — +1 Echo capacity, saved              bottle — throwable, respawns each attempt

const KEY_COLORS := {"red": Color(1.0, 0.4, 0.4), "blue": Color(0.4, 0.85, 1.0), "yellow": Color(1.0, 0.85, 0.35)}

var kind := "bottle"
var sprite: Sprite2D
var light: PointLight2D
var _t := 0.0


func _ready() -> void:
	kind = str(cfg("kind", "bottle"))
	prompt = {"keycard": "Take the keycard", "note": "Read the note", "shard": "Take the Echo shard",
		"bottle": "Pick up the bottle"}.get(kind, "Pick up")
	area_size = Vector2(30, 30)
	area_offset = Vector2(0, -6)
	super._ready()
	sprite = SpriteLib.prop_sprite(kind)
	sprite.position.y = -2
	add_child(sprite)
	if kind == "keycard":
		sprite.modulate = KEY_COLORS.get(str(cfg("key", "red")), Color.WHITE)
	if kind != "bottle":
		light = PointLight2D.new()
		light.texture = SpriteLib.light_texture()
		light.texture_scale = 0.3
		light.energy = 0.9
		light.color = Color(0.4, 0.95, 1.0) if kind == "shard" else (sprite.modulate if kind == "keycard" else Color(1, 0.9, 0.6))
		light.position = Vector2(0, -8)
		add_child(light)
		# Collectibles glow through the darkness so they can be found.
		var mat := CanvasItemMaterial.new()
		mat.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		sprite.material = mat


func _process(delta: float) -> void:
	_t += delta
	if kind != "bottle":
		sprite.position.y = -3 + roundf(sin(_t * 3.0) * 1.5)


func can_interact(actor: Node) -> bool:
	if not actor.is_in_group("player"):
		return false
	return kind != "bottle" or actor.held_item == ""


func _interact(actor: Node) -> void:
	var lm := get_node_or_null("/root/LevelManager")
	match kind:
		"bottle":
			actor.held_item = "bottle"
			play_sfx("bottle", -4.0)
		"keycard":
			if lm:
				lm.collect(object_id, {"key": str(cfg("key", "red"))})
			play_sfx("pickup")
		"note":
			if lm:
				lm.collect(object_id, {"note": object_id, "title": str(cfg("title", "Note")), "text": str(cfg("text", ""))})
			play_sfx("paper")
		"shard":
			if lm:
				lm.collect(object_id, {"shard": true})
			play_sfx("shard")
	queue_free()
