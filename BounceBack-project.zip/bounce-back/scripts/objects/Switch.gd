class_name Switch
extends Interactable
## Lever or electrical breaker panel; emits output_changed to linked targets.
##   mode "toggle" (default) or "pulse" (on for `pulse` seconds, then springs back).
## Echo-compatible unless the map sets "echo": false.

var kind := "lever"
var mode := "toggle"
var pulse := 3.0
var on := false
var sprite: Sprite2D
var _pulse_t := 0.0


func _ready() -> void:
	kind = str(cfg("kind", "lever"))
	mode = str(cfg("mode", "toggle"))
	pulse = float(cfg("pulse", 3.0))
	echo_compatible = bool(cfg("echo", true))
	prompt = "Pull lever" if kind == "lever" else "Flip breaker"
	super._ready()
	sprite = SpriteLib.prop_sprite("lever" if kind == "lever" else "panel", 2)
	add_child(sprite)
	if bool(cfg("start_on", false)):
		on = true
		call_deferred("emit_output", true)
	_update()


func get_prompt(_actor: Node) -> String:
	if mode == "pulse":
		return prompt
	return prompt + (" (off)" if on else "")


func _interact(_actor: Node) -> void:
	if mode == "pulse":
		var was := on
		on = true
		_pulse_t = pulse
		if not was:
			emit_output(true)
	else:
		on = not on
		emit_output(on)
	play_sfx("lever" if kind == "lever" else "switch")
	make_noise(0.22, "switch")
	_update()


func _physics_process(delta: float) -> void:
	if _pulse_t > 0.0:
		_pulse_t -= delta
		if _pulse_t <= 0.0:
			on = false
			emit_output(false)
			play_sfx("switch", -8.0)
			_update()


func _update() -> void:
	sprite.frame = 1 if on else 0


func pulse_fraction() -> float:
	return clampf(_pulse_t / pulse, 0.0, 1.0) if mode == "pulse" else 0.0
