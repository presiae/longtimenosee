extends Node
## Run state that survives attempts: checkpoint, keycards, collectibles, Echo capacity.
## The whole prison is one map; checkpoints split it into zones.

signal checkpoint_reached(index: int)
signal item_collected(id: String, data: Dictionary)

const GAME_SCENE := "res://scenes/Game.tscn"
const ENDING_SCENE := "res://scenes/menus/Ending.tscn"
const BASE_ECHO_CAPACITY := 1
const MAX_ECHO_CAPACITY := 3

var checkpoint := 0
var keys: Array[String] = []
var run_collected := {}        # keycards etc. for this run
var collected_global := {}     # notes and shards (saved)
var attempts_total := 0


func new_game() -> void:
	checkpoint = 0
	keys.clear()
	run_collected.clear()
	collected_global.clear()
	attempts_total = 0


func start_game() -> void:
	get_tree().change_scene_to_file(GAME_SCENE)


func echo_capacity() -> int:
	var shards := 0
	for d: Dictionary in collected_global.values():
		if d.has("shard"):
			shards += 1
	return mini(BASE_ECHO_CAPACITY + shards, MAX_ECHO_CAPACITY)


func has_key(color: String) -> bool:
	return color in keys


func is_collected(id: String) -> bool:
	return run_collected.has(id) or collected_global.has(id)


func collect(id: String, data: Dictionary) -> void:
	run_collected[id] = data
	if data.has("key"):
		keys.append(str(data.key))
	if data.has("note") or data.has("shard"):
		collected_global[id] = data
	item_collected.emit(id, data)
	_save()


func notes() -> Array:
	var out := []
	for d: Dictionary in collected_global.values():
		if d.has("note"):
			out.append(d)
	return out


func reach_checkpoint(index: int) -> void:
	if index <= checkpoint:
		return
	checkpoint = index
	checkpoint_reached.emit(index)
	_save()


func finish_game() -> void:
	var sm := get_node_or_null("/root/SaveManager")
	if sm:
		sm.mark_finished()
	get_tree().change_scene_to_file(ENDING_SCENE)


func _save() -> void:
	var sm := get_node_or_null("/root/SaveManager")
	if sm:
		sm.save_progress()


## Serialisation for SaveManager.
func to_dict() -> Dictionary:
	return {"checkpoint": checkpoint, "keys": keys.duplicate(), "run_collected": run_collected.duplicate(true),
		"collected_global": collected_global.duplicate(true), "attempts_total": attempts_total}


func from_dict(d: Dictionary) -> void:
	checkpoint = int(d.get("checkpoint", 0))
	keys.clear()
	for k in d.get("keys", []):
		keys.append(str(k))
	run_collected = d.get("run_collected", {})
	collected_global = d.get("collected_global", {})
	attempts_total = int(d.get("attempts_total", 0))
