extends Node
## Sound effects, positional audio, zone ambience and adaptive music.
##
## Buses: Master > Music, SFX, Ambience, Echo (Echo is routed into SFX through reverb,
## chorus and a low-pass, so everything an Echo does sounds distant and smeared).
## Music: three synced layers (calm / tension / chase). Their mix follows the most alert
## guard, alarms, and rises for the final escape.

const SFX := {
	"step": "res://assets/audio/sfx/step.wav", "step2": "res://assets/audio/sfx/step2.wav",
	"step_run": "res://assets/audio/sfx/step_run.wav",
	"door_open": "res://assets/audio/sfx/door_open.wav", "door_close": "res://assets/audio/sfx/door_close.wav",
	"glass": "res://assets/audio/sfx/glass.wav", "bang": "res://assets/audio/sfx/bang.wav",
	"alarm": "res://assets/audio/sfx/alarm.wav", "alert": "res://assets/audio/sfx/alert.wav",
	"huh": "res://assets/audio/sfx/huh.wav", "echo_spawn": "res://assets/audio/sfx/echo_spawn.wav",
	"checkpoint": "res://assets/audio/sfx/checkpoint.wav", "shard": "res://assets/audio/sfx/shard.wav",
	"power_down": "res://assets/audio/sfx/power_down.wav", "power_up": "res://assets/audio/sfx/power_up.wav",
	"plate": "res://assets/audio/sfx/plate.wav", "keycard": "res://assets/audio/sfx/keycard.wav",
	"vent": "res://assets/audio/sfx/vent.wav", "paper": "res://assets/audio/sfx/paper.wav",
	"caught": "res://assets/audio/sfx/caught.wav", "bounce": "res://assets/audio/sfx/bounce.wav",
	"switch": "res://assets/audio/sfx/switch.wav",
	"bars": "res://assets/audio/oga/bars.wav", "lever": "res://assets/audio/oga/lever.wav",
	"locker": "res://assets/audio/oga/locker.wav", "cloth": "res://assets/audio/oga/cloth.wav",
	"door_manual": "res://assets/audio/oga/door_manual.wav", "pickup": "res://assets/audio/oga/pickup.wav",
	"bottle": "res://assets/audio/oga/bottle.wav", "metal": "res://assets/audio/oga/metal_small.wav",
	"ui_move": "res://assets/audio/oga/ui1.wav", "ui_accept": "res://assets/audio/oga/ui2.wav",
	"ui_back": "res://assets/audio/oga/ui3.wav",
}
## Per-sound base volume trims (dB).
const TRIM := {"alarm": -10.0, "step": -14.0, "step2": -14.0, "step_run": -9.0, "bars": -2.0,
	"echo_spawn": -4.0, "door_open": -6.0, "door_close": -6.0, "huh": -6.0, "lever": -4.0}
const AMBIENCE := {
	"amb_cell": "res://assets/audio/ambient/amb_cell.wav", "amb_block": "res://assets/audio/ambient/amb_block.wav",
	"amb_security": "res://assets/audio/ambient/amb_security.wav", "amb_yard": "res://assets/audio/ambient/amb_yard.wav",
	"amb_outside": "res://assets/audio/ambient/amb_outside.wav",
}
const LAYERS := ["res://assets/audio/music/layer_calm.wav", "res://assets/audio/music/layer_tension.wav",
	"res://assets/audio/music/layer_chase.wav"]

## Set while an Echo is the one interacting, so object sounds go to the Echo bus.
var echo_context := false
var base_intensity := 0.0
var _intensity := 0.0
var _bump := 0.0
var _cache := {}
var _music: Array[AudioStreamPlayer] = []
var _amb_a: AudioStreamPlayer
var _amb_b: AudioStreamPlayer
var _amb_name := ""
var _music_on := false


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_setup_buses()
	for path in LAYERS:
		var p := AudioStreamPlayer.new()
		p.stream = _looped(path)
		p.bus = "Music"
		p.volume_db = -80.0
		add_child(p)
		_music.append(p)
	_amb_a = AudioStreamPlayer.new()
	_amb_b = AudioStreamPlayer.new()
	for a in [_amb_a, _amb_b]:
		a.bus = "Ambience"
		a.volume_db = -80.0
		add_child(a)


func _setup_buses() -> void:
	for b in ["Music", "SFX", "Ambience", "Echo"]:
		if AudioServer.get_bus_index(b) == -1:
			AudioServer.add_bus()
			var i := AudioServer.bus_count - 1
			AudioServer.set_bus_name(i, b)
			AudioServer.set_bus_send(i, "Master")
	var echo := AudioServer.get_bus_index("Echo")
	AudioServer.set_bus_send(echo, "SFX")
	if AudioServer.get_bus_effect_count(echo) == 0:
		var rev := AudioEffectReverb.new()
		rev.room_size = 0.85
		rev.wet = 0.55
		rev.dry = 0.6
		AudioServer.add_bus_effect(echo, rev)
		var ch := AudioEffectChorus.new()
		AudioServer.add_bus_effect(echo, ch)
		var lp := AudioEffectLowPassFilter.new()
		lp.cutoff_hz = 2600.0
		AudioServer.add_bus_effect(echo, lp)
	AudioServer.set_bus_volume_db(AudioServer.get_bus_index("Ambience"), -6.0)


func _looped(path: String) -> AudioStream:
	var s: AudioStreamWAV = load(path)
	if s:
		s = s.duplicate()
		s.loop_mode = AudioStreamWAV.LOOP_FORWARD
		s.loop_begin = 0
		s.loop_end = s.data.size() / 2
	return s


func _stream(name: String) -> AudioStream:
	if not _cache.has(name):
		_cache[name] = load(SFX[name]) if SFX.has(name) else null
	return _cache[name]


func _world() -> Node:
	var scene := get_tree().current_scene
	return scene.world if scene and scene.get("world") else null


## Positional one-shot in the current world.
func play_at(name: String, pos: Vector2, volume_db := 0.0, echo := false) -> void:
	var s := _stream(name)
	var w := _world()
	if s == null:
		return
	if w == null:
		play_ui(name, volume_db)
		return
	var p := AudioStreamPlayer2D.new()
	p.stream = s
	p.position = pos
	p.volume_db = volume_db + float(TRIM.get(name, 0.0))
	p.bus = "Echo" if (echo or echo_context) else "SFX"
	p.max_distance = 900.0
	p.attenuation = 1.6
	p.pitch_scale = randf_range(0.94, 1.06) if name.begins_with("step") else 1.0
	if p.bus == "Echo":
		p.pitch_scale *= 0.92
	w.add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


## Non-positional (UI, stingers).
func play_ui(name: String, volume_db := 0.0) -> void:
	var s := _stream(name)
	if s == null:
		return
	var p := AudioStreamPlayer.new()
	p.stream = s
	p.volume_db = volume_db + float(TRIM.get(name, 0.0))
	p.bus = "SFX"
	add_child(p)
	p.play()
	p.finished.connect(p.queue_free)


# ------------------------------------------------------------------ music
func start_music() -> void:
	if _music_on:
		return
	_music_on = true
	for p in _music:
		p.play()


func stop_music() -> void:
	_music_on = false
	for p in _music:
		p.stop()


func bump_intensity(v: float) -> void:
	_bump = maxf(_bump, v)


func _process(delta: float) -> void:
	if not _music_on:
		return
	var target := base_intensity
	for g in get_tree().get_nodes_in_group("guards"):
		var s: int = g.fsm.state
		if s == GuardStateMachine.S.CHASE:
			target = 1.0
			break
		elif s in [GuardStateMachine.S.SUSPICIOUS, GuardStateMachine.S.INVESTIGATE, GuardStateMachine.S.SEARCH]:
			target = maxf(target, 0.55)
	_bump = maxf(0.0, _bump - delta * 0.15)
	target = maxf(target, _bump)
	_intensity = move_toward(_intensity, target, delta * (1.5 if target > _intensity else 0.35))
	var vols := [
		-8.0 - _intensity * 6.0,
		lerpf(-60.0, -6.0, clampf((_intensity - 0.2) / 0.4, 0.0, 1.0)),
		lerpf(-60.0, -4.0, clampf((_intensity - 0.75) / 0.25, 0.0, 1.0)),
	]
	for i in 3:
		_music[i].volume_db = vols[i]


# ------------------------------------------------------------------ ambience
func set_ambience(name: String) -> void:
	if name == _amb_name or not AMBIENCE.has(name):
		return
	_amb_name = name
	var incoming := _amb_b if _amb_a.playing and _amb_a.volume_db > -40.0 else _amb_a
	var outgoing := _amb_a if incoming == _amb_b else _amb_b
	incoming.stream = _looped(AMBIENCE[name])
	incoming.volume_db = -50.0
	incoming.play()
	var tw := create_tween()
	tw.tween_property(incoming, "volume_db", 0.0, 2.0)
	tw.parallel().tween_property(outgoing, "volume_db", -60.0, 2.0)
	tw.tween_callback(outgoing.stop)


func stop_ambience() -> void:
	_amb_name = ""
	for a in [_amb_a, _amb_b]:
		create_tween().tween_property(a, "volume_db", -60.0, 1.0)
