extends Node
## Registers every input action in code so the bindings live in one readable place
## (and the controls screen can list them from the same table).

const BINDINGS := {
	"move_left": [KEY_A, KEY_LEFT],
	"move_right": [KEY_D, KEY_RIGHT],
	"move_up": [KEY_W, KEY_UP],
	"move_down": [KEY_S, KEY_DOWN],
	"run": [KEY_SHIFT],
	"crouch": [KEY_CTRL, KEY_C],
	"interact": [KEY_E],
	"throw": [KEY_Q],
	"restart": [KEY_R],
	"clear_echoes": [KEY_X],
	"pause": [KEY_ESCAPE],
	"debug_echo": [KEY_F3],
	"toggle_light": [KEY_L],
	"ui_accept_alt": [KEY_ENTER],
}

## Human-readable descriptions used by the controls screen.
const DESCRIPTIONS := [
	["WASD / Arrows", "Move"],
	["Shift", "Run (fast but loud)"],
	["Ctrl / C", "Sneak (silent, harder to spot)"],
	["E", "Interact / hide / pick up"],
	["Q", "Throw held object"],
	["R", "Bounce back (restart attempt, leaves an Echo)"],
	["X", "Dissolve all Echoes"],
	["Esc", "Pause"],
	["L", "Toggle lighting"],
	["F3", "Echo debug overlay"],
]


func _ready() -> void:
	for action: String in BINDINGS:
		if not InputMap.has_action(action):
			InputMap.add_action(action, 0.2)
		for key: int in BINDINGS[action]:
			var ev := InputEventKey.new()
			ev.physical_keycode = key
			InputMap.action_add_event(action, ev)
	# Gamepad support for the essentials.
	_add_joy("interact", JOY_BUTTON_X)
	_add_joy("run", JOY_BUTTON_RIGHT_SHOULDER)
	_add_joy("crouch", JOY_BUTTON_B)
	_add_joy("throw", JOY_BUTTON_Y)
	_add_joy("restart", JOY_BUTTON_BACK)
	_add_joy("pause", JOY_BUTTON_START)
	_add_axis("move_left", JOY_AXIS_LEFT_X, -1.0)
	_add_axis("move_right", JOY_AXIS_LEFT_X, 1.0)
	_add_axis("move_up", JOY_AXIS_LEFT_Y, -1.0)
	_add_axis("move_down", JOY_AXIS_LEFT_Y, 1.0)
	_add_joy("interact", JOY_BUTTON_A)


func _add_joy(action: String, button: JoyButton) -> void:
	var ev := InputEventJoypadButton.new()
	ev.button_index = button
	InputMap.action_add_event(action, ev)


func _add_axis(action: String, axis: JoyAxis, value: float) -> void:
	var ev := InputEventJoypadMotion.new()
	ev.axis = axis
	ev.axis_value = value
	InputMap.action_add_event(action, ev)
