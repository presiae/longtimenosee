extends Node
## Small visual effects: sound rings (so you can SEE how far a noise carries), glass
## shards, dust puffs and the Echo arrival ripple. Effects are spawned into the current
## World's entity layer and clean themselves up.

func _ready() -> void:
	NoiseManager.noise_emitted.connect(_on_noise)


func _world() -> Node:
	var scene := get_tree().current_scene
	if scene and scene.get("world"):
		return scene.world
	return null


func _on_noise(pos: Vector2, loudness: float, radius: float, source: Node, kind: String) -> void:
	if loudness < 0.3 or kind == "shout":
		return
	var echo := source != null and is_instance_valid(source) and source.is_in_group("echo")
	ring(pos, radius, Color(0.35, 0.95, 1.0) if echo else Color(1.0, 0.85, 0.45))


func ring(pos: Vector2, radius: float, col: Color) -> void:
	var w := _world()
	if w == null:
		return
	var r := Ring.new()
	r.position = pos
	r.max_r = radius
	r.col = col
	w.add_child(r)


func burst(pos: Vector2, kind: String) -> void:
	var w := _world()
	if w == null:
		return
	var p := CPUParticles2D.new()
	p.position = pos
	p.one_shot = true
	p.emitting = true
	p.amount = 14 if kind == "glass" else 8
	p.lifetime = 0.6
	p.explosiveness = 1.0
	p.spread = 180.0
	p.direction = Vector2.UP
	p.initial_velocity_min = 40.0
	p.initial_velocity_max = 110.0
	p.gravity = Vector2(0, 260)
	p.scale_amount_min = 1.0
	p.scale_amount_max = 2.0
	p.color = Color(0.6, 1.0, 0.75) if kind == "glass" else Color(0.6, 0.6, 0.65, 0.6)
	p.z_index = 6
	w.add_child(p)
	get_tree().create_timer(1.2).timeout.connect(p.queue_free)


## Expanding circle showing a sound's reach.
class Ring:
	extends Node2D
	var max_r := 100.0
	var col := Color.WHITE
	var t := 0.0

	func _ready() -> void:
		var m := CanvasItemMaterial.new()
		m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		material = m
		z_index = 4

	func _process(d: float) -> void:
		t += d / 0.7
		if t >= 1.0:
			queue_free()
			return
		queue_redraw()

	func _draw() -> void:
		var r := max_r * ease(t, 0.4)
		draw_arc(Vector2.ZERO, r, 0, TAU, 56, Color(col, 0.45 * (1.0 - t)), 1.5)
