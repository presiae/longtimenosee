extends Node
## Owns the list of Echo recordings across attempts.
##  - Every attempt is recorded. When it ends (caught or [R]), the recording becomes an Echo.
##  - Capacity starts at 1 and grows with Echo shards; when full, the oldest Echo is dropped.
##  - Reaching a new checkpoint releases all Echoes (they started somewhere else).
##  - [X] dissolves every Echo.

signal echoes_changed
signal echo_spawned(echo: Node)

const MIN_FRAMES := 30

var recordings: Array[EchoRecording] = []
var recorder: EchoRecorder
var active: Array[Node] = []
var recording_frames := 0
var debug_visible := false


func _process(_d: float) -> void:
	recording_frames = recorder.recording.frame_count() if is_instance_valid(recorder) else 0


func capacity() -> int:
	var lm := get_node_or_null("/root/LevelManager")
	return lm.echo_capacity() if lm else 1


## Called by Game when a new attempt begins.
func begin_attempt(world: Node, attempt: int, checkpoint: int) -> void:
	active.clear()
	recorder = EchoRecorder.new()
	recorder.name = "EchoRecorder"
	world.add_child(recorder)
	recorder.attach(world.player, checkpoint, attempt)
	var i := 0
	for rec in recordings:
		if rec.start_checkpoint != checkpoint:
			continue
		var e := Echo.new()
		e.name = "Echo%d" % i
		e.setup(rec, world, i)
		world.entities.add_child(e)
		e.finished.connect(func(x: Node) -> void: active.erase(x))
		active.append(e)
		echo_spawned.emit(e)
		i += 1
	if i > 0:
		var am := get_node_or_null("/root/AudioManager")
		if am:
			am.play_ui("echo_spawn")


## Called by Game when an attempt ends; the attempt becomes an Echo.
func end_attempt(_reason: String) -> void:
	if not is_instance_valid(recorder):
		return
	recorder.active = false
	var rec := recorder.recording
	if rec.frame_count() >= MIN_FRAMES:
		recordings.append(rec)
		while recordings.size() > capacity():
			recordings.pop_front()
	echoes_changed.emit()


## Checkpoints change the start point, so old recordings no longer line up.
func on_checkpoint(index: int) -> void:
	recordings.clear()
	if is_instance_valid(recorder):
		recorder.restart(index)
	for e in active:
		if is_instance_valid(e):
			e.dissolve("released at checkpoint")
	echoes_changed.emit()


func clear_all() -> void:
	recordings.clear()
	for e in active:
		if is_instance_valid(e):
			e.dissolve("dissolved by player")
	echoes_changed.emit()


func reset() -> void:
	recordings.clear()
	active.clear()


func _ready() -> void:
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.checkpoint_reached.connect(on_checkpoint)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("clear_echoes"):
		clear_all()
	elif event.is_action_pressed("debug_echo"):
		debug_visible = not debug_visible
