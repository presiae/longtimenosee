extends Node
## Global noise bus. Anything that makes a sound calls emit_noise(); every guard in the
## "listeners" group decides whether it heard it. Walls halve the reach of a sound.
##
## Loudness guide (radius = loudness * BASE_RADIUS):
##   sneak 0 · walk 0.16 · run 0.42 · lever 0.22 · door 0.5 · vent 0.35 · glass/bang 1.0

signal noise_emitted(pos: Vector2, loudness: float, radius: float, source: Node, kind: String)

const BASE_RADIUS := 320.0
const WALL_MUFFLE := 0.5

## Optional debug log of recent noises (F3 overlay).
var recent: Array = []


func radius_for(loudness: float) -> float:
	return loudness * BASE_RADIUS


func emit_noise(pos: Vector2, loudness: float, source: Node = null, kind := "") -> void:
	if loudness <= 0.0:
		return
	var r := radius_for(loudness)
	noise_emitted.emit(pos, loudness, r, source, kind)
	recent.append({"pos": pos, "r": r, "kind": kind, "t": Time.get_ticks_msec()})
	if recent.size() > 12:
		recent.pop_front()
	for l in get_tree().get_nodes_in_group("listeners"):
		if l == source or not is_instance_valid(l):
			continue
		var d := pos.distance_to(l.global_position)
		if d > r:
			continue
		var eff := r
		if _blocked(l, pos, l.global_position + Vector2(0, -8)):
			eff = r * WALL_MUFFLE
		if d <= eff:
			l.hear(pos, loudness, source, kind)


func _blocked(node: Node2D, a: Vector2, b: Vector2) -> bool:
	var q := PhysicsRayQueryParameters2D.create(a + Vector2(0, -6), b, 1 | 16)
	return not node.get_world_2d().direct_space_state.intersect_ray(q).is_empty()
