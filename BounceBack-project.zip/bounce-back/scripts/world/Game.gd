class_name Game
extends Node
## Owns the current World and the HUD. Every attempt rebuilds the World so each run starts
## from an identical, deterministic state — the foundation of Echo replays.

signal attempt_started(attempt: int)
signal attempt_ended(reason: String)

var world: World
var hud: Node
var attempt := 0
var _restarting := false


var pause_menu: PauseMenu
var story_seen := {}


func _ready() -> void:
	hud = preload("res://scenes/ui/HUD.tscn").instantiate()
	add_child(hud)
	pause_menu = PauseMenu.new()
	pause_menu.game = self
	add_child(pause_menu)
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.checkpoint_reached.connect(_on_checkpoint_story)
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.start_music()
	start_attempt()
	if lm and lm.checkpoint == 0 and lm.attempts_total <= 1:
		hud.fade_in_from_black(2.0)


func start_attempt() -> void:
	attempt += 1
	if world:
		world.queue_free()
		remove_child(world)
	world = World.new()
	world.name = "World"
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		world.start_checkpoint = lm.checkpoint
	add_child(world)
	move_child(world, 0)
	world.exited.connect(_on_exited)
	world.player_caught.connect(_on_caught)
	for o in world.objects.values():
		if o is Hint:
			o.shown.connect(func(t: String) -> void: hud.show_hint(t))
			o.hidden_hint.connect(func(t: String) -> void: hud.hide_hint(t))
	hud.bind_world(world, self)
	var em := get_node_or_null("/root/EchoManager")
	if em:
		em.begin_attempt(world, attempt, world.start_checkpoint)
	var dbg := EchoDebug.new()
	dbg.world = world
	world.add_child(dbg)
	if lm:
		lm.attempts_total += 1
	_restarting = false
	attempt_started.emit(attempt)


func restart_attempt(reason := "restart") -> void:
	if _restarting:
		return
	_restarting = true
	attempt_ended.emit(reason)
	var em := get_node_or_null("/root/EchoManager")
	if em:
		em.end_attempt(reason)
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.play_ui("bounce", -6.0)
	start_attempt()
	_story_after_attempt(reason)


func _on_caught(reason: String) -> void:
	if _restarting:
		return
	_restarting = true
	var em := get_node_or_null("/root/EchoManager")
	if em and is_instance_valid(em.recorder):
		em.recorder.active = false   # the Echo ends where you were caught
	world.player.set_caught()
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.play_ui("caught", -2.0)
	hud.flash_caught(reason)
	world.shake_camera(0.5)
	await get_tree().create_timer(1.3).timeout
	_restarting = false
	restart_attempt("caught")


## Story beats from the brief: the first capture introduces the Echo; escaping the first
## room shows the title card.
func _story_after_attempt(reason: String) -> void:
	var lm := get_node_or_null("/root/LevelManager")
	if lm == null or lm.checkpoint != 0:
		return
	if reason == "caught" and not story_seen.has("echo"):
		story_seen["echo"] = true
		hud.story_card("BUT SOMETHING FOLLOWED ME BACK.", "That glow is you - your last attempt, repeating every move.\nMake it rattle the bars, then press R to bounce back.", 6.0)
	elif not story_seen.has("echo_hint") and EchoManager.recordings.size() > 0:
		story_seen["echo_hint"] = true
		hud.show_hint("Your Echo repeats your last attempt exactly. Use it as a distraction.")


func _on_checkpoint_story(index: int) -> void:
	if index == 1 and not story_seen.has("title"):
		story_seen["title"] = true
		hud.title_card("BOUNCE BACK", "EVERY FAILURE LEAVES SOMETHING BEHIND.")


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("restart") and not _restarting:
		restart_attempt("restart")


func _on_exited() -> void:
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.finish_game()
