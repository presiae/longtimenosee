class_name MapBuilder
extends RefCounted
## Turns a MapGen grid into TileMapLayers.
##  - Floor layer: floors and ground (no collision).
##  - Wall layer: every solid cell. A wall whose southern neighbour is open floor shows its
##    FACE (the 3/4 look); every other solid cell shows the dark wall TOP.
##  - Collision on wall cells, LightOccluder2D polygons so lights cast wall shadows.
##    Faces only occlude along their top lip, so a room's light still falls on its own walls.
##    Fences collide but don't occlude (you can see through them).

const TILESET_PATH := "res://assets/tilesets/td_tiles.png"
const T := 32
const FLOOR_ATLAS := [
	Vector2i(0, 0), Vector2i(1, 0), Vector2i(2, 0), Vector2i(3, 0), Vector2i(4, 0), Vector2i(5, 0),
	Vector2i(6, 0), Vector2i(7, 0), Vector2i(0, 1), Vector2i(1, 1), Vector2i(2, 1), Vector2i(3, 1),
	Vector2i(4, 1), Vector2i(5, 1), Vector2i(6, 1), Vector2i(7, 1),
]

static var _tileset: TileSet


static func tileset() -> TileSet:
	if _tileset:
		return _tileset
	var ts := TileSet.new()
	ts.tile_size = Vector2i(T, T)
	ts.add_physics_layer()
	ts.set_physics_layer_collision_layer(0, 1)   # "world"
	ts.set_physics_layer_collision_mask(0, 0)
	ts.add_occlusion_layer()
	var src := TileSetAtlasSource.new()
	src.texture = load(TILESET_PATH)
	src.texture_region_size = Vector2i(T, T)
	ts.add_source(src, 0)
	var h := T * 0.5
	var full := PackedVector2Array([Vector2(-h, -h), Vector2(h, -h), Vector2(h, h), Vector2(-h, h)])
	var lip := PackedVector2Array([Vector2(-h, -h), Vector2(h, -h), Vector2(h, -h + 6), Vector2(-h, -h + 6)])
	for y in 8:
		for x in 8:
			var c := Vector2i(x, y)
			src.create_tile(c)
			var td := src.get_tile_data(c, 0)
			if y >= 2 and y <= 5:
				td.add_collision_polygon(0)
				td.set_collision_polygon_points(0, 0, full)
				if y <= 4:
					var occ := OccluderPolygon2D.new()
					occ.polygon = full if x == 0 else lip
					td.set_occluder(0, occ)
	_tileset = ts
	return ts


## Returns {floor: TileMapLayer, walls: TileMapLayer, edges: Node2D}
static func build(m: MapGen) -> Dictionary:
	var ts := tileset()
	var fl := TileMapLayer.new()
	fl.name = "Floor"
	fl.tile_set = ts
	fl.collision_enabled = false
	fl.occlusion_enabled = false
	fl.z_index = -20
	var wl := TileMapLayer.new()
	wl.name = "Walls"
	wl.tile_set = ts
	wl.z_index = -15
	var rng := RandomNumberGenerator.new()
	rng.seed = 77
	for y in m.h:
		for x in m.w:
			var f := m.floor_mat[m.idx(x, y)]
			if f != MapGen.SOLID:
				fl.set_cell(Vector2i(x, y), 0, FLOOR_ATLAS[f])
				continue
			if not _near_floor(m, x, y, 3):
				continue
			var row := m.wall_mat[m.idx(x, y)]
			var col := 0
			if m.is_floor(x, y + 1):
				col = 1
				var r := rng.randf()
				if r < 0.12:
					col = 2
				elif r < 0.2:
					col = 3
			if row == MapGen.W.FENCE:
				if not m.is_wall(x, y):
					continue
				col = 0
			elif not m.is_wall(x, y):
				col = 0
			wl.set_cell(Vector2i(x, y), 0, Vector2i(col, row))
	var edges := WallEdges.new()
	edges.map = m
	edges.z_index = -14
	return {"floor": fl, "walls": wl, "edges": edges}


static func _near_floor(m: MapGen, x: int, y: int, r: int) -> bool:
	for dy in range(-r, r + 1):
		for dx in range(-r, r + 1):
			if m.is_floor(x + dx, y + dy):
				return true
	return false


static func cell_center(c: Vector2i) -> Vector2:
	return Vector2(c.x * T + T * 0.5, c.y * T + T * 0.5)


## Feet position for something standing in a cell (slightly below centre looks right in 3/4).
static func cell_feet(c: Vector2i) -> Vector2:
	return Vector2(c.x * T + T * 0.5, c.y * T + T * 0.7)


static func world_to_cell(p: Vector2) -> Vector2i:
	return Vector2i(floori(p.x / T), floori(p.y / T))


## Thin highlight along the edges of wall tops where they meet floor: crisp silhouettes.
class WallEdges:
	extends Node2D
	var map: MapGen

	func _draw() -> void:
		var hi := Color(0.36, 0.40, 0.50, 1.0)
		for y in map.h:
			for x in map.w:
				if map.is_floor(x, y) or not map.is_wall(x, y):
					continue
				if map.wall_mat[map.idx(x, y)] == MapGen.W.FENCE:
					continue
				var o := Vector2(x * T, y * T)
				var face := map.is_floor(x, y + 1)
				if map.is_floor(x - 1, y):
					draw_line(o + Vector2(0.5, 0), o + Vector2(0.5, 6 if face else T), hi, 1.0)
				if map.is_floor(x + 1, y):
					draw_line(o + Vector2(T - 0.5, 0), o + Vector2(T - 0.5, 6 if face else T), hi, 1.0)
				if map.is_floor(x, y - 1):
					draw_line(o + Vector2(0, 0.5), o + Vector2(T, 0.5), hi, 1.0)
