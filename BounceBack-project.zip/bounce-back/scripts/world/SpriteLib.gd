class_name SpriteLib
extends RefCounted
## Loads generated sprite sheets into SpriteFrames, prop strips into textures, and makes
## the procedural light textures. Everything is cached.

static var _frames := {}
static var _props := {}
static var _light_tex: Texture2D
static var _cone_tex: Texture2D


static func character_frames(sheet: String) -> SpriteFrames:
	if _frames.has(sheet):
		return _frames[sheet]
	var tex: Texture2D = load("res://assets/sprites/%s.png" % sheet)
	var f := FileAccess.open("res://assets/sprites/%s.json" % sheet, FileAccess.READ)
	var meta: Dictionary = JSON.parse_string(f.get_as_text())
	var cell := Vector2i(int(meta.cell[0]), int(meta.cell[1]))
	var sf := SpriteFrames.new()
	sf.remove_animation("default")
	for anim: String in meta.anims:
		var a: Dictionary = meta.anims[anim]
		sf.add_animation(anim)
		sf.set_animation_speed(anim, float(a.fps))
		sf.set_animation_loop(anim, bool(a.loop))
		for i in int(a.frames):
			var at := AtlasTexture.new()
			at.atlas = tex
			at.region = Rect2(i * cell.x, int(a.row) * cell.y, cell.x, cell.y)
			sf.add_frame(anim, at)
	_frames[sheet] = sf
	return sf


static func prop(name: String) -> Texture2D:
	if not _props.has(name):
		_props[name] = load("res://assets/sprites/td/%s.png" % name)
	return _props[name]


## Sprite2D for a prop strip, anchored at its bottom-centre (feet) for y-sorting.
static func prop_sprite(name: String, frames := 1) -> Sprite2D:
	var s := Sprite2D.new()
	s.texture = prop(name)
	s.hframes = maxi(1, frames)
	s.centered = false
	var fw := s.texture.get_width() / s.hframes
	s.offset = Vector2(-fw * 0.5, -s.texture.get_height())
	return s


static func light_texture() -> Texture2D:
	if _light_tex:
		return _light_tex
	var g := Gradient.new()
	g.set_color(0, Color(1, 1, 1, 1))
	g.set_color(1, Color(1, 1, 1, 0))
	g.add_point(0.55, Color(1, 1, 1, 0.5))
	var t := GradientTexture2D.new()
	t.gradient = g
	t.fill = GradientTexture2D.FILL_RADIAL
	t.fill_from = Vector2(0.5, 0.5)
	t.fill_to = Vector2(1.0, 0.5)
	t.width = 256
	t.height = 256
	_light_tex = t
	return t


## 256px cone with its apex at the CENTRE, pointing +X (~72 degrees), so a PointLight2D
## placed at the eye casts correct shadows. Effective radius = 128px * texture_scale.
static func cone_texture() -> Texture2D:
	if _cone_tex:
		return _cone_tex
	var n := 256
	var img := Image.create(n, n, false, Image.FORMAT_RGBA8)
	var half := deg_to_rad(36.0)
	for y in n:
		for x in n:
			var v := Vector2(x - n * 0.5, y - n * 0.5)
			var d := v.length() / (n * 0.5)
			var ang := absf(v.angle())
			if d > 1.0 or ang > half:
				img.set_pixel(x, y, Color(1, 1, 1, 0))
				continue
			var edge := clampf((half - ang) / deg_to_rad(8.0), 0.0, 1.0)
			img.set_pixel(x, y, Color(1, 1, 1, edge * pow(1.0 - d, 0.8)))
	_cone_tex = ImageTexture.create_from_image(img)
	return _cone_tex


## Direction suffix for 4-way sheets plus whether to flip horizontally.
static func dir_anim(v: Vector2) -> Array:
	if absf(v.x) > absf(v.y) * 1.1:
		return ["side", v.x < 0.0]
	return ["down" if v.y >= 0.0 else "up", false]
