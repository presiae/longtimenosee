class_name World
extends Node2D
## One attempt in the prison: map, objects, characters, lights and camera.
## Rebuilt from MapGen on every attempt, so each run starts from an identical state.

signal exited
signal player_caught(reason: String)
signal zone_changed(zone: Dictionary)

const PLAYER_SCENE := preload("res://scenes/player/Player.tscn")
const AMBIENT := Color(0.075, 0.085, 0.13)
const AMBIENT_OUTDOOR := Color(0.18, 0.21, 0.31)
const CAMERA_ZOOM := 1.35

static var TYPES := {
	"door": [Door, {}], "lever": [Switch, {"kind": "lever"}], "panel": [Switch, {"kind": "panel"}],
	"plate": [PressurePlate, {}], "locker": [HidingSpot, {"kind": "locker"}], "bed": [HidingSpot, {"kind": "bed"}],
	"vent": [Vent, {}], "keycard": [Pickup, {"kind": "keycard"}], "note": [Pickup, {"kind": "note"}],
	"shard": [Pickup, {"kind": "shard"}], "bottle": [Pickup, {"kind": "bottle"}],
	"checkpoint": [Checkpoint, {}], "exit": [LevelExit, {}], "lamp": [Lamp, {}], "prop": [Prop, {}],
	"noise": [NoiseSource, {}], "hint": [Hint, {}], "logic": [Logic, {}],
}

static var _map_cache: MapGen

var map: MapGen
var start_checkpoint := 0
var player: PlayerController
var camera: Camera2D
var entities: Node2D        # y-sorted: characters, props, doors
var objects := {}           # id -> LevelObject
var canvas_mod: CanvasModulate
var player_light: PointLight2D
var lighting_on := true
## Title screen / ending backdrop: no player control, nothing can see or trigger the player.
var attract_mode := false
var current_zone := {}
var _shake := 0.0
var _rng := RandomNumberGenerator.new()


func _ready() -> void:
	if _map_cache == null:
		_map_cache = MapGen.prison()
	map = _map_cache
	var built := MapBuilder.build(map)
	add_child(built.floor)
	add_child(built.walls)
	add_child(built.edges)

	canvas_mod = CanvasModulate.new()
	canvas_mod.color = AMBIENT
	add_child(canvas_mod)

	entities = Node2D.new()
	entities.name = "Entities"
	entities.y_sort_enabled = true
	add_child(entities)
	_spawn_entities()

	player = PLAYER_SCENE.instantiate()
	player.position = spawn_position()
	entities.add_child(player)
	player_light = PointLight2D.new()
	player_light.texture = SpriteLib.light_texture()
	player_light.texture_scale = 1.45
	player_light.energy = 0.85
	player_light.color = Color(1.0, 0.93, 0.82)
	player_light.shadow_enabled = true
	player_light.shadow_filter = PointLight2D.SHADOW_FILTER_PCF5
	player_light.shadow_color = Color(0, 0, 0, 0.9)
	player_light.position = Vector2(0, -10)
	player.add_child(player_light)
	if attract_mode:
		player.controls_enabled = false
		player.is_hidden = true
		player.visible = false
		player.collision_layer = 0
		player.collision_mask = 0
		player.get_node("Interaction").monitoring = false
		player_light.enabled = false

	camera = Camera2D.new()
	camera.zoom = Vector2(CAMERA_ZOOM, CAMERA_ZOOM)
	camera.position_smoothing_enabled = true
	camera.position_smoothing_speed = 6.0
	camera.limit_left = 0
	camera.limit_top = 0
	camera.limit_right = map.w * MapGen.TILE
	camera.limit_bottom = map.h * MapGen.TILE
	player.add_child(camera)
	camera.position = Vector2(0, -12)
	camera.make_current()
	camera.reset_smoothing.call_deferred()
	_rng.seed = 5
	_update_zone(true)


# ------------------------------------------------------------------ guard navigation
var nav: AStarGrid2D


func _build_nav() -> void:
	nav = AStarGrid2D.new()
	nav.region = Rect2i(0, 0, map.w, map.h)
	nav.cell_size = Vector2(MapGen.TILE, MapGen.TILE)
	nav.offset = Vector2(MapGen.TILE * 0.5, MapGen.TILE * 0.7)
	nav.diagonal_mode = AStarGrid2D.DIAGONAL_MODE_ONLY_IF_NO_OBSTACLES
	nav.default_compute_heuristic = AStarGrid2D.HEURISTIC_OCTILE
	nav.update()
	for y in map.h:
		for x in map.w:
			if not map.is_floor(x, y) or map.hidden[map.idx(x, y)] == 1:
				nav.set_point_solid(Vector2i(x, y), true)
	for o: LevelObject in objects.values():
		if o is Prop:
			for c in o.blocked_cells():
				if map.inside(c.x, c.y):
					nav.set_point_solid(c, true)
		elif o is HidingSpot or o is Switch:
			nav.set_point_solid(o.cell, true)
		elif o is Door:
			_door_nav(o)
			o.opened.connect(_door_nav.bind(o))
			o.closed.connect(_door_nav.bind(o))


func _door_nav(d: Door) -> void:
	for i in range(-(d.width_cells / 2), d.width_cells / 2 + 1):
		var c := d.cell + Vector2i(i, 0)
		if map.inside(c.x, c.y):
			nav.set_point_solid(c, not d.is_open)


func find_path(from: Vector2, to: Vector2) -> PackedVector2Array:
	if nav == null:
		_build_nav()
	var a := MapBuilder.world_to_cell(from)
	var b := MapBuilder.world_to_cell(to)
	if not nav.is_in_boundsv(a) or not nav.is_in_boundsv(b):
		return PackedVector2Array()
	var pts := nav.get_point_path(a, b, true)
	if pts.size() > 0 and not nav.is_point_solid(b) and MapBuilder.world_to_cell(pts[pts.size() - 1]) == b:
		pts[pts.size() - 1] = to
	return pts


func is_walkable_line(a: Vector2, b: Vector2) -> bool:
	var q := PhysicsRayQueryParameters2D.create(a + Vector2(0, -4), b + Vector2(0, -4), 1 | 16 | 128)
	return get_world_2d().direct_space_state.intersect_ray(q).is_empty()


func spawn_position() -> Vector2:
	if start_checkpoint > 0:
		for o: LevelObject in objects.values():
			if o is Checkpoint and o.index == start_checkpoint:
				return o.position
	for e: Dictionary in map.entities:
		if e.type == "start":
			return MapBuilder.cell_feet(Vector2i(int(e.cell[0]), int(e.cell[1])))
	return Vector2(64, 64)


func _spawn_entities() -> void:
	var lm := get_node_or_null("/root/LevelManager")
	for i in map.entities.size():
		var e: Dictionary = map.entities[i]
		var type := str(e.type)
		if type == "start":
			continue
		if not TYPES.has(type):
			_spawn_extra(type, e, i)
			continue
		var cfg: Dictionary = (TYPES[type][1] as Dictionary).duplicate()
		cfg.merge(e, true)
		if not cfg.has("id"):
			cfg["id"] = "%s_%d" % [type, i]
		if lm and type in ["keycard", "note", "shard"] and lm.is_collected(cfg.id):
			continue
		var o: LevelObject = (TYPES[type][0] as GDScript).new()
		o.name = str(cfg.id)
		o.setup(cfg, self)
		var c := Vector2i(int(e.cell[0]), int(e.cell[1]))
		o.position = MapBuilder.cell_center(c) if type in ["door", "vent", "plate", "checkpoint", "lamp", "logic", "exit"] \
			else MapBuilder.cell_feet(c)
		o.position += Vector2(float(e.get("dx", 0)), float(e.get("dy", 0)))
		entities.add_child(o)
		objects[cfg.id] = o
		if o is Checkpoint:
			o.reached.connect(_on_checkpoint)
		elif o is LevelExit:
			o.player_exited.connect(func() -> void: exited.emit())
	_wire_links()


## Hook for entity types owned by other systems (guards, cameras, floodlights).
func _spawn_extra(type: String, e: Dictionary, i: int) -> void:
	var cfg := e.duplicate()
	if not cfg.has("id"):
		cfg["id"] = "%s_%d" % [type, i]
	var o: LevelObject = null
	match type:
		"guard":
			o = GuardAI.new()
		"camera":
			o = SecurityCamera.new()
		"tower":
			o = Floodlight.new()
		_:
			push_warning("Unknown entity type " + type)
			return
	o.name = str(cfg.id)
	o.setup(cfg, self)
	var c := Vector2i(int(e.cell[0]), int(e.cell[1]))
	o.position = MapBuilder.cell_feet(c)
	entities.add_child(o)
	objects[cfg.id] = o


func _wire_links() -> void:
	for o: LevelObject in objects.values():
		var targets: Array = o.config.get("targets", [])
		for t: String in targets:
			if not objects.has(t):
				push_error("%s links to missing object '%s'" % [o.object_id, t])
				continue
			var target: LevelObject = objects[t]
			var src := o.object_id
			target.register_input(src)
			o.output_changed.connect(func(on: bool) -> void: target.set_input(src, on))


func _on_checkpoint(index: int) -> void:
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.reach_checkpoint(index)


func _process(delta: float) -> void:
	if _shake > 0.0:
		_shake = maxf(0.0, _shake - delta * 1.8)
		var amt := _shake * _shake * 6.0
		var settings := get_node_or_null("/root/SaveManager")
		if settings and not settings.get_setting("screen_shake", true):
			amt = 0.0
		camera.offset = Vector2(_rng.randf_range(-1, 1), _rng.randf_range(-1, 1)) * amt
	if is_instance_valid(player):
		player.in_vent = map.hidden[map.idx(_cell_of(player.global_position).x, _cell_of(player.global_position).y)] == 1 \
			if map.inside(_cell_of(player.global_position).x, _cell_of(player.global_position).y) else false
		_update_zone(false)


func _cell_of(p: Vector2) -> Vector2i:
	return MapBuilder.world_to_cell(p)


func _update_zone(force: bool) -> void:
	var z := map.zone_at(_cell_of(player.global_position))
	if z.is_empty() or (not force and z.get("id") == current_zone.get("id")):
		return
	current_zone = z
	if not attract_mode:
		var am := get_node_or_null("/root/AudioManager")
		if am:
			am.set_ambience(str(z.ambience))
			am.base_intensity = 0.35 if int(z.id) >= 4 else 0.0
	var outdoor: bool = int(z.id) >= 4
	var tw := create_tween()
	tw.tween_property(canvas_mod, "color", AMBIENT_OUTDOOR if outdoor else AMBIENT, 1.5)
	zone_changed.emit(z)


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("toggle_light"):
		lighting_on = not lighting_on
		canvas_mod.visible = lighting_on


func shake_camera(amount: float, from := Vector2.INF) -> void:
	if from != Vector2.INF and is_instance_valid(player) and from.distance_to(player.global_position) > 400.0:
		return
	_shake = clampf(_shake + amount, 0.0, 1.0)


## Combined light level (0 dark .. 1 bright) at a point from lamps (respecting walls).
func light_at(p: Vector2) -> float:
	var best := 0.0
	for lamp in get_tree().get_nodes_in_group("lamps"):
		if lamp.level == self:
			best = maxf(best, lamp.light_at(p))
	for f in get_tree().get_nodes_in_group("floodlights"):
		if f.level == self:
			best = maxf(best, f.light_at(p))
	return best


func is_hidden_cell(p: Vector2) -> bool:
	var c := _cell_of(p)
	return map.inside(c.x, c.y) and map.hidden[map.idx(c.x, c.y)] == 1
