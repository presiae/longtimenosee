class_name MapGen
extends RefCounted
## Builds the prison as a grid: rooms are carved from rectangles and ellipses, walls are
## generated automatically around every open floor cell, and doors sit in carved gaps.
## The layout is authored in code (`prison()`), decorated with a seeded RNG, and produces
## the same map every time so Echo recordings stay valid.

const TILE := 32
const SOLID := -1

# Floor materials -> atlas coords in td_tiles.png
enum F { CONC, CONC2, CELL, CHECK, METAL, DARK, WOOD, CARPET, GRASS, GRASS2, DIRT, GRAVEL, ASPH, ASPH_LINE, SAND, PUDDLE }
# Wall materials -> atlas row
enum W { CONC = 2, BRICK = 3, STONE = 4, FENCE = 5 }

var w := 85
var h := 55
var floor_mat: PackedInt32Array
var wall_mat: PackedInt32Array
var hidden: PackedByteArray     # vent crawlspaces: you can't be seen in them
var entities: Array = []
var zones: Array = []
var rng := RandomNumberGenerator.new()


func _init(width := 85, height := 55, seed_value := 1979) -> void:
	w = width
	h = height
	rng.seed = seed_value
	floor_mat = PackedInt32Array()
	floor_mat.resize(w * h)
	floor_mat.fill(SOLID)
	wall_mat = PackedInt32Array()
	wall_mat.resize(w * h)
	wall_mat.fill(W.CONC)
	hidden = PackedByteArray()
	hidden.resize(w * h)


func idx(x: int, y: int) -> int:
	return y * w + x


func inside(x: int, y: int) -> bool:
	return x >= 0 and y >= 0 and x < w and y < h


func is_floor(x: int, y: int) -> bool:
	return inside(x, y) and floor_mat[idx(x, y)] != SOLID


## Solid cell that touches open floor (8-neighbourhood): drawn and collided as wall.
func is_wall(x: int, y: int) -> bool:
	if not inside(x, y):
		return false
	if is_floor(x, y):
		return false
	for dy in range(-1, 2):
		for dx in range(-1, 2):
			if is_floor(x + dx, y + dy):
				return true
	return false


# ------------------------------------------------------------------ carving
func carve(x0: int, y0: int, x1: int, y1: int, mat: int) -> void:
	for y in range(mini(y0, y1), maxi(y0, y1) + 1):
		for x in range(mini(x0, x1), maxi(x0, x1) + 1):
			if inside(x, y):
				floor_mat[idx(x, y)] = _vary(mat)


## Non-rectangular rooms and yards.
func ellipse(cx: float, cy: float, rx: float, ry: float, mat: int) -> void:
	for y in range(int(cy - ry) - 1, int(cy + ry) + 2):
		for x in range(int(cx - rx) - 1, int(cx + rx) + 2):
			var nx := (x - cx) / rx
			var ny := (y - cy) / ry
			if nx * nx + ny * ny <= 1.0 and inside(x, y):
				floor_mat[idx(x, y)] = _vary(mat)


func fill_solid(x0: int, y0: int, x1: int, y1: int) -> void:
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			if inside(x, y):
				floor_mat[idx(x, y)] = SOLID


func wall_zone(x0: int, y0: int, x1: int, y1: int, mat: int) -> void:
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			if inside(x, y):
				wall_mat[idx(x, y)] = mat


func hide_cells(x0: int, y0: int, x1: int, y1: int) -> void:
	for y in range(y0, y1 + 1):
		for x in range(x0, x1 + 1):
			hidden[idx(x, y)] = 1


func _vary(mat: int) -> int:
	if mat == F.CONC and rng.randf() < 0.18:
		return F.CONC2
	if mat == F.GRASS and rng.randf() < 0.3:
		return F.GRASS2
	return mat


func add(type: String, x: int, y: int, props := {}) -> Dictionary:
	var e := {"type": type, "cell": [x, y]}
	e.merge(props, true)
	entities.append(e)
	return e


func zone(id: int, title: String, rect: Rect2i, objective: String, ambience: String) -> void:
	zones.append({"id": id, "title": title, "rect": rect, "objective": objective, "ambience": ambience})


func zone_at(cell: Vector2i) -> Dictionary:
	for z: Dictionary in zones:
		if (z.rect as Rect2i).has_point(cell):
			return z
	return {}


# ------------------------------------------------------------------ the prison
static func prison() -> MapGen:
	var m := MapGen.new()
	m._layout()
	return m


func _layout() -> void:
	# ============ ZONE 1 — THE CELL =====================================
	zone(1, "THE CELL", Rect2i(2, 2, 19, 12), "Escape your cell.", "amb_cell")
	carve(4, 4, 8, 7, F.CELL)                 # your cell
	carve(6, 8, 6, 8, F.CELL)                 # cell door gap
	carve(9, 5, 16, 5, F.DARK)                # vent crawlspace...
	carve(16, 6, 16, 8, F.DARK)               # ...dropping into the corridor
	hide_cells(9, 5, 16, 8)
	carve(3, 9, 21, 12, F.CONC)               # guard corridor
	add("start", 5, 6)
	add("bed", 4, 5, {"id": "bed_cell"})
	add("prop", 8, 4, {"art": "toilet"})
	add("prop", 7, 4, {"art": "sink"})
	add("lamp", 6, 5, {"radius": 110, "flicker": true, "energy": 0.7})
	add("note", 4, 7, {"id": "note_cell", "title": "Scratched into the bunk",
		"text": "Day 412. The guard on the corridor never leaves his post. Unless something rattles in here."})
	add("door", 6, 8, {"id": "cell_door", "style": "bars", "mode": "locked"})
	add("noise", 6, 7, {"id": "bars", "prompt": "Rattle the bars", "loudness": 1.0, "sfx": "bars", "emit_at": [6, 9]})
	add("vent", 9, 5, {"id": "cell_vent"})
	add("lamp", 17, 10, {"radius": 150, "id": "post_lamp"})
	add("lamp", 4, 10, {"radius": 90, "energy": 0.6})
	add("guard", 14, 10, {"id": "g_post", "patrol": [[14, 10]], "facing": "east", "look_around": false})
	add("hint", 5, 6, {"w": 5, "h": 4, "text": "WASD to move.  E to interact.  The vent grate is on the east wall."})
	add("hint", 12, 5, {"w": 6, "h": 1, "text": "Vents are dark: nobody can see you in here."})
	add("prop", 18, 9, {"art": "barrel"})
	add("prop", 19, 12, {"art": "crate"})

	# ============ ZONE 2 — THE CELL BLOCK ===============================
	zone(2, "THE CELL BLOCK", Rect2i(21, 2, 21, 19), "Find a way south to the security wing.", "amb_block")
	wall_zone(21, 2, 41, 20, W.BRICK)
	carve(22, 8, 40, 13, F.CHECK)             # main hall
	for cx: int in [23, 28, 33, 38]:          # upper cells
		carve(cx, 3, cx + 2, 6, F.CELL)
		carve(cx + 1, 7, cx + 1, 7, F.CELL)
	for cx: int in [23, 27]:                  # lower cells
		carve(cx, 15, cx + 2, 18, F.CELL)
		carve(cx + 1, 14, cx + 1, 14, F.CELL)
	carve(33, 15, 36, 18, F.DARK)             # showers
	carve(34, 14, 35, 14, F.DARK)
	carve(38, 15, 40, 18, F.CONC)             # store room
	carve(39, 14, 39, 14, F.CONC)
	carve(31, 14, 31, 21, F.CONC)             # corridor south (to security)
	add("checkpoint", 22, 10, {"index": 1})
	add("door", 24, 7, {"style": "bars", "mode": "locked"})
	add("door", 29, 7, {"style": "bars", "mode": "locked"})
	add("door", 34, 7, {"id": "store_door", "style": "steel", "mode": "manual"})
	add("door", 39, 7, {"style": "bars", "mode": "locked"})
	add("door", 24, 14, {"style": "bars", "mode": "locked"})
	add("door", 28, 14, {"style": "bars", "mode": "locked"})
	add("door", 39, 14, {"id": "storeroom_door", "style": "steel", "mode": "manual"})
	add("door", 31, 14, {"id": "south_gate", "style": "steel", "mode": "switch", "hold_time": 1.6})
	add("lever", 35, 4, {"id": "south_lever", "targets": ["south_gate"], "mode": "pulse", "pulse": 0.4})
	add("bottle", 33, 5)
	add("bottle", 36, 16)
	add("shard", 40, 17, {"id": "shard_1"})
	add("note", 38, 16, {"id": "note_block", "title": "Work order",
		"text": "South gate lever is wired to the store room. It only holds for a couple of seconds. Nobody can be in two places at once, right?"})
	for cx: int in [23, 28, 38]:
		add("bed", cx, 4)
	for lx: int in [26, 32, 37]:
		add("locker", lx, 8)
	add("locker", 27, 13, {"against": "south"})
	add("locker", 32, 13, {"id": "gate_locker", "against": "south"})
	add("lamp", 26, 9, {"radius": 95})
	add("lamp", 32, 9, {"radius": 95, "flicker": true})
	add("lamp", 38, 9, {"radius": 95})
	add("lamp", 34, 4, {"radius": 70, "energy": 0.6})
	add("lamp", 35, 16, {"radius": 80, "energy": 0.5})
	add("guard", 39, 9, {"id": "g_hall_a", "patrol": [[39, 9], [29, 9]], "wait": 1.2})
	add("guard", 38, 11, {"id": "g_hall_b", "patrol": [[38, 11], [34, 11], [34, 9], [38, 9]], "wait": 2.0})
	add("hint", 31, 13, {"w": 2, "h": 2, "text": "This gate is wired to a lever. It won't stay open long enough on your own... the locker beside it is a good place to wait."})
	add("hint", 22, 10, {"w": 2, "h": 3, "text": "Guards only see far in the light. Hold CTRL and keep to the dark south wall."})

	# ============ ZONE 3 — SECURITY WING ================================
	zone(3, "SECURITY WING", Rect2i(3, 21, 39, 13), "Get the red keycard from the control room.", "amb_security")
	carve(26, 22, 36, 25, F.METAL)            # lobby
	carve(6, 26, 41, 28, F.METAL)             # long hallway (cameras)
	carve(8, 22, 12, 24, F.WOOD)              # records room (plate A)
	carve(10, 25, 10, 25, F.WOOD)
	carve(15, 30, 20, 32, F.WOOD)             # interview room (plate B)
	carve(18, 29, 18, 29, F.WOOD)
	carve(22, 30, 29, 32, F.CARPET)           # control room
	carve(25, 29, 25, 29, F.CARPET)
	carve(42, 27, 45, 27, F.CONC)             # exit passage to the yard
	add("checkpoint", 31, 23, {"index": 2})
	add("panel", 28, 22, {"id": "cam_panel", "mode": "pulse", "pulse": 7.0, "targets": ["cam_1", "cam_2", "cam_3"]})
	add("camera", 14, 26, {"id": "cam_1", "dir": 90, "sweep": 55, "speed": 0.55, "range": 170})
	add("camera", 24, 26, {"id": "cam_2", "dir": 90, "sweep": 55, "speed": 0.7, "range": 170, "phase": 1.5})
	add("camera", 35, 26, {"id": "cam_3", "dir": 90, "sweep": 55, "speed": 0.6, "range": 170, "phase": 0.7})
	add("plate", 10, 23, {"id": "plate_a", "targets": ["control_and"]})
	add("plate", 18, 31, {"id": "plate_b", "targets": ["control_and"]})
	add("logic", 25, 29, {"id": "control_and", "require_all": true, "targets": ["control_door"]})
	add("door", 25, 29, {"id": "control_door", "style": "steel", "mode": "switch"})
	add("lever", 27, 30, {"id": "control_exit", "targets": ["control_door"], "mode": "pulse", "pulse": 3.0})
	add("keycard", 23, 31, {"id": "card_red", "key": "red"})
	add("shard", 28, 31, {"id": "shard_2"})
	add("prop", 22, 30, {"art": "desk", "frames": 2})
	add("note", 26, 31, {"id": "note_control", "title": "Shift log",
		"text": "Inmate 7 caught again at 02:14. Swear I saw him in the records room and the interview room at the same time."})
	add("door", 42, 27, {"id": "yard_door", "style": "red", "mode": "key", "key": "red"})
	add("prop", 9, 22, {"art": "desk", "frames": 2})
	add("prop", 16, 30, {"art": "table"})
	add("prop", 34, 22, {"art": "desk", "frames": 2})
	add("locker", 33, 25, {"against": "south"})
	add("locker", 20, 28, {"against": "south"})
	add("bottle", 36, 24)
	add("lamp", 31, 23, {"radius": 120, "color": "#cfe0ff"})
	add("lamp", 10, 27, {"radius": 110, "color": "#cfe0ff"})
	add("lamp", 20, 27, {"radius": 110, "color": "#cfe0ff"})
	add("lamp", 30, 27, {"radius": 110, "color": "#cfe0ff"})
	add("lamp", 39, 27, {"radius": 110, "color": "#cfe0ff"})
	add("lamp", 10, 23, {"radius": 80, "energy": 0.6})
	add("lamp", 18, 31, {"radius": 80, "energy": 0.6})
	add("lamp", 25, 31, {"radius": 110, "color": "#a0ffd0", "energy": 0.8})
	add("guard", 8, 27, {"id": "g_sec", "patrol": [[8, 27], [22, 27]], "wait": 2.5})
	add("hint", 25, 28, {"w": 3, "h": 1, "text": "Both pressure plates must be held at once. You'll need two Echoes."})
	add("hint", 28, 23, {"w": 2, "h": 2, "text": "The breaker cuts the cameras for a few seconds."})

	# ============ ZONE 4 — THE YARD =====================================
	zone(4, "THE YARD", Rect2i(42, 2, 41, 41), "Cut the floodlights and open the main gate.", "amb_yard")
	wall_zone(43, 2, 82, 44, W.STONE)
	carve(46, 5, 78, 39, F.GRASS)             # yard, with bevelled corners
	carve(48, 4, 76, 4, F.GRASS)
	carve(45, 7, 45, 37, F.GRASS)
	carve(79, 7, 79, 37, F.GRASS)
	carve(46, 25, 49, 30, F.GRASS)
	carve(45, 27, 45, 27, F.CONC)
	ellipse(66, 14, 7.5, 4.5, F.SAND)          # exercise ground
	ellipse(55, 33, 5.0, 3.0, F.DIRT)
	carve(46, 40, 77, 40, F.GRAVEL)
	carve(68, 34, 72, 40, F.GRAVEL)            # path to the gate
	carve(46, 27, 66, 27, F.GRAVEL)
	# Buildings inside the yard (left solid, interiors carved, doors in the gaps)
	fill_solid(50, 8, 58, 15)
	carve(51, 9, 57, 14, F.WOOD)               # workshop
	carve(54, 15, 54, 15, F.WOOD)
	fill_solid(63, 24, 70, 30)
	carve(64, 25, 69, 29, F.CONC)              # generator shed
	carve(66, 30, 66, 30, F.CONC)
	fill_solid(58, 34, 64, 38)
	carve(59, 35, 63, 37, F.CONC)              # guard hut
	carve(61, 34, 61, 34, F.CONC)
	add("checkpoint", 47, 27, {"index": 3})
	add("door", 54, 15, {"style": "steel", "mode": "manual"})
	add("door", 61, 34, {"style": "steel", "mode": "manual"})
	add("prop", 52, 10, {"art": "table"})
	add("prop", 56, 13, {"art": "crate"})
	add("prop", 51, 13, {"art": "barrel"})
	add("bottle", 53, 12)
	add("bottle", 55, 10)
	add("note", 57, 9, {"id": "note_workshop", "title": "Torn page",
		"text": "Gate plates: one each side of the road. The gate only opens while BOTH are held down. Floodlights run off the shed generator."})
	add("lamp", 54, 11, {"radius": 100, "energy": 0.7})
	add("prop", 66, 26, {"art": "generator", "frames": 2})
	add("lever", 68, 27, {"id": "power_lever", "targets": ["tower_1", "tower_2"]})
	add("lamp", 66, 28, {"radius": 80, "energy": 0.6})
	add("prop", 60, 36, {"art": "table"})
	add("lamp", 61, 36, {"radius": 80})
	add("noise", 57, 38, {"id": "dumpster", "prompt": "Kick the dumpster", "loudness": 1.0, "sfx": "bang"})
	add("prop", 57, 38, {"art": "barrel"})
	add("tower", 75, 8, {"id": "tower_1", "a": [58, 20], "b": [76, 22], "period": 7.0})
	add("tower", 47, 36, {"id": "tower_2", "a": [64, 38], "b": [77, 37], "period": 6.0, "phase": 2.0})
	add("prop", 66, 9, {"art": "hoop"})
	add("prop", 61, 15, {"art": "weights"})
	add("prop", 71, 15, {"art": "bench"})
	for t: Array in [[47, 6], [77, 6], [48, 22], [76, 30], [73, 20]]:
		add("prop", t[0], t[1], {"art": "tree"})
	for b: Array in [[52, 20], [58, 22], [74, 26], [50, 31]]:
		add("prop", b[0], b[1], {"art": "bush"})
	add("guard", 48, 18, {"id": "g_yard_a", "patrol": [[48, 18], [60, 18], [60, 6], [48, 6]], "wait": 1.0})
	add("guard", 76, 12, {"id": "g_yard_b", "patrol": [[76, 12], [76, 33], [71, 33]], "wait": 1.5})
	add("guard", 70, 38, {"id": "g_gate", "patrol": [[70, 38]], "facing": "north", "look_around": true})

	# ============ ZONE 5 — THE GATE AND OUTSIDE ==========================
	zone(5, "OUTSIDE", Rect2i(42, 44, 43, 11), "Run.", "amb_outside")
	carve(69, 41, 71, 43, F.ASPH)              # gate passage through the perimeter wall
	add("plate", 64, 39, {"id": "gate_plate_a", "targets": ["gate_and"]})
	add("plate", 76, 39, {"id": "gate_plate_b", "targets": ["gate_and"]})
	add("logic", 70, 41, {"id": "gate_and", "require_all": true, "targets": ["main_gate"]})
	add("door", 70, 42, {"id": "main_gate", "style": "gate", "mode": "switch", "hold_time": 1.0})
	add("lamp", 70, 40, {"radius": 120, "color": "#ffe0a0"})
	add("hint", 70, 40, {"w": 3, "h": 1, "text": "Both gate plates at once - and the floodlights off. Time for every Echo you have."})
	wall_zone(43, 45, 84, 54, W.FENCE)
	carve(44, 46, 83, 53, F.GRASS)             # outside
	carve(44, 49, 83, 51, F.ASPH)
	carve(44, 50, 83, 50, F.ASPH_LINE)
	carve(69, 44, 71, 48, F.ASPH)
	add("prop", 62, 48, {"art": "car", "frames": 2})
	add("prop", 76, 46, {"art": "sign"})
	for t: Array in [[47, 47], [55, 47], [80, 47], [50, 53], [60, 53], [74, 53], [66, 47]]:
		add("prop", t[0], t[1], {"art": "tree"})
	add("exit", 82, 50)
	add("lamp", 70, 46, {"radius": 140, "color": "#ffd0a0", "energy": 0.6})
	add("lamp", 58, 50, {"radius": 120, "color": "#ffd0a0", "energy": 0.5})

	# Perimeter: the outer ring of solid around the yard uses stone walls.
	wall_zone(0, 0, 84, 0, W.STONE)
