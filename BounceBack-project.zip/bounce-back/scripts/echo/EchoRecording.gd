class_name EchoRecording
extends RefCounted
## One recorded attempt, sampled every physics frame (60 Hz, fixed timestep).
## Per frame: position, facing, animation name index and flags. Plus timestamped events:
##   {"f": frame, "type": "interact", "id": object_id}
##   {"f": frame, "type": "noise", "loud": float, "kind": String}
##   {"f": frame, "type": "throw", "dir": Vector2}      (target relative to origin)

const FLAG_HIDDEN := 1
const FLAG_SNEAK := 2
const FLAG_RUN := 4

var positions := PackedVector2Array()
var facings := PackedVector2Array()
var anim_ids := PackedInt32Array()
var flags := PackedInt32Array()
var events: Array = []
var anim_names: Array[String] = []
var start_checkpoint := 0
var created_attempt := 0
## Index of the next event to fire during playback.
var _anim_lookup := {}


func frame_count() -> int:
	return positions.size()


func duration() -> float:
	return frame_count() / 60.0


func add_frame(pos: Vector2, facing: Vector2, anim: String, flag: int) -> void:
	positions.append(pos)
	facings.append(facing)
	if not _anim_lookup.has(anim):
		_anim_lookup[anim] = anim_names.size()
		anim_names.append(anim)
	anim_ids.append(_anim_lookup[anim])
	flags.append(flag)


func add_event(e: Dictionary) -> void:
	e["f"] = maxi(0, frame_count() - 1)
	events.append(e)


func anim_at(i: int) -> String:
	return anim_names[anim_ids[i]] if i < anim_ids.size() else "idle_down"


func summary() -> String:
	var counts := {}
	for e: Dictionary in events:
		counts[e.type] = int(counts.get(e.type, 0)) + 1
	return "%.1fs, %d events %s" % [duration(), events.size(), counts]
