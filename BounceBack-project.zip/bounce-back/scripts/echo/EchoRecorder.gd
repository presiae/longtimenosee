class_name EchoRecorder
extends Node
## Records the real player every physics frame. Runs after the player has moved
## (higher process priority) so each sample is that frame's final state.

var player: PlayerController
var recording := EchoRecording.new()
var active := true


func _init() -> void:
	process_physics_priority = 100


func attach(p: PlayerController, checkpoint: int, attempt: int) -> void:
	player = p
	recording.start_checkpoint = checkpoint
	recording.created_attempt = attempt
	p.interaction.used.connect(func(id: String) -> void: _event({"type": "interact", "id": id}))
	p.threw.connect(func(o: Vector2, t: Vector2) -> void: _event({"type": "throw", "dir": t - o, "off": o - p.global_position}))
	p.noise_made.connect(func(l: float, k: String) -> void: _event({"type": "noise", "loud": l, "kind": k}))


## Throw away everything recorded so far (used when a checkpoint changes the start point).
func restart(checkpoint: int) -> void:
	var attempt := recording.created_attempt
	recording = EchoRecording.new()
	recording.start_checkpoint = checkpoint
	recording.created_attempt = attempt


func _event(e: Dictionary) -> void:
	if active:
		recording.add_event(e)


func _physics_process(_delta: float) -> void:
	if not active or not is_instance_valid(player):
		return
	var f := 0
	if player.is_hidden:
		f |= EchoRecording.FLAG_HIDDEN
	if player.sneaking:
		f |= EchoRecording.FLAG_SNEAK
	if player.running:
		f |= EchoRecording.FLAG_RUN
	recording.add_frame(player.global_position, player.facing, player.anim, f)
