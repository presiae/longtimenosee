class_name Echo
extends Node2D
## A replay of a previous attempt — not an AI. Every physics frame it moves to the recorded
## position, plays the recorded animation, and fires recorded events at the same frame:
## interacting with Echo-compatible objects, making the same noises, throwing bottles.
## It presses plates (Area2D on the "echo" layer) and draws guards' attention, but it can't
## pick anything up, can't be caught, and can't leave the prison.
##
## Robustness: if the recorded path is blocked by a door that is closed in THIS attempt,
## the Echo stalls (flickering) instead of walking through it; after STALL_LIMIT seconds it
## dissolves. Playback errors never stop the game.

signal finished(echo: Echo)
signal event_fired(echo: Echo, e: Dictionary, ok: bool)

const STALL_LIMIT := 2.0
const INTERACT_REACH := 56.0

var rec: EchoRecording
var world: Node
var slot := 0
var frame := 0
var concealed := false
var sneaking := false
var stalled_t := 0.0
var sprite: AnimatedSprite2D
var glow: PointLight2D
var area: Area2D
var _next_event := 0
var _done := false
var _time := 0.0
var events_log: Array[String] = []


func _init() -> void:
	process_physics_priority = -10


func setup(recording: EchoRecording, w: Node, index: int) -> void:
	rec = recording
	world = w
	slot = index


func _ready() -> void:
	add_to_group("echo")
	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = SpriteLib.character_frames("td_echo")
	sprite.centered = false
	sprite.offset = Vector2(-16, -31)
	var mat := ShaderMaterial.new()
	mat.shader = preload("res://shaders/echo.gdshader")
	mat.set_shader_parameter("seed", float(slot) * 1.7)
	sprite.material = mat
	add_child(sprite)
	glow = PointLight2D.new()
	glow.texture = SpriteLib.light_texture()
	glow.texture_scale = 0.55
	glow.color = Color(0.3, 0.95, 1.0)
	glow.energy = 0.9
	glow.position = Vector2(0, -12)
	add_child(glow)
	area = Area2D.new()
	area.collision_layer = 4
	area.collision_mask = 0
	var cs := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 6
	cs.shape = c
	cs.position = Vector2(0, -4)
	area.add_child(cs)
	add_child(area)
	if rec.frame_count() > 0:
		global_position = rec.positions[0]
	_apply_frame(0)


func get_eye_target() -> Vector2:
	return global_position + Vector2(0, -12)


func is_concealed() -> bool:
	return concealed


func progress() -> float:
	return clampf(float(frame) / maxf(1.0, rec.frame_count()), 0.0, 1.0)


func _physics_process(delta: float) -> void:
	if _done:
		return
	_time += delta
	var n := rec.frame_count()
	if frame + 1 >= n:
		dissolve("recording ended")
		return
	var next := rec.positions[frame + 1]
	if _blocked_at(next):
		stalled_t += delta
		sprite.modulate.a = 0.35 + 0.35 * absf(sin(_time * 20.0))
		if stalled_t >= STALL_LIMIT:
			dissolve("blocked by a closed door")
		return
	stalled_t = 0.0
	frame += 1
	_apply_frame(frame)
	while _next_event < rec.events.size() and int(rec.events[_next_event].f) <= frame:
		_fire(rec.events[_next_event])
		_next_event += 1


func _apply_frame(i: int) -> void:
	global_position = rec.positions[i]
	var fl := rec.flags[i]
	var hidden_now := fl & EchoRecording.FLAG_HIDDEN != 0
	var in_vent: bool = world.is_hidden_cell(global_position) if world and world.has_method("is_hidden_cell") else false
	concealed = hidden_now or in_vent
	sneaking = fl & EchoRecording.FLAG_SNEAK != 0
	visible = not hidden_now
	var a := rec.anim_at(i)
	var d: Array = SpriteLib.dir_anim(rec.facings[i])
	sprite.flip_h = d[1]
	if sprite.animation != a and sprite.sprite_frames.has_animation(a):
		sprite.play(a)
	if not _done:
		sprite.modulate.a = 0.55 if in_vent else 0.85


## A closed door or bars where the recording wants to step next.
func _blocked_at(p: Vector2) -> bool:
	var params := PhysicsShapeQueryParameters2D.new()
	var c := CircleShape2D.new()
	c.radius = 4.0
	params.shape = c
	params.transform = Transform2D(0.0, p + Vector2(0, -4))
	params.collision_mask = 16 | 128
	return not get_world_2d().direct_space_state.intersect_shape(params, 1).is_empty()


func _fire(e: Dictionary) -> void:
	var ok := false
	match str(e.type):
		"interact":
			var obj: Node = world.objects.get(str(e.id)) if world else null
			if obj is Interactable and is_instance_valid(obj):
				if obj.global_position.distance_to(global_position) <= INTERACT_REACH:
					ok = obj.try_interact(self)
			_log("%d interact %s -> %s" % [frame, e.id, "ok" if ok else "skipped"])
		"noise":
			var nm := get_node_or_null("/root/NoiseManager")
			if nm:
				nm.emit_noise(global_position, float(e.loud), self, str(e.kind))
			var am := get_node_or_null("/root/AudioManager")
			if am and str(e.kind).begins_with("step"):
				am.play_at("step", global_position, -4.0, true)
			ok = true
		"throw":
			var origin: Vector2 = global_position + (e.get("off", Vector2(0, -14)) as Vector2)
			PlayerController.spawn_projectile(get_parent(), origin, origin + (e.dir as Vector2), true)
			_log("%d throw" % frame)
			ok = true
	event_fired.emit(self, e, ok)


## A guard walked into us: a flicker, nothing more. Echoes can't be caught.
func brush_past() -> void:
	var tw := create_tween()
	tw.tween_property(sprite, "modulate:a", 0.15, 0.08)
	tw.tween_property(sprite, "modulate:a", 0.85, 0.3)


func dissolve(reason: String) -> void:
	if _done:
		return
	_done = true
	_log("%d dissolved: %s" % [frame, reason])
	area.set_deferred("monitorable", false)
	area.get_child(0).set_deferred("disabled", true)
	var tw := create_tween()
	tw.tween_property(sprite, "modulate:a", 0.0, 0.6)
	tw.parallel().tween_property(glow, "energy", 0.0, 0.6)
	tw.tween_callback(func() -> void:
		finished.emit(self)
		queue_free())


func _log(s: String) -> void:
	events_log.append(s)
	if events_log.size() > 30:
		events_log.pop_front()
