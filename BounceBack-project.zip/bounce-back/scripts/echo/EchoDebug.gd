class_name EchoDebug
extends Node2D
## F3 overlay for inspecting recording and playback: every Echo's full recorded path,
## its event markers (cyan = interact, yellow = noise, white = throw), its current
## frame, plus a text panel with recordings, playback logs and guard states.

var world: Node
var label: Label
var layer: CanvasLayer


func _ready() -> void:
	z_index = 50
	var m := CanvasItemMaterial.new()
	m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	material = m
	layer = CanvasLayer.new()
	layer.layer = 50
	add_child(layer)
	label = Label.new()
	label.position = Vector2(14, 100)
	label.add_theme_font_size_override("font_size", 11)
	label.add_theme_color_override("font_color", Color(0.6, 1.0, 1.0))
	label.add_theme_color_override("font_shadow_color", Color.BLACK)
	layer.add_child(label)


func _process(_d: float) -> void:
	var on: bool = EchoManager.debug_visible
	visible = on
	layer.visible = on
	if not on:
		return
	queue_redraw()
	var lines: Array[String] = ["ECHO DEBUG (F3)   capacity %d   stored %d   recording %.1fs" % [
		EchoManager.capacity(), EchoManager.recordings.size(), EchoManager.recording_frames / 60.0]]
	for i in EchoManager.recordings.size():
		lines.append("  rec %d: %s" % [i, EchoManager.recordings[i].summary()])
	for e in EchoManager.active:
		if is_instance_valid(e):
			lines.append("  echo %d frame %d/%d %s%s" % [e.slot, e.frame, e.rec.frame_count(),
				"STALLED " if e.stalled_t > 0.0 else "", "concealed" if e.concealed else ""])
			for l in e.events_log.slice(-3):
				lines.append("     " + l)
	for g in get_tree().get_nodes_in_group("guards"):
		if g.level == world and g.global_position.distance_to(world.player.global_position) < 500.0:
			lines.append("  " + g.debug_text())
	label.text = "\n".join(lines)


func _draw() -> void:
	for e in EchoManager.active:
		if not is_instance_valid(e):
			continue
		var r: EchoRecording = e.rec
		var pts := PackedVector2Array()
		for i in range(0, r.frame_count(), 4):
			pts.append(r.positions[i])
		if pts.size() > 1:
			draw_polyline(pts, Color(0.3, 0.95, 1.0, 0.5), 1.0)
		for ev: Dictionary in r.events:
			var f := mini(int(ev.f), r.frame_count() - 1)
			var col := Color(0.3, 1.0, 1.0) if ev.type == "interact" else (Color(1, 0.9, 0.3, 0.5) if ev.type == "noise" else Color.WHITE)
			draw_circle(r.positions[f], 3.0 if ev.type != "noise" else 1.5, col)
		draw_arc(e.global_position, 10, 0, TAU, 16, Color(0.3, 1, 1), 1.5)
	for n: Dictionary in NoiseManager.recent:
		var age := (Time.get_ticks_msec() - int(n.t)) / 1000.0
		if age < 1.5:
			draw_arc(n.pos, n.r, 0, TAU, 48, Color(1, 0.9, 0.4, 0.4 * (1.0 - age / 1.5)), 1.0)
