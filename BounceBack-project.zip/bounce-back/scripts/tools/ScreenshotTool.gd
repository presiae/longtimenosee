extends Node
## Development capture helper. Inactive unless BB_SHOT is set.
##   BB_SHOT=path.png        save the viewport after BB_SHOT_FRAMES frames, then quit
##   BB_SHOT_FRAMES=90       frames to wait (default 90)
##   BB_SHOT_SCALE=3         integer upscale of the saved image (default 3)
##   BB_SHOT_SCRIPT=res://...gd  optional script whose run(tree) coroutine stages the shot
## Also: F12 saves a screenshot to user://screenshots during normal play.

var _frames := 0
var _target := 90
var _path := ""
var _scale := 3


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	_path = OS.get_environment("BB_SHOT")
	var stage := OS.get_environment("BB_SHOT_SCRIPT")
	if stage != "" and _path == "":
		var st: Object = load(stage).new()
		add_child(st)
		st.call_deferred("run", get_tree())
		return
	if _path == "":
		return
	var f := OS.get_environment("BB_SHOT_FRAMES")
	if f != "":
		_target = int(f)
	var s := OS.get_environment("BB_SHOT_SCALE")
	if s != "":
		_scale = int(s)
	var script_path := OS.get_environment("BB_SHOT_SCRIPT")
	if script_path != "":
		var stager: Object = load(script_path).new()
		add_child(stager)
		stager.call_deferred("run", get_tree())


func _process(_delta: float) -> void:
	if _path == "":
		return
	_frames += 1
	if _frames == _target:
		_save(_path)
		get_tree().quit()


func _unhandled_input(event: InputEvent) -> void:
	if event is InputEventKey and event.pressed and event.physical_keycode == KEY_F12:
		DirAccess.make_dir_recursive_absolute("user://screenshots")
		_save("user://screenshots/shot_%d.png" % Time.get_ticks_msec())


func _save(path: String) -> void:
	var img := get_viewport().get_texture().get_image()
	if _scale > 1:
		img.resize(img.get_width() * _scale, img.get_height() * _scale, Image.INTERPOLATE_NEAREST)
	img.save_png(path)
	print("screenshot saved: ", path)
