class_name LevelObject
extends Node2D
## Base for everything placed from a level file.
##
## Objects are wired together by id: an emitter's `output_changed(on)` is connected
## to each target's `set_input(source_id, on)`. A receiver becomes active when ANY
## (default) or ALL (`require_all`) of its inputs are on, optionally inverted.

signal output_changed(on: bool)

var object_id := ""
var level: Node   # the owning World (untyped to avoid a cyclic class reference)
var cell := Vector2i.ZERO
var config := {}
var require_all := false
var invert := false
var _inputs := {}
var _active := false
## Number of input sources wired in by the level (needed for require_all).
var expected_inputs := 0


## Called by the Level right after instancing, before _ready.
func setup(cfg: Dictionary, owner_level: Node) -> void:
	config = cfg
	level = owner_level
	object_id = str(cfg.get("id", ""))
	if cfg.has("cell"):
		cell = Vector2i(int(cfg.cell[0]), int(cfg.cell[1]))
	require_all = bool(cfg.get("require_all", false))
	invert = bool(cfg.get("invert", false))


func cfg(key: String, default: Variant = null) -> Variant:
	return config.get(key, default)


func register_input(source_id: String) -> void:
	expected_inputs += 1
	_inputs[source_id] = false


func set_input(source_id: String, on: bool) -> void:
	_inputs[source_id] = on
	var count := 0
	for v: bool in _inputs.values():
		if v:
			count += 1
	var active := (count >= maxi(1, expected_inputs)) if require_all else count > 0
	if invert:
		active = not active
	if active != _active:
		_active = active
		_on_active_changed(active)


func is_active() -> bool:
	return _active


## Override in receivers.
func _on_active_changed(_on: bool) -> void:
	pass


func emit_output(on: bool) -> void:
	output_changed.emit(on)


## Convenience for sound + noise (resolved lazily so objects work in isolation tests).
func make_noise(loudness: float, kind: String = "") -> void:
	var nm := get_node_or_null("/root/NoiseManager")
	if nm:
		nm.emit_noise(global_position, loudness, self, kind)


func play_sfx(sfx: String, volume_db := 0.0) -> void:
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.play_at(sfx, global_position, volume_db)
