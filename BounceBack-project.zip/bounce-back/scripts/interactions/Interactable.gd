class_name Interactable
extends LevelObject
## A LevelObject the player (and, if echo_compatible, an Echo) can use with [E].
## Creates its own detection Area2D on the "interactable" physics layer.

signal interacted(actor: Node)

const INTERACT_LAYER := 64  # layer 7

var prompt := "Use"
## Echoes may only trigger objects explicitly marked compatible.
var echo_compatible := false
var area: Area2D
var area_size := Vector2(36, 36)
var area_offset := Vector2(0, -10)


func _ready() -> void:
	area = Area2D.new()
	area.name = "InteractArea"
	area.collision_layer = INTERACT_LAYER
	area.collision_mask = 0
	area.monitoring = false
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = area_size
	cs.shape = r
	cs.position = area_offset
	area.add_child(cs)
	add_child(area)
	area.set_meta("interactable", self)


func can_interact(_actor: Node) -> bool:
	return true


## True for the Echo variant of an actor (Echo nodes are in group "echo").
static func is_echo(actor: Node) -> bool:
	return actor != null and actor.is_in_group("echo")


## Entry point used by players and echoes. Returns true if something happened.
func try_interact(actor: Node) -> bool:
	if is_echo(actor) and not echo_compatible:
		return false
	if not can_interact(actor):
		return false
	var am := get_node_or_null("/root/AudioManager")
	if am:
		am.echo_context = is_echo(actor)
	_interact(actor)
	if am:
		am.echo_context = false
	interacted.emit(actor)
	return true


func _interact(_actor: Node) -> void:
	pass


func get_prompt(_actor: Node) -> String:
	return prompt
