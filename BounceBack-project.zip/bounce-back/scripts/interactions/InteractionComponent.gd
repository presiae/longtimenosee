class_name InteractionComponent
extends Area2D
## Attached to the player. Tracks nearby Interactables, picks the closest usable one,
## and fires it on [E]. Emits `used(object_id)` so the Echo recorder can log it.

signal used(object_id: String)
signal focus_changed(target: Interactable)

var actor: Node
var target: Interactable
var _nearby: Array[Interactable] = []


func _ready() -> void:
	actor = get_parent()
	collision_layer = 0
	collision_mask = Interactable.INTERACT_LAYER
	monitorable = false
	var cs := CollisionShape2D.new()
	var r := CircleShape2D.new()
	r.radius = 22.0
	cs.shape = r
	cs.position = Vector2(0, -6)
	add_child(cs)
	area_entered.connect(_on_enter)
	area_exited.connect(_on_exit)


func _on_enter(a: Area2D) -> void:
	if a.has_meta("interactable"):
		_nearby.append(a.get_meta("interactable"))


func _on_exit(a: Area2D) -> void:
	if a.has_meta("interactable"):
		_nearby.erase(a.get_meta("interactable"))


func _physics_process(_delta: float) -> void:
	var best: Interactable = null
	var best_d := INF
	# While hidden, only the hiding spot itself is usable.
	if actor.is_hidden and actor.hiding_spot:
		best = actor.hiding_spot
	else:
		for it in _nearby:
			if not is_instance_valid(it) or not it.can_interact(actor):
				continue
			var d := it.global_position.distance_squared_to(actor.global_position)
			if d < best_d:
				best_d = d
				best = it
	if best != target:
		target = best
		focus_changed.emit(target)


## Returns true if something was used.
func interact() -> bool:
	if target == null or not is_instance_valid(target):
		return false
	var id := target.object_id
	if target.try_interact(actor):
		used.emit(id)
		return true
	return false
