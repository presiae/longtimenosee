extends Node
## Ending: dawn breaks outside the wall. The prisoner looks back, and every Echo that got
## them here appears behind them. Then the credits, and a way to play again.

const CREDITS_TEXT := preload("res://scripts/ui/CreditsText.gd")

var world: World
var ui: Control
var text: Label
var fade: ColorRect
var band: ColorRect


func _ready() -> void:
	world = World.new()
	world.attract_mode = true
	add_child(world)
	world.player.global_position = MapBuilder.cell_feet(Vector2i(70, 47))
	world.camera.reset_smoothing.call_deferred()
	world.canvas_mod.color = Color(0.12, 0.12, 0.2)
	create_tween().tween_property(world.canvas_mod, "color", Color(0.85, 0.66, 0.6), 9.0)
	AudioManager.base_intensity = 0.0
	AudioManager.set_ambience("amb_outside")

	# The prisoner, looking back at the prison.
	var p := AnimatedSprite2D.new()
	p.sprite_frames = SpriteLib.character_frames("td_prisoner")
	p.centered = false
	p.offset = Vector2(-16, -31)
	p.position = MapBuilder.cell_feet(Vector2i(70, 49))
	p.play("idle_up")
	world.entities.add_child(p)

	var cl := CanvasLayer.new()
	cl.layer = 20
	add_child(cl)
	ui = Control.new()
	ui.theme = UITheme.theme()
	ui.set_anchors_preset(Control.PRESET_FULL_RECT)
	cl.add_child(ui)
	fade = ColorRect.new()
	fade.color = Color(0, 0, 0, 1)
	fade.set_anchors_preset(Control.PRESET_FULL_RECT)
	fade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(fade)
	band = ColorRect.new()
	band.color = Color(0, 0, 0, 0.55)
	band.anchor_right = 1.0
	band.offset_top = 370
	band.offset_bottom = 450
	band.modulate.a = 0.0
	band.mouse_filter = Control.MOUSE_FILTER_IGNORE
	ui.add_child(band)
	text = UITheme.title_label("", 26, Color(1.0, 0.95, 0.88))
	text.anchor_right = 1.0
	text.offset_top = 380
	text.offset_bottom = 440
	text.modulate.a = 0.0
	ui.add_child(text)
	_run()


func _run() -> void:
	var tw := create_tween()
	tw.tween_property(fade, "color:a", 0.0, 2.5)
	await tw.finished
	await get_tree().create_timer(1.5).timeout
	# The Echoes appear behind, one by one.
	var spots := [Vector2i(68, 46), Vector2i(72, 46), Vector2i(66, 45), Vector2i(74, 45), Vector2i(70, 44)]
	var n := clampi(LevelManager.attempts_total, 3, spots.size())
	for i in n:
		var e := AnimatedSprite2D.new()
		e.sprite_frames = SpriteLib.character_frames("td_echo")
		e.centered = false
		e.offset = Vector2(-16, -31)
		e.position = MapBuilder.cell_feet(spots[i])
		var mat := ShaderMaterial.new()
		mat.shader = preload("res://shaders/echo.gdshader")
		mat.set_shader_parameter("seed", float(i))
		e.material = mat
		e.play("idle_down")
		e.modulate.a = 0.0
		world.entities.add_child(e)
		create_tween().tween_property(e, "modulate:a", 0.8, 1.5)
		AudioManager.play_ui("echo_spawn", -8.0)
		await get_tree().create_timer(0.9).timeout
	text.text = "EVERY TIME I FELL, I GOT CLOSER."
	var t2 := create_tween()
	t2.tween_property(text, "modulate:a", 1.0, 1.5)
	t2.parallel().tween_property(band, "modulate:a", 1.0, 1.5)
	t2.tween_interval(4.0)
	t2.tween_property(fade, "color:a", 1.0, 2.5)
	t2.parallel().tween_property(text, "modulate:a", 0.0, 2.0)
	t2.parallel().tween_property(band, "modulate:a", 0.0, 2.0)
	await t2.finished
	_credits()


func _credits() -> void:
	var roll := CREDITS_TEXT.make_roll(ui, "Escaped after %d attempts." % LevelManager.attempts_total)
	var tw := create_tween()
	tw.tween_property(roll, "position:y", -roll.size.y + 120.0, 26.0).from(560.0)
	await tw.finished
	var box := VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.offset_left = -130
	box.offset_top = 220
	box.add_theme_constant_override("separation", 10)
	ui.add_child(box)
	box.add_child(UITheme.title_label("THANK YOU FOR PLAYING", 22, UITheme.CYAN))
	var again := UITheme.button("Play Again", func() -> void:
		LevelManager.new_game()
		EchoManager.reset()
		SaveManager.save_progress()
		get_tree().change_scene_to_file("res://scenes/menus/Intro.tscn"))
	box.add_child(again)
	box.add_child(UITheme.button("Main Menu", func() -> void: get_tree().change_scene_to_file("res://scenes/menus/MainMenu.tscn")))
	again.grab_focus()
