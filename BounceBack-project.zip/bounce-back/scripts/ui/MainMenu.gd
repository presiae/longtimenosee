extends Node
## Title screen. The background is the real prison, live: guards patrol and lamps flicker
## while the camera drifts slowly across the map.

const INTRO := "res://scenes/menus/Intro.tscn"
const CREDITS := "res://scenes/menus/Credits.tscn"

var world: World
var ui: CanvasLayer
var menu: VBoxContainer
var _cam_t := 0.0
var _path: Array[Vector2] = []
var _settings_open := false


func _ready() -> void:
	world = World.new()
	world.attract_mode = true
	add_child(world)
	for c in [Vector2i(14, 11), Vector2i(31, 11), Vector2i(31, 27), Vector2i(60, 20), Vector2i(70, 38), Vector2i(31, 11)]:
		_path.append(MapBuilder.cell_feet(c))
	AudioManager.start_music()
	AudioManager.base_intensity = 0.0
	AudioManager.set_ambience("amb_block")

	ui = CanvasLayer.new()
	ui.layer = 20
	add_child(ui)
	var root := Control.new()
	root.theme = UITheme.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	ui.add_child(root)
	var shade := ColorRect.new()
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	shade.color = Color(0, 0, 0, 0.35)
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(shade)

	var title := UITheme.title_label("BOUNCE BACK", 72, Color(0.9, 0.96, 1.0))
	title.anchor_right = 1.0
	title.offset_top = 70
	title.offset_bottom = 160
	root.add_child(title)
	var sub := UITheme.title_label("EVERY FAILURE LEAVES SOMETHING BEHIND.", 16, UITheme.CYAN)
	sub.anchor_right = 1.0
	sub.offset_top = 160
	sub.offset_bottom = 190
	root.add_child(sub)
	var tw := create_tween().set_loops()
	tw.tween_property(title, "modulate", Color(0.75, 1.0, 1.0), 1.6)
	tw.tween_property(title, "modulate", Color.WHITE, 1.6)

	menu = VBoxContainer.new()
	menu.add_theme_constant_override("separation", 8)
	menu.anchor_left = 0.5
	menu.anchor_right = 0.5
	menu.offset_left = -130
	menu.offset_right = 130
	menu.offset_top = 215
	root.add_child(menu)
	var has_save := SaveManager.has_save() and SaveManager.load_progress() and (LevelManager.checkpoint > 0 or LevelManager.attempts_total > 0)
	var cont := UITheme.button("Continue", _continue)
	cont.disabled = not has_save
	menu.add_child(cont)
	menu.add_child(UITheme.button("New Game", _new_game))
	menu.add_child(UITheme.button("Settings", _settings))
	menu.add_child(UITheme.button("Credits", func() -> void: get_tree().change_scene_to_file(CREDITS)))
	menu.add_child(UITheme.button("Quit", func() -> void: get_tree().quit()))
	(cont if has_save else menu.get_child(1)).call_deferred("grab_focus")

	var foot := UITheme.body_label("WASD move   E interact   Shift run   Ctrl sneak   R bounce back", 14, Color(0.55, 0.6, 0.7))
	foot.anchor_top = 1.0
	foot.anchor_bottom = 1.0
	foot.anchor_right = 1.0
	foot.offset_top = -34
	foot.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	root.add_child(foot)


func _process(delta: float) -> void:
	_cam_t += delta * 0.035
	var seg := int(_cam_t) % (_path.size() - 1)
	var k := smoothstep(0.0, 1.0, fmod(_cam_t, 1.0))
	world.player.global_position = _path[seg].lerp(_path[seg + 1], k)


func _new_game() -> void:
	LevelManager.new_game()
	EchoManager.reset()
	SaveManager.save_progress()
	get_tree().change_scene_to_file(INTRO)


func _continue() -> void:
	SaveManager.load_progress()
	EchoManager.reset()
	LevelManager.start_game()


func _settings() -> void:
	if _settings_open:
		return
	_settings_open = true
	menu.visible = false
	var s := SettingsPanel.new()
	s.anchor_left = 0.5
	s.anchor_top = 0.5
	s.anchor_right = 0.5
	s.anchor_bottom = 0.5
	ui.get_child(0).add_child(s)
	s.closed.connect(func() -> void:
		_settings_open = false
		menu.visible = true
		menu.get_child(1).grab_focus())
