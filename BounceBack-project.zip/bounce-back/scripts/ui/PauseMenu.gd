class_name PauseMenu
extends CanvasLayer
## Esc: Resume, Restart attempt, Settings, Main menu.

var game: Node
var root: Control
var box: VBoxContainer


func _ready() -> void:
	layer = 40
	process_mode = Node.PROCESS_MODE_ALWAYS
	root = Control.new()
	root.theme = UITheme.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(root)
	var shade := ColorRect.new()
	shade.color = Color(0, 0, 0, 0.6)
	shade.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.add_child(shade)
	box = VBoxContainer.new()
	box.anchor_left = 0.5
	box.anchor_right = 0.5
	box.offset_left = -130
	box.offset_right = 130
	box.offset_top = 150
	box.add_theme_constant_override("separation", 10)
	root.add_child(box)
	box.add_child(UITheme.title_label("PAUSED", 34, UITheme.CYAN))
	var resume := UITheme.button("Resume", close)
	box.add_child(resume)
	box.add_child(UITheme.button("Restart attempt (R)", func() -> void:
		close()
		game.restart_attempt("restart")))
	box.add_child(UITheme.button("Dissolve Echoes (X)", func() -> void:
		EchoManager.clear_all()
		close()))
	box.add_child(UITheme.button("Settings", _settings))
	box.add_child(UITheme.button("Main Menu", func() -> void:
		get_tree().paused = false
		SaveManager.save_progress()
		get_tree().change_scene_to_file("res://scenes/menus/MainMenu.tscn")))
	visible = false


func open() -> void:
	visible = true
	box.visible = true
	get_tree().paused = true
	box.get_child(1).grab_focus()


func close() -> void:
	visible = false
	get_tree().paused = false


func _settings() -> void:
	box.visible = false
	var s := SettingsPanel.new()
	s.anchor_left = 0.5
	s.anchor_top = 0.5
	s.anchor_right = 0.5
	s.anchor_bottom = 0.5
	root.add_child(s)
	s.closed.connect(func() -> void:
		box.visible = true
		box.get_child(1).grab_focus())


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause"):
		get_viewport().set_input_as_handled()
		if visible and box.visible:
			close()
		elif not visible:
			open()
