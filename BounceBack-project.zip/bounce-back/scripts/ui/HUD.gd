class_name HUD
extends CanvasLayer
## Minimal, atmospheric HUD: zone + objective (top-left), Echo slots (top-right), detection
## eye, interaction prompt and hints (bottom), caught / alarm flashes, note reader.

var _world: Node
var _game: Node
var zone_label: Label
var objective: Label
var prompt: Label
var hint: Label
var banner: Label
var held: Label
var flash: ColorRect
var center_msg: Label
var echo_panel: EchoSlots
var detect: DetectionEye
var note_panel: PanelContainer
var note_title: Label
var note_text: Label
var _hint_text := ""


var story: VBoxContainer
var story_title: Label
var story_body: Label
var black: ColorRect


func _ready() -> void:
	layer = 10
	process_mode = Node.PROCESS_MODE_ALWAYS
	add_to_group("hud")
	var root := Control.new()
	root.theme = UITheme.theme()
	root.set_anchors_preset(Control.PRESET_FULL_RECT)
	root.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(root)
	flash = ColorRect.new()
	flash.set_anchors_preset(Control.PRESET_FULL_RECT)
	flash.color = Color(0.8, 0.05, 0.05, 0.0)
	flash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(flash)

	zone_label = _label(root, Vector2(18, 12), 14, Color(0.55, 0.9, 1.0))
	objective = _label(root, Vector2(18, 32), 16, Color(0.9, 0.92, 0.96))
	held = _label(root, Vector2(18, 54), 13, Color(0.6, 1.0, 0.75))
	prompt = _label(root, Vector2.ZERO, 16, Color(1.0, 0.92, 0.6))
	_bottom(prompt, -78)
	hint = _label(root, Vector2.ZERO, 14, Color(0.75, 0.8, 0.9))
	_bottom(hint, -46)
	hint.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	banner = _label(root, Vector2.ZERO, 34, Color(0.85, 0.95, 1.0))
	_wide(banner, 96.0, 50.0)
	banner.modulate.a = 0.0
	center_msg = _label(root, Vector2.ZERO, 40, Color(1.0, 0.3, 0.3))
	_wide(center_msg, 200.0, 140.0)
	center_msg.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	center_msg.modulate.a = 0.0

	echo_panel = EchoSlots.new()
	echo_panel.anchor_left = 1.0
	echo_panel.anchor_right = 1.0
	echo_panel.offset_left = -190
	echo_panel.offset_right = -14
	echo_panel.offset_top = 14
	echo_panel.offset_bottom = 54
	root.add_child(echo_panel)
	detect = DetectionEye.new()
	detect.anchor_left = 1.0
	detect.anchor_right = 1.0
	detect.offset_left = -62
	detect.offset_right = -18
	detect.offset_top = 66
	detect.offset_bottom = 90
	root.add_child(detect)

	note_panel = PanelContainer.new()
	note_panel.anchor_left = 0.5
	note_panel.anchor_right = 0.5
	note_panel.anchor_top = 0.5
	note_panel.anchor_bottom = 0.5
	note_panel.offset_left = -240
	note_panel.offset_right = 240
	note_panel.offset_top = -120
	note_panel.offset_bottom = 120
	note_panel.process_mode = Node.PROCESS_MODE_ALWAYS
	var sb := StyleBoxFlat.new()
	sb.bg_color = Color(0.85, 0.8, 0.66, 0.97)
	sb.border_color = Color(0.3, 0.24, 0.16)
	sb.set_border_width_all(3)
	sb.set_content_margin_all(18)
	note_panel.add_theme_stylebox_override("panel", sb)
	var vb := VBoxContainer.new()
	note_panel.add_child(vb)
	note_title = Label.new()
	note_title.add_theme_font_size_override("font_size", 20)
	note_title.add_theme_color_override("font_color", Color(0.25, 0.15, 0.1))
	vb.add_child(note_title)
	note_text = Label.new()
	note_text.add_theme_font_size_override("font_size", 16)
	note_text.add_theme_color_override("font_color", Color(0.2, 0.15, 0.12))
	note_text.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	note_text.custom_minimum_size = Vector2(420, 0)
	vb.add_child(note_text)
	var close := Label.new()
	close.text = "[E] close"
	close.add_theme_font_size_override("font_size", 13)
	close.add_theme_color_override("font_color", Color(0.4, 0.3, 0.2))
	vb.add_child(close)
	note_panel.visible = false
	root.add_child(note_panel)

	black = ColorRect.new()
	black.set_anchors_preset(Control.PRESET_FULL_RECT)
	black.color = Color(0, 0, 0, 0)
	black.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(black)
	story = VBoxContainer.new()
	story.anchor_right = 1.0
	story.offset_top = 170
	story.offset_left = 80
	story.offset_right = -80
	story.add_theme_constant_override("separation", 14)
	story.modulate.a = 0.0
	story.mouse_filter = Control.MOUSE_FILTER_IGNORE
	root.add_child(story)
	story_title = UITheme.title_label("", 30, Color(0.45, 0.95, 1.0))
	story.add_child(story_title)
	story_body = UITheme.body_label("", 18, Color(0.85, 0.9, 0.96))
	story_body.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	story.add_child(story_body)
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.item_collected.connect(_on_item)
		lm.checkpoint_reached.connect(func(_i: int) -> void: show_banner("CHECKPOINT  -  ECHOES RELEASED", Color(0.5, 0.95, 1.0)))


func _label(parent: Control, pos: Vector2, size: int, col: Color) -> Label:
	var l := Label.new()
	l.position = pos
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.85))
	l.add_theme_constant_override("shadow_offset_x", 2)
	l.add_theme_constant_override("shadow_offset_y", 2)
	l.mouse_filter = Control.MOUSE_FILTER_IGNORE
	parent.add_child(l)
	return l


## Full-width label pinned at a vertical offset (negative = from the bottom edge).
func _bottom(l: Label, y: float) -> void:
	_wide(l, y, 30.0)


func _wide(l: Label, y: float, h: float) -> void:
	l.anchor_left = 0.0
	l.anchor_right = 1.0
	l.anchor_top = 1.0 if y < 0.0 else 0.0
	l.anchor_bottom = l.anchor_top
	l.offset_left = 60.0
	l.offset_right = -60.0
	l.offset_top = y
	l.offset_bottom = y + h
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER


func bind_world(world: Node, game: Node) -> void:
	_world = world
	_game = game
	hint.text = ""
	_hint_text = ""
	prompt.text = ""
	world.player.interaction.focus_changed.connect(_on_focus)
	world.zone_changed.connect(_on_zone)
	_on_zone(world.current_zone)
	detect.world = world
	echo_panel.game = game


func _on_zone(z: Dictionary) -> void:
	if z.is_empty():
		return
	var changed: bool = zone_label.text != str(z.title)
	zone_label.text = str(z.title)
	objective.text = str(z.objective)
	if changed:
		show_banner(str(z.title), Color(0.85, 0.95, 1.0))


func _on_focus(t: Interactable) -> void:
	if t == null or not is_instance_valid(_world) or not is_instance_valid(_world.player):
		prompt.text = ""
	else:
		prompt.text = "[E]  " + t.get_prompt(_world.player)


func _process(_delta: float) -> void:
	if is_instance_valid(_world) and is_instance_valid(_world.player):
		held.text = "Holding: bottle  [Q] throw" if _world.player.held_item != "" else ""
	if note_panel.visible and Input.is_action_just_pressed("interact"):
		note_panel.visible = false
		get_tree().paused = false


func show_hint(t: String) -> void:
	_hint_text = t
	hint.text = t


func hide_hint(t: String) -> void:
	if _hint_text == t:
		_hint_text = ""
		hint.text = ""


func show_banner(text: String, col: Color) -> void:
	banner.text = text
	banner.add_theme_color_override("font_color", col)
	var tw := create_tween()
	tw.tween_property(banner, "modulate:a", 1.0, 0.4)
	tw.tween_interval(1.8)
	tw.tween_property(banner, "modulate:a", 0.0, 0.8)


func fade_in_from_black(t: float) -> void:
	black.color.a = 1.0
	create_tween().tween_property(black, "color:a", 0.0, t)


## Big story text over a darkened screen (the game keeps running underneath).
func story_card(title: String, body: String, hold: float) -> void:
	story_title.add_theme_font_size_override("font_size", 30)
	story_title.text = title
	story_body.text = body
	var tw := create_tween()
	tw.tween_property(black, "color:a", 0.55, 0.4)
	tw.parallel().tween_property(story, "modulate:a", 1.0, 0.8)
	tw.tween_interval(hold)
	tw.tween_property(story, "modulate:a", 0.0, 1.0)
	tw.parallel().tween_property(black, "color:a", 0.0, 1.0)


func title_card(title: String, sub: String) -> void:
	story_title.add_theme_font_size_override("font_size", 64)
	story_title.text = title
	story_body.text = sub
	var tw := create_tween()
	tw.tween_property(story, "modulate:a", 1.0, 1.2)
	tw.tween_interval(3.5)
	tw.tween_property(story, "modulate:a", 0.0, 1.5)


func flash_caught(reason: String) -> void:
	center_msg.text = "CAUGHT\n" + reason.to_upper()
	center_msg.add_theme_font_size_override("font_size", 30)
	var tw := create_tween()
	flash.color.a = 0.45
	center_msg.modulate.a = 1.0
	tw.tween_property(flash, "color:a", 0.0, 1.2)
	tw.parallel().tween_property(center_msg, "modulate:a", 0.0, 1.4).set_delay(0.6)


func flash_alarm() -> void:
	show_banner("ALARM", Color(1.0, 0.3, 0.3))
	var tw := create_tween()
	flash.color.a = 0.18
	tw.tween_property(flash, "color:a", 0.0, 0.6)


func _on_item(_id: String, data: Dictionary) -> void:
	if data.has("note"):
		note_title.text = str(data.title)
		note_text.text = str(data.text)
		note_panel.visible = true
		get_tree().paused = true
	elif data.has("shard"):
		show_banner("ECHO SHARD  -  ONE MORE ECHO", Color(0.4, 1.0, 1.0))
	elif data.has("key"):
		show_banner("%s KEYCARD" % str(data.key).to_upper(), Color(1.0, 0.5, 0.5))


## Echo slots: filled cyan diamonds = recorded Echoes, hollow = free capacity.
class EchoSlots:
	extends Control
	var game: Node

	func _process(_d: float) -> void:
		queue_redraw()

	func _draw() -> void:
		var lm := get_node_or_null("/root/LevelManager")
		var cap: int = lm.echo_capacity() if lm else 1
		var used := 0
		var em := get_node_or_null("/root/EchoManager")
		if em:
			used = em.recordings.size()
		var f := ThemeDB.fallback_font
		draw_string(f, Vector2(0, 14), "ECHOES", HORIZONTAL_ALIGNMENT_LEFT, -1, 12, Color(0.5, 0.85, 0.95))
		for i in cap:
			var c := Vector2(76 + i * 30, 10)
			var pts := PackedVector2Array([c + Vector2(0, -9), c + Vector2(8, 0), c + Vector2(0, 9), c + Vector2(-8, 0)])
			if i < used:
				draw_colored_polygon(pts, Color(0.35, 0.95, 1.0, 0.95))
			else:
				pts.append(pts[0])
				draw_polyline(pts, Color(0.35, 0.95, 1.0, 0.6), 1.5)
		if em and em.recording_frames > 0:
			draw_string(f, Vector2(0, 34), "REC %.1fs" % (em.recording_frames / 60.0), HORIZONTAL_ALIGNMENT_LEFT, -1, 11, Color(1, 0.4, 0.4, 0.8))


## Detection eye: closed when unseen, opening/colouring with the most alert guard.
class DetectionEye:
	extends Control
	var world: Node

	func _process(_d: float) -> void:
		queue_redraw()

	func _draw() -> void:
		var level := 0.0
		var col := Color(0.6, 0.65, 0.75, 0.6)
		if is_instance_valid(world):
			for g in get_tree().get_nodes_in_group("guards"):
				if g.level != world:
					continue
				var s: int = g.fsm.state
				if s == GuardStateMachine.S.CHASE:
					level = 1.0
					col = GuardStateMachine.COLORS[s]
				elif g.suspicion > level or s in [GuardStateMachine.S.INVESTIGATE, GuardStateMachine.S.SEARCH]:
					level = maxf(level, maxf(g.suspicion, 0.5 if s != GuardStateMachine.S.PATROL and s != GuardStateMachine.S.RETURN else 0.0))
					if level > 0.05:
						col = GuardStateMachine.COLORS[s]
		var c := Vector2(22, 12)
		var open := 2.0 + level * 8.0
		var pts := PackedVector2Array()
		for i in 17:
			var t := float(i) / 16.0 * PI
			pts.append(c + Vector2(cos(t) * 18, sin(t) * open))
		for i in 17:
			var t := PI + float(i) / 16.0 * PI
			pts.append(c + Vector2(cos(t) * 18, sin(t) * open))
		draw_polyline(pts, col, 2.0)
		if level > 0.1:
			draw_circle(c, 2.0 + level * 3.0, col)
