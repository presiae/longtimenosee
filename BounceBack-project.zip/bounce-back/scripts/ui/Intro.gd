extends Control
## Opening: black screen, prison sounds, slow text. Skippable once you've seen it.

const LINES := [
	["THE FIRST TIME, I RAN.", 3.2],
	["THEY CAUGHT ME BEFORE I REACHED THE WALL.", 3.6],
	["THE SECOND TIME, I WAS SMARTER.", 3.0],
]

var label: Label
var skip_hint: Label
var _skippable := false
var _done := false


func _ready() -> void:
	theme = UITheme.theme()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	label = UITheme.title_label("", 26, Color(0.85, 0.88, 0.95))
	label.set_anchors_preset(Control.PRESET_FULL_RECT)
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.modulate.a = 0.0
	add_child(label)
	_skippable = bool(SaveManager.meta.get("intro_seen", false))
	skip_hint = UITheme.body_label("Enter / Esc to skip" if _skippable else "", 14, Color(0.4, 0.45, 0.55))
	skip_hint.anchor_top = 1.0
	skip_hint.anchor_bottom = 1.0
	skip_hint.anchor_right = 1.0
	skip_hint.offset_top = -30
	skip_hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	add_child(skip_hint)
	AudioManager.stop_music()
	AudioManager.set_ambience("amb_cell")
	_run()


func _run() -> void:
	await get_tree().create_timer(0.8).timeout
	AudioManager.play_ui("step", 6.0)
	await get_tree().create_timer(0.45).timeout
	AudioManager.play_ui("step2", 6.0)
	await get_tree().create_timer(0.45).timeout
	AudioManager.play_ui("step", 6.0)
	await get_tree().create_timer(0.6).timeout
	AudioManager.play_ui("bang", -2.0)        # a heavy door closes
	await get_tree().create_timer(0.7).timeout
	AudioManager.play_ui("metal", -4.0)       # keys
	await get_tree().create_timer(0.25).timeout
	AudioManager.play_ui("metal", -6.0)
	for l: Array in LINES:
		if _done:
			return
		label.text = l[0]
		var tw := create_tween()
		tw.tween_property(label, "modulate:a", 1.0, 1.0)
		tw.tween_interval(float(l[1]))
		tw.tween_property(label, "modulate:a", 0.0, 0.8)
		await tw.finished
	_finish()


func _finish() -> void:
	if _done:
		return
	_done = true
	SaveManager.mark_intro_seen()
	LevelManager.start_game()


func _unhandled_input(event: InputEvent) -> void:
	if _skippable and (event.is_action_pressed("pause") or event.is_action_pressed("ui_accept")):
		_finish()
