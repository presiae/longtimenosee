extends Control
## Credits screen from the main menu.

const CREDITS_TEXT := preload("res://scripts/ui/CreditsText.gd")


func _ready() -> void:
	theme = UITheme.theme()
	set_anchors_preset(Control.PRESET_FULL_RECT)
	var bg := ColorRect.new()
	bg.color = Color(0.02, 0.025, 0.045)
	bg.set_anchors_preset(Control.PRESET_FULL_RECT)
	add_child(bg)
	var roll := CREDITS_TEXT.make_roll(self)
	roll.position.y = 40
	var back := UITheme.button("Back", func() -> void: get_tree().change_scene_to_file("res://scenes/menus/MainMenu.tscn"))
	back.anchor_left = 0.5
	back.anchor_right = 0.5
	back.anchor_top = 1.0
	back.anchor_bottom = 1.0
	back.offset_left = -130
	back.offset_right = 130
	back.offset_top = -64
	back.offset_bottom = -24
	add_child(back)
	back.grab_focus()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") or event.is_action_pressed("ui_cancel"):
		get_tree().change_scene_to_file("res://scenes/menus/MainMenu.tscn")
