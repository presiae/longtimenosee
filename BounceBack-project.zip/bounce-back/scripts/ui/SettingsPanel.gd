class_name SettingsPanel
extends PanelContainer
## Volume sliders, fullscreen, window size, screen shake and the controls list.
## Every change is applied immediately and saved.

signal closed


func _ready() -> void:
	theme = UITheme.theme()
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_preset(Control.PRESET_CENTER)
	custom_minimum_size = Vector2(620, 0)
	var vb := VBoxContainer.new()
	vb.add_theme_constant_override("separation", 10)
	add_child(vb)
	vb.add_child(UITheme.title_label("SETTINGS", 26, UITheme.CYAN))
	for row: Array in [["Master volume", "master_volume"], ["Music volume", "music_volume"], ["Effects volume", "sfx_volume"]]:
		vb.add_child(_slider(row[0], row[1]))
	vb.add_child(_check("Fullscreen", "fullscreen"))
	vb.add_child(_check("Screen shake", "screen_shake"))
	var res := HBoxContainer.new()
	var rl := UITheme.body_label("Window size")
	rl.custom_minimum_size = Vector2(200, 0)
	res.add_child(rl)
	var ob := OptionButton.new()
	for s: Vector2i in SaveManager.WINDOW_SIZES:
		ob.add_item("%d x %d" % [s.x, s.y])
	ob.selected = int(SaveManager.get_setting("window_scale"))
	ob.item_selected.connect(func(i: int) -> void: SaveManager.set_setting("window_scale", i))
	res.add_child(ob)
	vb.add_child(res)
	vb.add_child(UITheme.title_label("CONTROLS", 18, UITheme.CYAN))
	var grid := GridContainer.new()
	grid.columns = 2
	grid.add_theme_constant_override("h_separation", 24)
	for d: Array in InputSetup.DESCRIPTIONS:
		grid.add_child(UITheme.body_label(d[0], 15, UITheme.CYAN))
		grid.add_child(UITheme.body_label(d[1], 15))
	vb.add_child(grid)
	var back := UITheme.button("Back", func() -> void:
		closed.emit()
		queue_free())
	vb.add_child(back)
	back.call_deferred("grab_focus")
	reset_size()
	position = -size * 0.5


func _slider(label: String, key: String) -> Control:
	var h := HBoxContainer.new()
	var l := UITheme.body_label(label)
	l.custom_minimum_size = Vector2(200, 0)
	h.add_child(l)
	var s := HSlider.new()
	s.min_value = 0.0
	s.max_value = 1.0
	s.step = 0.05
	s.value = float(SaveManager.get_setting(key))
	s.custom_minimum_size = Vector2(320, 24)
	s.value_changed.connect(func(v: float) -> void: SaveManager.set_setting(key, v))
	h.add_child(s)
	return h


func _check(label: String, key: String) -> Control:
	var c := CheckButton.new()
	c.text = label
	c.button_pressed = bool(SaveManager.get_setting(key))
	c.toggled.connect(func(v: bool) -> void: SaveManager.set_setting(key, v))
	return c


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("pause") or event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		closed.emit()
		queue_free()
