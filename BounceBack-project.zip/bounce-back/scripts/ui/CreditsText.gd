extends RefCounted
## Credits content shared by the ending roll and the Credits screen (mirrors ASSET_CREDITS.md).

const SECTIONS := [
	["BOUNCE BACK", []],
	["Design, code, pixel art, music & sound design", ["Original work created for this project"]],
	["Engine", ["Godot Engine 4.7 (MIT)"]],
	["Fonts", ["Silkscreen by Jason Kottke - SIL Open Font License 1.1",
		"Pixelify Sans by Stefie Justprince - SIL Open Font License 1.1"]],
	["Sound effects", ["RPG Sound Pack by artisticdude (OpenGameArt.org) - CC0",
		"Footsteps, doors, alarms, Echo shimmer, ambience and music:", "synthesised for this game (tools/audio/make_audio.py)"]],
	["Tools", ["pixelstudio.py from pixel-art-studio by Gamezxz - MIT"]],
	["", ["You don't escape by being faster.", "You escape by learning from your failures."]],
]


static func make_roll(parent: Control, header := "") -> VBoxContainer:
	var vb := VBoxContainer.new()
	vb.anchor_left = 0.0
	vb.anchor_right = 1.0
	vb.add_theme_constant_override("separation", 6)
	parent.add_child(vb)
	if header != "":
		vb.add_child(UITheme.title_label(header, 18, UITheme.CYAN))
		vb.add_child(_gap(30))
	for s: Array in SECTIONS:
		if s[0] != "":
			vb.add_child(UITheme.title_label(s[0], 34 if s[0] == "BOUNCE BACK" else 18, UITheme.TEXT if s[0] == "BOUNCE BACK" else UITheme.CYAN))
		for line: String in s[1]:
			var l := UITheme.body_label(line, 17)
			l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
			vb.add_child(l)
		vb.add_child(_gap(26))
	vb.reset_size()
	return vb


static func _gap(h: int) -> Control:
	var c := Control.new()
	c.custom_minimum_size = Vector2(0, h)
	return c
