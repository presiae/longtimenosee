class_name UITheme
extends RefCounted
## One consistent font system: Silkscreen for display titles, Pixelify Sans for menus,
## HUD and story text. Dark panels, cyan accents (the Echo colour).

const TITLE_FONT := "res://assets/fonts/Silkscreen-Bold.ttf"
const TITLE_FONT_REGULAR := "res://assets/fonts/Silkscreen-Regular.ttf"
const BODY_FONT := "res://assets/fonts/PixelifySans.ttf"
const CYAN := Color(0.35, 0.95, 1.0)
const INK := Color(0.03, 0.04, 0.07)
const TEXT := Color(0.86, 0.9, 0.96)

static var _theme: Theme


static func theme() -> Theme:
	if _theme:
		return _theme
	var t := Theme.new()
	t.default_font = load(BODY_FONT)
	t.default_font_size = 18
	var normal := _box(Color(0.06, 0.08, 0.12, 0.92), Color(0.22, 0.28, 0.38))
	var hover := _box(Color(0.08, 0.16, 0.2, 0.95), CYAN)
	var pressed := _box(Color(0.1, 0.25, 0.3, 1.0), CYAN)
	var disabled := _box(Color(0.05, 0.06, 0.08, 0.7), Color(0.15, 0.17, 0.2))
	for s in ["normal", "hover", "pressed", "disabled", "focus"]:
		t.set_stylebox(s, "Button", {"normal": normal, "hover": hover, "pressed": pressed, "disabled": disabled, "focus": hover}[s])
	t.set_color("font_color", "Button", TEXT)
	t.set_color("font_hover_color", "Button", CYAN)
	t.set_color("font_focus_color", "Button", CYAN)
	t.set_color("font_pressed_color", "Button", Color.WHITE)
	t.set_color("font_disabled_color", "Button", Color(0.4, 0.43, 0.5))
	t.set_font_size("font_size", "Button", 20)
	t.set_color("font_color", "Label", TEXT)
	t.set_stylebox("panel", "PanelContainer", _box(Color(0.03, 0.04, 0.07, 0.94), Color(0.2, 0.26, 0.36), 18))
	var grab := StyleBoxFlat.new()
	grab.bg_color = CYAN
	t.set_stylebox("slider", "HSlider", _box(Color(0.12, 0.15, 0.2), Color(0.2, 0.26, 0.36), 2))
	t.set_stylebox("grabber_area", "HSlider", grab)
	t.set_stylebox("grabber_area_highlight", "HSlider", grab)
	_theme = t
	return t


static func _box(bg: Color, border: Color, margin := 10) -> StyleBoxFlat:
	var s := StyleBoxFlat.new()
	s.bg_color = bg
	s.border_color = border
	s.set_border_width_all(2)
	s.set_content_margin_all(margin)
	s.content_margin_left = margin + 8
	s.content_margin_right = margin + 8
	return s


static func title_label(text: String, size: int, col := TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_override("font", load(TITLE_FONT))
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.add_theme_color_override("font_shadow_color", Color(0, 0, 0, 0.9))
	l.add_theme_constant_override("shadow_offset_x", 3)
	l.add_theme_constant_override("shadow_offset_y", 3)
	l.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	return l


static func body_label(text: String, size := 18, col := TEXT) -> Label:
	var l := Label.new()
	l.text = text
	l.add_theme_font_size_override("font_size", size)
	l.add_theme_color_override("font_color", col)
	l.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	return l


static func button(text: String, cb: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(260, 40)
	b.pressed.connect(func() -> void:
		var am: Node = (Engine.get_main_loop() as SceneTree).root.get_node_or_null("AudioManager")
		if am:
			am.play_ui("ui_accept", -6.0)
		cb.call())
	b.focus_entered.connect(func() -> void:
		var am: Node = (Engine.get_main_loop() as SceneTree).root.get_node_or_null("AudioManager")
		if am:
			am.play_ui("ui_move", -14.0))
	return b
