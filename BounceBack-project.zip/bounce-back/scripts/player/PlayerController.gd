class_name PlayerController
extends CharacterBody2D
## The prisoner, top-down. 8-way movement with acceleration, run (loud) and sneak (silent,
## harder to spot). Origin is at the feet so characters depth-sort correctly.

signal interacted(object_id: String)
signal threw(origin: Vector2, target: Vector2)
signal noise_made(loudness: float, kind: String)
signal anim_changed(anim: String)

const WALK_SPEED := 82.0
const RUN_SPEED := 138.0
const SNEAK_SPEED := 44.0
const ACCEL := 900.0
const DECEL := 1100.0
const THROW_RANGE := 150.0

const NOISE_WALK := 0.16
const NOISE_RUN := 0.42

var facing := Vector2.DOWN
var sneaking := false
var running := false
var controls_enabled := true
var manual_step := false
## Test/demo hook: when set, replaces keyboard input. {"move": Vector2, "sneak": bool, "run": bool}
var bot_input: Variant = null
var is_hidden := false          # inside a locker / bed
var hiding_spot: Node = null
var in_vent := false            # standing in a dark crawlspace
var held_item := ""
var anim := "idle_down"
var caught := false
var _lock_anim := ""
var _lock_t := 0.0
var _step_accum := 0.0

@onready var sprite: AnimatedSprite2D = $Sprite
@onready var interaction: InteractionComponent = $Interaction


func _ready() -> void:
	sprite.sprite_frames = SpriteLib.character_frames("td_prisoner")
	sprite.centered = false
	sprite.offset = Vector2(-16, -31)
	sprite.play("idle_down")


func _physics_process(delta: float) -> void:
	if manual_step:
		return
	var input := Vector2.ZERO
	var want_sneak := false
	var want_run := false
	if bot_input is Dictionary:
		input = bot_input.get("move", Vector2.ZERO)
		want_sneak = bot_input.get("sneak", false)
		want_run = bot_input.get("run", false)
	elif controls_enabled and not caught:
		input = Input.get_vector("move_left", "move_right", "move_up", "move_down")
		want_sneak = Input.is_action_pressed("crouch")
		want_run = Input.is_action_pressed("run")
		if Input.is_action_just_pressed("interact"):
			try_interact()
		if Input.is_action_just_pressed("throw"):
			throw_item()
	step(delta, input, want_sneak, want_run)


## One simulation step (split out so tests can drive it deterministically).
func step(delta: float, input: Vector2, want_sneak: bool, want_run: bool) -> void:
	if is_hidden or caught:
		velocity = Vector2.ZERO
		_update_anim()
		return
	if input.length() > 1.0:
		input = input.normalized()
	sneaking = want_sneak
	running = want_run and not sneaking and input.length() > 0.1
	var speed := SNEAK_SPEED if sneaking else (RUN_SPEED if running else WALK_SPEED)
	var target := input * speed
	var rate := ACCEL if input.length() > 0.05 else DECEL
	velocity = velocity.move_toward(target, rate * delta)
	if input.length() > 0.1:
		facing = input.normalized()
	move_and_slide()

	# Footsteps make noise; sneaking is silent.
	var spd := velocity.length()
	if spd > 10.0 and not sneaking:
		_step_accum += spd * delta
		var stride := 30.0 if running else 26.0
		if _step_accum >= stride:
			_step_accum -= stride
			var loud := NOISE_RUN if running else NOISE_WALK
			if in_vent:
				loud *= 0.5
			make_noise(loud, "step_run" if running else "step")
	else:
		_step_accum = 0.0
	if _lock_t > 0.0:
		_lock_t -= delta
		if _lock_t <= 0.0:
			_lock_anim = ""
	_update_anim()


func make_noise(loudness: float, kind: String) -> void:
	noise_made.emit(loudness, kind)
	var am := get_node_or_null("/root/AudioManager")
	if am and kind.begins_with("step"):
		am.play_at(kind if kind == "step_run" else ("step" if randf() < 0.5 else "step2"), global_position, -2.0)
	var nm := get_node_or_null("/root/NoiseManager")
	if nm:
		nm.emit_noise(global_position, loudness, self, kind)


func _update_anim() -> void:
	var d: Array = SpriteLib.dir_anim(facing)
	var base := "idle"
	if caught:
		base = "caught"
	elif _lock_anim != "":
		base = _lock_anim
	elif velocity.length() > 8.0:
		base = "sneak" if sneaking else ("run" if running else "walk")
	elif sneaking:
		base = "sneakidle"
	var a := "%s_%s" % [base, d[0]]
	sprite.flip_h = d[1]
	if a != anim:
		anim = a
		sprite.play(a)
		anim_changed.emit(a)


func play_action(action: String, t: float) -> void:
	_lock_anim = action
	_lock_t = t


func try_interact() -> bool:
	if interaction and interaction.interact():
		if not is_hidden:
			play_action("interact", 0.25)
		return true
	return false


## Throw the held bottle where you're facing; it lands and shatters loudly.
func throw_item() -> bool:
	if held_item == "" or is_hidden:
		return false
	held_item = ""
	var origin := global_position + Vector2(0, -14)
	var target := global_position + facing * THROW_RANGE
	spawn_projectile(get_parent(), origin, target, false)
	play_action("interact", 0.25)
	threw.emit(origin, target)
	return true


static func spawn_projectile(parent: Node, origin: Vector2, target: Vector2, echo: bool) -> void:
	var p := Projectile.new()
	p.start = origin
	p.target = target
	p.from_echo = echo
	parent.add_child(p)


## True when guards and cameras cannot see the player at all.
func is_concealed() -> bool:
	return is_hidden or in_vent


func get_eye_target() -> Vector2:
	return global_position + Vector2(0, -12)


func set_caught() -> void:
	caught = true
	velocity = Vector2.ZERO
	_update_anim()
