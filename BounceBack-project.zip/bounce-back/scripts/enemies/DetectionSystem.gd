class_name DetectionSystem
extends RefCounted
## Shared sight rules for guards, cameras and floodlights.
##  - Field of view: a cone around the facing direction.
##  - Detection radius: very close targets are noticed from any angle.
##  - Line of sight: walls, closed doors and cover (crates, lockers...) block it.
##  - Light: in darkness you are only seen inside a guard's flashlight beam.

const SIGHT_MASK := 1 | 16 | 32
const HALF_FOV := deg_to_rad(36.0)
const CLOSE_RADIUS := 38.0
const FLASHLIGHT_RANGE := 150.0
const LIT_RANGE := 235.0


static func line_clear(node: Node2D, from: Vector2, to: Vector2, exclude: Array = []) -> bool:
	var q := PhysicsRayQueryParameters2D.create(from, to, SIGHT_MASK, exclude)
	return node.get_world_2d().direct_space_state.intersect_ray(q).is_empty()


static func in_cone(origin: Vector2, facing: Vector2, p: Vector2, half_angle: float) -> bool:
	var v := p - origin
	if v.length_squared() < 0.01:
		return true
	return absf(facing.angle_to(v)) <= half_angle


## Guard sight. Returns 0 (not seen) or a 0..1 "how clearly" factor that scales suspicion.
static func guard_sees(guard: Node2D, eye: Vector2, facing: Vector2, target: Node2D, world: Node) -> float:
	if target.has_method("is_concealed") and target.is_concealed():
		return 0.0
	var tp: Vector2 = target.get_eye_target() if target.has_method("get_eye_target") else target.global_position
	var d := eye.distance_to(tp)
	var sneaking: bool = target.get("sneaking") == true
	var close := CLOSE_RADIUS * (0.7 if sneaking else 1.0)
	if d > LIT_RANGE:
		return 0.0
	var cone := in_cone(eye, facing, tp, HALF_FOV)
	if not cone and d > close:
		return 0.0
	if not line_clear(guard, eye, tp):
		return 0.0
	if d <= close:
		return 1.0
	var reach := FLASHLIGHT_RANGE * (0.8 if sneaking else 1.0)
	if d <= reach:
		return clampf(1.25 - d / LIT_RANGE, 0.3, 1.0)
	# Beyond the flashlight: only if the target stands in lamp light.
	var lit: float = world.light_at(target.global_position) if world and world.has_method("light_at") else 0.0
	if lit > 0.25:
		return clampf(lit * (1.0 - d / LIT_RANGE) * 1.6, 0.15, 0.8)
	return 0.0


## Raycast-clipped cone polygon (local to origin) for drawing vision cones.
static func cone_polygon(node: Node2D, origin: Vector2, angle: float, half: float, reach: float, rays := 22) -> PackedVector2Array:
	var pts := PackedVector2Array([Vector2.ZERO])
	var space := node.get_world_2d().direct_space_state
	for i in rays + 1:
		var a := angle - half + (2.0 * half) * i / rays
		var end := origin + Vector2.from_angle(a) * reach
		var q := PhysicsRayQueryParameters2D.create(origin, end, 1 | 16)
		var hit := space.intersect_ray(q)
		var p: Vector2 = hit.position if not hit.is_empty() else end
		pts.append(p - origin)
	return pts
