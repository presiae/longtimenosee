class_name GuardStateMachine
extends RefCounted
## Finite state machine for guards. Only bookkeeping lives here (current state, time in
## state, transition signal); GuardAI implements what each state does.
##
##   PATROL ──sees/hears something──> SUSPICIOUS ──> INVESTIGATE ──> SEARCH ──> RETURN ──> PATROL
##      └─────────── player clearly seen (suspicion full) ──> CHASE ──lost sight──> SEARCH

signal changed(from: int, to: int)

enum S { PATROL, SUSPICIOUS, INVESTIGATE, CHASE, SEARCH, RETURN }

const NAMES := ["PATROL", "SUSPICIOUS", "INVESTIGATE", "CHASE", "SEARCH", "RETURN"]
## Indicator colours: white normal, yellow suspicious, orange investigating, red detected.
const COLORS := [Color(0.85, 0.88, 0.95), Color(1.0, 0.86, 0.25), Color(1.0, 0.55, 0.15),
	Color(1.0, 0.2, 0.2), Color(1.0, 0.55, 0.15), Color(0.85, 0.88, 0.95)]

var state: int = S.PATROL
var time_in_state := 0.0


func change(to: int) -> void:
	if to == state:
		return
	var from := state
	state = to
	time_in_state = 0.0
	changed.emit(from, to)


func tick(delta: float) -> void:
	time_in_state += delta


func is_alert() -> bool:
	return state == S.CHASE


func state_name() -> String:
	return NAMES[state]


func color() -> Color:
	return COLORS[state]
