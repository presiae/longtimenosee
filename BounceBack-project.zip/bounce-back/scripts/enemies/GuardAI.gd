class_name GuardAI
extends LevelObject
## Prison guard. Patrols waypoints, sees with a flashlight-lit cone, hears noises, and runs
## the PATROL / SUSPICIOUS / INVESTIGATE / CHASE / SEARCH / RETURN state machine.
## Echoes attract guards (sight and sound) but can never be caught — only the real
## prisoner can be.

const S := GuardStateMachine.S
const SPEED_PATROL := 46.0
const SPEED_INVESTIGATE := 64.0
const SPEED_CHASE := 112.0
const CATCH_DIST := 18.0
const SUSPICION_RATE := 2.3
const SUSPICION_DECAY := 0.35

var fsm := GuardStateMachine.new()
var facing := Vector2.RIGHT
var suspicion := 0.0
var patrol: Array[Vector2] = []
var patrol_i := 0
var wait_time := 1.0
var look_around := false
var post_facing := Vector2.RIGHT
var investigate_pos := Vector2.ZERO
var last_known := Vector2.ZERO
var path: PackedVector2Array = PackedVector2Array()
var path_goal := Vector2.INF

var sprite: AnimatedSprite2D
var flashlight: PointLight2D
var cone: VisionCone
var indicator: GuardIndicator
var presence: Area2D

var _wait_t := 0.0
var _look_t := 0.0
var _repath_t := 0.0
var _unseen_t := 0.0
var _seen_hide_spot: Node = null
var _pursue_echo: Node2D = null
var _anim := ""
var _step_t := 0.0


func _ready() -> void:
	add_to_group("guards")
	add_to_group("listeners")
	var pts: Array = cfg("patrol", [[cell.x, cell.y]])
	for p: Array in pts:
		patrol.append(MapBuilder.cell_feet(Vector2i(int(p[0]), int(p[1]))))
	wait_time = float(cfg("wait", 1.0))
	look_around = bool(cfg("look_around", false))
	post_facing = {"north": Vector2.UP, "south": Vector2.DOWN, "east": Vector2.RIGHT, "west": Vector2.LEFT} \
		.get(str(cfg("facing", "east")), Vector2.RIGHT)
	facing = post_facing

	sprite = AnimatedSprite2D.new()
	sprite.sprite_frames = SpriteLib.character_frames("td_guard")
	sprite.centered = false
	sprite.offset = Vector2(-16, -31)
	add_child(sprite)

	flashlight = PointLight2D.new()
	flashlight.texture = SpriteLib.cone_texture()
	flashlight.texture_scale = DetectionSystem.FLASHLIGHT_RANGE * 2.0 / 256.0 * 1.1
	flashlight.color = Color(1.0, 0.92, 0.7)
	flashlight.energy = 1.25
	flashlight.shadow_enabled = true
	flashlight.shadow_filter = PointLight2D.SHADOW_FILTER_NONE
	flashlight.position = Vector2(0, -14)
	add_child(flashlight)

	cone = VisionCone.new()
	cone.position = Vector2(0, -14)
	add_child(cone)
	indicator = GuardIndicator.new()
	indicator.position = Vector2(0, -40)
	add_child(indicator)

	presence = Area2D.new()
	presence.collision_layer = 8
	presence.collision_mask = 0
	var cs := CollisionShape2D.new()
	var c := CircleShape2D.new()
	c.radius = 7
	cs.shape = c
	cs.position = Vector2(0, -4)
	presence.add_child(cs)
	add_child(presence)
	fsm.changed.connect(_on_state_changed)


func eye() -> Vector2:
	return global_position + Vector2(0, -14)


# ------------------------------------------------------------------ main loop
func _physics_process(delta: float) -> void:
	fsm.tick(delta)
	_perceive(delta)
	match fsm.state:
		S.PATROL:
			_do_patrol(delta)
		S.SUSPICIOUS:
			_do_suspicious(delta)
		S.INVESTIGATE:
			_do_investigate(delta)
		S.CHASE:
			_do_chase(delta)
		S.SEARCH:
			_do_search(delta)
		S.RETURN:
			_do_return(delta)
	_update_visuals()


func _perceive(delta: float) -> void:
	var w: Node = level
	var p: PlayerController = w.player if w else null
	var seen := 0.0
	if p and is_instance_valid(p) and not p.caught:
		seen = DetectionSystem.guard_sees(self, eye(), facing, p, w)
	if seen > 0.0:
		_unseen_t = 0.0
		last_known = p.global_position
		suspicion = minf(1.0, suspicion + seen * SUSPICION_RATE * delta)
		if fsm.state == S.CHASE:
			if global_position.distance_to(p.global_position) <= CATCH_DIST:
				_catch(p, "A guard caught you.")
		elif suspicion >= 1.0:
			fsm.change(S.CHASE)
		elif fsm.state in [S.PATROL, S.RETURN, S.SEARCH] and suspicion > 0.12:
			investigate_pos = p.global_position
			fsm.change(S.SUSPICIOUS)
		elif fsm.state in [S.SUSPICIOUS, S.INVESTIGATE]:
			investigate_pos = p.global_position
	else:
		_unseen_t += delta
		if fsm.state != S.CHASE:
			suspicion = maxf(0.0, suspicion - SUSPICION_DECAY * delta)
		# Remember a hiding spot the player dived into while we were watching.
		if fsm.state == S.CHASE and p and p.is_hidden and _unseen_t < 0.7 and _seen_hide_spot == null:
			_seen_hide_spot = p.hiding_spot
	# Echoes: visible movement draws attention, but never a chase.
	if fsm.state != S.CHASE:
		for e in get_tree().get_nodes_in_group("echo"):
			if not e.visible or e.get("concealed"):
				continue
			var ep: Vector2 = e.global_position + Vector2(0, -12)
			if eye().distance_to(ep) < DetectionSystem.LIT_RANGE and DetectionSystem.in_cone(eye(), facing, ep, DetectionSystem.HALF_FOV) \
					and DetectionSystem.line_clear(self, eye(), ep):
				investigate_pos = e.global_position
				_pursue_echo = e
				if fsm.state in [S.PATROL, S.RETURN, S.SEARCH]:
					fsm.change(S.SUSPICIOUS)
				break


## Called by NoiseManager.
func hear(pos: Vector2, loudness: float, _source: Node, kind: String) -> void:
	if fsm.state == S.CHASE:
		return
	investigate_pos = pos
	if kind == "alarm":
		fsm.change(S.INVESTIGATE)
		_repath_t = 0.0
		path_goal = Vector2.INF
	elif loudness >= 0.6 or fsm.state in [S.INVESTIGATE, S.SEARCH]:
		fsm.change(S.INVESTIGATE)
		path_goal = Vector2.INF
	elif fsm.state in [S.PATROL, S.RETURN]:
		fsm.change(S.SUSPICIOUS)


## Cameras / floodlights call this when they spot the real prisoner.
func alarm_chase(pos: Vector2) -> void:
	last_known = pos
	suspicion = 1.0
	fsm.change(S.CHASE)
	path_goal = Vector2.INF


# ------------------------------------------------------------------ states
func _do_patrol(delta: float) -> void:
	if patrol.size() <= 1:
		var post: Vector2 = patrol[0] if patrol.size() == 1 else position
		if position.distance_to(post) > 4.0:
			_move_towards(post, SPEED_PATROL, delta)
		else:
			_look_t += delta
			if look_around and _look_t > 2.6:
				_look_t = 0.0
				facing = post_facing.rotated(PI * 0.5 * (1 if int(fsm.time_in_state / 2.6) % 2 == 0 else -1)) \
					if facing == post_facing else post_facing
			elif not look_around:
				facing = post_facing
			_set_anim("idle")
		return
	var target := patrol[patrol_i]
	if position.distance_to(target) < 3.0:
		_wait_t += delta
		_set_anim("idle")
		if _wait_t >= wait_time:
			_wait_t = 0.0
			patrol_i = (patrol_i + 1) % patrol.size()
	else:
		_move_towards(target, SPEED_PATROL, delta)


func _do_suspicious(delta: float) -> void:
	_set_anim("idle")
	var to := investigate_pos - position
	if to.length() > 1.0:
		facing = facing.slerp(to.normalized(), minf(1.0, delta * 6.0)).normalized()
	if fsm.time_in_state > 0.9:
		fsm.change(S.INVESTIGATE)


func _do_investigate(delta: float) -> void:
	if is_instance_valid(_pursue_echo) and _pursue_echo.visible:
		if DetectionSystem.line_clear(self, eye(), _pursue_echo.global_position + Vector2(0, -12)):
			investigate_pos = _pursue_echo.global_position
	if not _move_towards(investigate_pos, SPEED_INVESTIGATE, delta) or position.distance_to(investigate_pos) < 14.0:
		if is_instance_valid(_pursue_echo) and position.distance_to(_pursue_echo.global_position) < 20.0:
			_pursue_echo.call("brush_past")
		_pursue_echo = null
		fsm.change(S.SEARCH)
	elif fsm.time_in_state > 14.0:
		fsm.change(S.SEARCH)


func _do_chase(delta: float) -> void:
	var p: PlayerController = level.player
	if _seen_hide_spot and is_instance_valid(_seen_hide_spot):
		var spot: Node2D = _seen_hide_spot
		_move_towards(spot.global_position + Vector2(0, 14), SPEED_CHASE, delta)
		if position.distance_to(spot.global_position) < 30.0 and p.is_hidden and p.hiding_spot == spot:
			_catch(p, "The guard saw you hide.")
		return
	_move_towards(last_known, SPEED_CHASE, delta)
	if p and not p.is_concealed() and position.distance_to(p.global_position) <= CATCH_DIST and _unseen_t < 0.3:
		_catch(p, "A guard caught you.")
	elif _unseen_t > 0.8 and position.distance_to(last_known) < 16.0:
		suspicion = 0.6
		investigate_pos = last_known
		fsm.change(S.SEARCH)
	elif _unseen_t > 6.0:
		fsm.change(S.SEARCH)


func _do_search(delta: float) -> void:
	_set_anim("search")
	_look_t += delta
	if _look_t > 0.9:
		_look_t = 0.0
		facing = facing.rotated(PI * 0.5 * (1 if int(fsm.time_in_state) % 3 != 2 else -1))
	if fsm.time_in_state > 3.6:
		fsm.change(S.RETURN)


func _do_return(delta: float) -> void:
	var home := patrol[patrol_i] if not patrol.is_empty() else position
	if not _move_towards(home, SPEED_PATROL, delta) or position.distance_to(home) < 4.0:
		fsm.change(S.PATROL)


func _on_state_changed(_from: int, to: int) -> void:
	path_goal = Vector2.INF
	_look_t = 0.0
	if to == S.CHASE:
		_seen_hide_spot = null
		play_sfx("alert")
		var nm := get_node_or_null("/root/NoiseManager")
		if nm:
			nm.emit_noise(global_position, 0.7, self, "shout")
		var mus := get_node_or_null("/root/AudioManager")
		if mus:
			mus.bump_intensity(1.0)
	elif to == S.SUSPICIOUS:
		play_sfx("huh", -6.0)
	elif to == S.SEARCH:
		_seen_hide_spot = null


func _catch(p: PlayerController, reason: String) -> void:
	if p.caught:
		return
	_set_anim("catch")
	set_physics_process(false)
	var to := p.global_position - position
	if to.length() > 0.1:
		facing = to.normalized()
	level.player_caught.emit(reason)


# ------------------------------------------------------------------ movement
## Moves along an A* path. Returns false when there is no path to the goal.
func _move_towards(goal: Vector2, speed: float, delta: float) -> bool:
	_repath_t -= delta
	if goal.distance_to(path_goal) > 20.0 or (_repath_t <= 0.0 and fsm.state == S.CHASE):
		_repath_t = 0.25
		path_goal = goal
		path = level.find_path(position, goal)
		if path.size() > 0 and path[0].distance_to(position) < 20.0:
			path.remove_at(0)
	if path.is_empty():
		if position.distance_to(goal) < 40.0 and level.is_walkable_line(position, goal):
			path = PackedVector2Array([goal])
		else:
			_set_anim("idle")
			return false
	var next := path[0]
	var to := next - position
	var step := speed * delta
	if to.length() <= step:
		position = next
		path.remove_at(0)
	else:
		position += to.normalized() * step
	if to.length() > 0.5:
		facing = facing.slerp(to.normalized(), minf(1.0, delta * 10.0)).normalized()
	_set_anim("run" if speed >= SPEED_CHASE else "walk")
	_step_t -= delta
	if _step_t <= 0.0:
		_step_t = 0.3 if speed >= SPEED_CHASE else 0.48
		play_sfx("step_run" if speed >= SPEED_CHASE else "step2", -8.0)
	return true


# ------------------------------------------------------------------ visuals
func _set_anim(base: String) -> void:
	var d: Array = SpriteLib.dir_anim(facing)
	var a := "%s_%s" % [base, d[0]]
	sprite.flip_h = d[1]
	if a != _anim:
		_anim = a
		sprite.play(a)


func _update_visuals() -> void:
	var ang := facing.angle()
	flashlight.rotation = ang
	cone.update_cone(self, ang, fsm.color())
	indicator.state = fsm.state
	indicator.meter = suspicion
	indicator.queue_redraw()


## Debug overlay info (F3).
func debug_text() -> String:
	return "%s %s  sus %.2f" % [object_id, fsm.NAMES[fsm.state], suspicion]


## Raycast-clipped glowing cone that stays visible in the dark (unshaded).
class VisionCone:
	extends Node2D
	var poly := PackedVector2Array()
	var col := Color.WHITE
	var _frame := 0

	func _ready() -> void:
		var m := CanvasItemMaterial.new()
		m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
		material = m
		z_index = 2

	func update_cone(owner_node: Node2D, angle: float, c: Color) -> void:
		col = c
		_frame += 1
		if _frame % 2 == 0 or poly.is_empty():
			poly = DetectionSystem.cone_polygon(owner_node, global_position, angle, DetectionSystem.HALF_FOV, DetectionSystem.FLASHLIGHT_RANGE)
		queue_redraw()

	func _draw() -> void:
		if poly.size() < 3:
			return
		var cols := PackedColorArray()
		cols.append(Color(col, 0.20))
		for i in poly.size() - 1:
			cols.append(Color(col, 0.04))
		draw_polygon(poly, cols)


## State icon above the guard's head: dot (patrol), ? (suspicious/investigating), ! (chase).
class GuardIndicator:
	extends Node2D
	var state := 0
	var meter := 0.0

	func _ready() -> void:
		var m := CanvasItemMaterial.new()
		m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
		material = m
		z_index = 30

	func _draw() -> void:
		var c: Color = GuardStateMachine.COLORS[state]
		var ink := Color(0.04, 0.05, 0.09)
		match state:
			GuardStateMachine.S.CHASE:
				draw_rect(Rect2(-2, -9, 4, 8), ink)
				draw_rect(Rect2(-1, -8, 2, 6), c)
				draw_rect(Rect2(-2, 0, 4, 3), ink)
				draw_rect(Rect2(-1, 0, 2, 2), c)
			GuardStateMachine.S.SUSPICIOUS, GuardStateMachine.S.INVESTIGATE, GuardStateMachine.S.SEARCH:
				for r in [Rect2(-3, -9, 6, 2), Rect2(2, -8, 2, 4), Rect2(-1, -5, 3, 2), Rect2(-1, -3, 2, 2), Rect2(-1, 0, 2, 2)]:
					draw_rect((r as Rect2).grow(1), ink)
				for r in [Rect2(-3, -9, 6, 2), Rect2(2, -8, 2, 4), Rect2(-1, -5, 3, 2), Rect2(-1, -3, 2, 2), Rect2(-1, 0, 2, 2)]:
					draw_rect(r, c)
			_:
				draw_rect(Rect2(-2, -2, 4, 4), Color(ink, 0.6))
				draw_rect(Rect2(-1, -1, 2, 2), Color(c, 0.6))
		if meter > 0.02 and state != GuardStateMachine.S.CHASE:
			draw_rect(Rect2(-9, 5, 18, 3), ink)
			draw_rect(Rect2(-8, 6, 16.0 * meter, 1), Color(1.0, 0.3 + 0.5 * (1.0 - meter), 0.2))
