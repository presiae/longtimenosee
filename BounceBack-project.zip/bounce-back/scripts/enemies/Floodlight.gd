class_name Floodlight
extends LevelObject
## Watchtower floodlight. Its beam sweeps a bright circle across the yard between two
## points. Being caught in the beam raises the alarm; an Echo in the beam draws guards to
## it. A linked input (the generator lever) cuts its power.

const SPOT_RADIUS := 58.0

var a := Vector2.ZERO
var b := Vector2.ZERO
var period := 7.0
var enabled := true
var spot_pos := Vector2.ZERO
var meter := 0.0
var tower: Sprite2D
var spot_light: PointLight2D
var spot_draw: Node2D
var _t := 0.0
var _cool := 0.0


func _ready() -> void:
	add_to_group("floodlights")
	var pa: Array = cfg("a", [cell.x, cell.y + 4])
	var pb: Array = cfg("b", [cell.x + 4, cell.y + 4])
	a = MapBuilder.cell_center(Vector2i(int(pa[0]), int(pa[1])))
	b = MapBuilder.cell_center(Vector2i(int(pb[0]), int(pb[1])))
	period = float(cfg("period", 7.0))
	_t = float(cfg("phase", 0.0))
	tower = SpriteLib.prop_sprite("tower", 2)
	add_child(tower)
	var body := StaticBody2D.new()
	body.collision_layer = 1
	var cs := CollisionShape2D.new()
	var r := RectangleShape2D.new()
	r.size = Vector2(36, 10)
	cs.shape = r
	cs.position = Vector2(0, -5)
	body.add_child(cs)
	add_child(body)
	# The beam lives in world space, not under the tower.
	spot_light = PointLight2D.new()
	spot_light.texture = SpriteLib.light_texture()
	spot_light.texture_scale = SPOT_RADIUS * 2.6 / 256.0
	spot_light.energy = 1.6
	spot_light.color = Color(1.0, 0.96, 0.85)
	spot_light.top_level = true
	add_child(spot_light)
	spot_draw = Node2D.new()
	spot_draw.top_level = true
	var m := CanvasItemMaterial.new()
	m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	spot_draw.material = m
	spot_draw.z_index = 2
	spot_draw.draw.connect(_draw_spot)
	add_child(spot_draw)


func _on_active_changed(active: bool) -> void:
	enabled = not active
	tower.frame = 0 if enabled else 1
	spot_light.enabled = enabled
	spot_draw.queue_redraw()
	play_sfx("power_down" if not enabled else "power_up")


func _physics_process(delta: float) -> void:
	if not enabled:
		return
	_t += delta
	var k := 0.5 - 0.5 * cos(_t / period * TAU)
	spot_pos = a.lerp(b, k)
	spot_light.global_position = spot_pos
	spot_draw.global_position = spot_pos
	spot_draw.queue_redraw()
	_cool -= delta
	var p: PlayerController = level.player
	if p and not p.caught and not p.is_concealed() and p.global_position.distance_to(spot_pos) < SPOT_RADIUS:
		meter += delta * 2.8
		if meter >= 1.0 and _cool <= 0.0:
			_cool = 4.0
			play_sfx("alarm")
			SecurityCamera.raise_alarm(self, p.global_position, true)
	else:
		meter = maxf(0.0, meter - delta)
		if _cool <= 0.0:
			for e in get_tree().get_nodes_in_group("echo"):
				if e.visible and e.global_position.distance_to(spot_pos) < SPOT_RADIUS:
					_cool = 6.0
					SecurityCamera.raise_alarm(self, e.global_position, false)
					break


## Is a point currently lit by this beam? (Guards see you from far away there.)
func light_at(p: Vector2) -> float:
	if not enabled:
		return 0.0
	return 1.0 if p.distance_to(spot_pos) < SPOT_RADIUS else 0.0


func _draw_spot() -> void:
	if not enabled:
		return
	spot_draw.draw_circle(Vector2.ZERO, SPOT_RADIUS, Color(1.0, 0.95, 0.8, 0.10 + meter * 0.15))
	spot_draw.draw_arc(Vector2.ZERO, SPOT_RADIUS, 0, TAU, 40, Color(1.0, 0.9, 0.6, 0.35), 1.5)
