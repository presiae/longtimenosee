class_name SecurityCamera
extends LevelObject
## Wall-mounted camera sweeping a vision cone. It sees in the dark. Spotting the prisoner
## fills its meter and then raises the alarm (every guard nearby comes running). Spotting
## an Echo raises an alarm at the Echo's position — a useful distraction.
## A linked input (breaker panel) switches it off while active.

const HALF := deg_to_rad(17.0)
const SIGHT_MASK := 1 | 16 | 32

var base_angle := PI * 0.5
var sweep := deg_to_rad(50.0)
var speed := 0.6
var reach := 170.0
var enabled := true
var angle := 0.0
var meter := 0.0
var sprite: Sprite2D
var cone: Node2D
var light: PointLight2D
var _t := 0.0
var _cool := 0.0
var _poly := PackedVector2Array()


func _ready() -> void:
	add_to_group("cameras")
	base_angle = deg_to_rad(float(cfg("dir", 90)))
	sweep = deg_to_rad(float(cfg("sweep", 50)))
	speed = float(cfg("speed", 0.6))
	reach = float(cfg("range", 170))
	_t = float(cfg("phase", 0.0))
	# Mounted on the wall face above the cell.
	position.y -= 30
	sprite = SpriteLib.prop_sprite("camera", 2)
	sprite.offset.y = -4
	z_index = 3
	add_child(sprite)
	light = PointLight2D.new()
	light.texture = SpriteLib.cone_texture()
	light.texture_scale = reach * 2.0 / 256.0 * 1.05
	light.color = Color(1.0, 0.35, 0.3)
	light.energy = 0.45
	light.shadow_enabled = false   # cosmetic tint; the cone polygon already respects walls
	add_child(light)
	cone = Node2D.new()
	var m := CanvasItemMaterial.new()
	m.light_mode = CanvasItemMaterial.LIGHT_MODE_UNSHADED
	m.blend_mode = CanvasItemMaterial.BLEND_MODE_ADD
	cone.material = m
	cone.draw.connect(_draw_cone)
	add_child(cone)


func _on_active_changed(active: bool) -> void:
	enabled = not active
	sprite.frame = 0 if enabled else 1
	light.enabled = enabled
	meter = 0.0
	cone.queue_redraw()
	play_sfx("power_down" if not enabled else "power_up", -6.0)


func _physics_process(delta: float) -> void:
	if not enabled:
		return
	_t += delta * speed
	angle = base_angle + sin(_t) * sweep
	light.rotation = angle
	_cool -= delta
	var w: Node = level
	var p: PlayerController = w.player
	var origin := global_position
	var spotted := false
	if p and not p.caught and not p.is_concealed() and _sees(origin, p.get_eye_target()):
		meter += delta * 1.6
		spotted = true
		if meter >= 1.0 and _cool <= 0.0:
			_cool = 4.0
			_raise_alarm(p.global_position, true)
	else:
		meter = maxf(0.0, meter - delta * 0.8)
	if not spotted and _cool <= 0.0:
		for e in get_tree().get_nodes_in_group("echo"):
			if e.visible and not e.get("concealed") and _sees(origin, e.global_position + Vector2(0, -12)):
				_cool = 6.0
				_raise_alarm(e.global_position, false)
				break
	if Engine.get_physics_frames() % 2 == 0:
		_poly = DetectionSystem.cone_polygon(self, origin, angle, HALF, reach, 12)
	cone.queue_redraw()


func _sees(origin: Vector2, p: Vector2) -> bool:
	if origin.distance_to(p) > reach:
		return false
	if absf(angle_difference(angle, (p - origin).angle())) > HALF:
		return false
	var q := PhysicsRayQueryParameters2D.create(origin, p, SIGHT_MASK)
	return get_world_2d().direct_space_state.intersect_ray(q).is_empty()


func _raise_alarm(pos: Vector2, is_player: bool) -> void:
	play_sfx("alarm")
	raise_alarm(self, pos, is_player)


## Shared by cameras and floodlights: real prisoner -> nearby guards chase;
## an Echo -> they investigate the spot.
static func raise_alarm(from: Node, pos: Vector2, is_player: bool) -> void:
	var hud := from.get_tree().get_first_node_in_group("hud")
	if hud:
		hud.flash_alarm()
	for g in from.get_tree().get_nodes_in_group("guards"):
		if g.global_position.distance_to(pos) > 700.0:
			continue
		if is_player:
			g.alarm_chase(pos)
		else:
			g.hear(pos, 1.0, from, "alarm")


func _draw_cone() -> void:
	if not enabled or _poly.size() < 3:
		return
	var c := Color(1.0, 0.3 + 0.4 * (1.0 - meter), 0.25)
	var cols := PackedColorArray([Color(c, 0.25)])
	for i in _poly.size() - 1:
		cols.append(Color(c, 0.05))
	cone.draw_polygon(_poly, cols)
