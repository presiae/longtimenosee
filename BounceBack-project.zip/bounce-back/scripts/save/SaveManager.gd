extends Node
## Saves settings (user://settings.cfg) and progress (user://save.json): checkpoint,
## keycards, notes, Echo shards (capacity upgrades), attempts and whether the intro and
## the game have been seen/finished. Close the game any time and Continue later.

var SETTINGS_PATH := "user://settings.cfg"
var SAVE_PATH := "user://save.json"
const DEFAULTS := {
	"master_volume": 0.8, "music_volume": 0.7, "sfx_volume": 0.9, "fullscreen": false,
	"screen_shake": true, "window_scale": 1,
}
const WINDOW_SIZES := [Vector2i(1280, 720), Vector2i(1600, 900), Vector2i(1920, 1080)]

var settings := {}
var meta := {"intro_seen": false, "finished": false}


func _ready() -> void:
	process_mode = Node.PROCESS_MODE_ALWAYS
	load_settings()
	_load_meta()


# ------------------------------------------------------------------ settings
func get_setting(key: String, default: Variant = null) -> Variant:
	return settings.get(key, DEFAULTS.get(key, default))


func set_setting(key: String, value: Variant) -> void:
	settings[key] = value
	apply_settings()
	save_settings()


func load_settings() -> void:
	settings = DEFAULTS.duplicate()
	var cf := ConfigFile.new()
	if cf.load(SETTINGS_PATH) == OK:
		for k: String in DEFAULTS:
			settings[k] = cf.get_value("settings", k, DEFAULTS[k])
	apply_settings()


func save_settings() -> void:
	var cf := ConfigFile.new()
	for k: String in settings:
		cf.set_value("settings", k, settings[k])
	cf.save(SETTINGS_PATH)


func apply_settings() -> void:
	_bus("Master", float(get_setting("master_volume")))
	_bus("Music", float(get_setting("music_volume")))
	_bus("SFX", float(get_setting("sfx_volume")))
	if DisplayServer.get_name() == "headless":
		return
	var fs: bool = get_setting("fullscreen")
	DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN if fs else DisplayServer.WINDOW_MODE_WINDOWED)
	if not fs:
		var i := clampi(int(get_setting("window_scale")), 0, WINDOW_SIZES.size() - 1)
		var size: Vector2i = WINDOW_SIZES[i]
		var screen := DisplayServer.screen_get_size()
		if size.x <= screen.x and size.y <= screen.y and DisplayServer.window_get_size() != size:
			DisplayServer.window_set_size(size)
			DisplayServer.window_set_position((screen - size) / 2)


func _bus(name: String, linear: float) -> void:
	var i := AudioServer.get_bus_index(name)
	if i == -1:
		return
	AudioServer.set_bus_volume_db(i, linear_to_db(maxf(linear, 0.0001)))
	AudioServer.set_bus_mute(i, linear <= 0.001)


# ------------------------------------------------------------------ progress
func has_save() -> bool:
	return FileAccess.file_exists(SAVE_PATH)


func save_progress() -> void:
	var lm := get_node_or_null("/root/LevelManager")
	var data := {"version": 1, "meta": meta, "progress": lm.to_dict() if lm else {}}
	var f := FileAccess.open(SAVE_PATH, FileAccess.WRITE)
	if f:
		f.store_string(JSON.stringify(data, "  "))


func load_progress() -> bool:
	if not has_save():
		return false
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) != TYPE_DICTIONARY:
		return false
	meta.merge(d.get("meta", {}), true)
	var lm := get_node_or_null("/root/LevelManager")
	if lm:
		lm.from_dict(d.get("progress", {}))
	return true


func _load_meta() -> void:
	if not has_save():
		return
	var f := FileAccess.open(SAVE_PATH, FileAccess.READ)
	var d: Variant = JSON.parse_string(f.get_as_text())
	if typeof(d) == TYPE_DICTIONARY:
		meta.merge(d.get("meta", {}), true)


func mark_intro_seen() -> void:
	meta["intro_seen"] = true
	save_progress()


func mark_finished() -> void:
	meta["finished"] = true
	save_progress()


func delete_progress() -> void:
	if has_save():
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SAVE_PATH))
