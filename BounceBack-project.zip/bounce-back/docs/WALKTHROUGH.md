# Walkthrough (spoilers)

These are the routes the automated playthroughs use (`tests/test_solutions.gd`). Other
solutions exist.

## 1. The Cell
1. Read the note under the bunk.
2. **Attempt 1:** pry open the vent grate on the east wall and crawl through. The guard by
   the vent exit catches you. That's intended.
3. **Attempt 2:** walk to the cell bars and press **E** to rattle them, wait a moment, then
   press **R**.
4. **Attempt 3:** your Echo rattles the bars and the guard walks over to check the cell.
   Crawl out through the vent behind his back and head east to the chalk circle (checkpoint 1).

## 2. The Cell Block
- Keep to the dark south wall while sneaking (**Ctrl**). The lamps and patrols are on the north side.
- The south gate is wired to a lever in the store room (the manual door on the north side),
  and it only stays open for about 2 seconds.
- **Record:** wait about 15 seconds, open the store-room door, pull the lever, then press **R**.
- **Play:** sneak to the locker beside the gate and hide. When your Echo pulls the lever, the
  gate opens: step out and walk through.
- Optional: the store room on the south side (manual door) holds an **Echo shard**
  (capacity 2) and a note.

## 3. The Security Wing
- The breaker in the lobby cuts the hallway cameras for 7 seconds.
- The control room needs **both** plates held at once: plate A in the records room
  (north-west) and plate B in the interview room (south).
- **Record 1:** go to plate A and stand on it for a long while, then press **R**.
- **Record 2:** go to plate B and stand on it, then press **R**.
- **Play:** wait outside the control room. When both Echoes are on their plates, the door
  opens. Take the **red keycard** and the second **Echo shard** (capacity 3). The lever
  inside opens the door again from within.
- The red door at the east end of the hallway leads to the yard.

## 4–5. The Yard and the Gate
- Floodlight towers sweep the yard. The generator lever in the shed (south of the exercise
  ground) cuts them.
- The main gate opens only while **both** gate plates (west and east of the gravel road) are
  held. The gate guard can be lured away by kicking the dumpster next to the guard hut.
- **Record A:** pull the generator lever, then walk to the west gate plate and stand on it. Press **R**.
- **Record B:** walk to the east gate plate and stand on it. Press **R**.
- (Optional **Record C**, if you have three Echoes: kick the dumpster, then wait.)
- **Play:** the lights go out, both plates go down, and the gate opens. Walk through and
  follow the road east.
