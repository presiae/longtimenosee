# The Echo system

The Echo is the heart of the game. It is a **functional replay of a previous attempt**, not
a recorded video and not an AI.

## Recording — `scripts/echo/EchoRecorder.gd`, `EchoRecording.gd`

- Physics runs at a fixed 60 ticks per second. The recorder runs after the player each tick
  (`process_physics_priority = 100`) and stores that tick's final state:
  `positions`, `facings`, `anim_ids` (indices into `anim_names`) and `flags`
  (`FLAG_HIDDEN`, `FLAG_SNEAK`, `FLAG_RUN`).
- Events are stored with the frame they happened on:
  - `{"type": "interact", "id": <object id>}` when the player uses an object.
  - `{"type": "noise", "loud": float, "kind": String}` for every footstep or noise.
  - `{"type": "throw", "dir": Vector2, "off": Vector2}` for thrown bottles.
- Object ids are stable because the world is rebuilt from the same `MapGen` data each attempt.

## Lifecycle — `scripts/managers/EchoManager.gd`

1. `Game.start_attempt()` rebuilds the World, then `EchoManager.begin_attempt()` attaches a
   fresh recorder and spawns one `Echo` for each stored recording that started at the
   current checkpoint.
2. When an attempt ends (caught, or **R**), `end_attempt()` keeps the recording if it lasted
   at least 0.5 s. Capacity is `1 + shards` (max 3); the oldest recording is dropped first.
3. On reaching a new checkpoint, every recording is released and the current recording
   restarts from that moment (old recordings started somewhere else, so they would no
   longer line up).
4. **X** dissolves every Echo.

## Playback — `scripts/echo/EchoPlayback.gd` (`class_name Echo`)

Each physics tick (`process_physics_priority = -10`), the Echo:

1. Checks that the next recorded position isn't blocked by a door or bars that are closed
   *in this attempt*. If it is, the Echo **stalls** (it flickers and doesn't advance). After
   2 s it dissolves. It never walks through a door, and the game never freezes.
2. Advances one frame: moves to the recorded position, plays the recorded animation, applies
   the hidden/sneak flags (`concealed` in lockers and vents).
3. Fires every event whose frame has been reached:
   - **interact**: looks the object up by id and calls `try_interact(echo)` if it's within
     56 px. `Interactable.try_interact` refuses unless the object is `echo_compatible`, so
     Echoes can use levers, breakers, vents, manual doors and noise sources, but never
     pickups, keycard doors or the exit.
   - **noise**: re-emits the same noise through `NoiseManager` (guards hear it), and footsteps
     play through the reverb-and-chorus **Echo audio bus**.
   - **throw**: spawns a ghost bottle that shatters with the same loud noise.
4. Its `Area2D` on the *echo* physics layer presses pressure plates.

## How the world reacts

- Guards who **see** an Echo or **hear** its noise investigate it. They never chase or catch
  it; walking into one just makes it flicker (`brush_past`).
- Cameras and floodlights that spot an Echo raise an alarm *at the Echo's position*, which
  pulls guards towards it — a distraction.

## Debugging

Press **F3** in game: every Echo's full path, event markers (cyan = interact, yellow = noise,
white = throw), the current frame, stalls, recent playback log lines, noise radii and the
state of nearby guards.

## Tests — `tests/test_echo.gd`, `tests/test_solutions.gd`

- Playback matches the recording to within 0.01 px.
- The vent, lever and plate interactions replay on the same frame.
- Two Echoes hold two plates and open the AND-gated control-room door.
- An Echo rattling the bars lures the post guard away.
- An Echo blocked by a closed door stalls, then dissolves.
- Capacity, checkpoint release, and very short attempts leaving no Echo.
- Bot playthroughs that solve every zone with Echoes.
