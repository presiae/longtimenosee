# Architecture

```
res://
  scenes/        Game.tscn, menus/ (MainMenu, Intro, Ending, Credits), player/, ui/
  scripts/
    world/       MapGen (layout), MapBuilder (tiles/collision/occluders), World (one attempt),
                 Game (attempt lifecycle, story beats), SpriteLib (sheets, light textures)
    player/      PlayerController (8-way movement, sneak/run, noise, throwing)
    echo/        EchoRecording, EchoRecorder, EchoPlayback (Echo), EchoDebug (F3)
    enemies/     GuardAI, GuardStateMachine, DetectionSystem, SecurityCamera, Floodlight
    interactions/LevelObject (id-based wiring), Interactable ([E] use), InteractionComponent
    objects/     Door, Switch, PressurePlate, Logic, HidingSpot, Vent, Pickup, Lamp, Prop,
                 NoiseSource, Projectile, Checkpoint, LevelExit, Hint
    managers/    InputSetup, LevelManager, NoiseManager, EchoManager, Effects, AudioManager
    save/        SaveManager
    ui/          HUD, UITheme, MainMenu, PauseMenu, SettingsPanel, Intro, Ending, Credits
  shaders/       echo.gdshader
  assets/        sprites/, tilesets/, audio/{sfx,ambient,music,oga}, fonts/
  tools/         art/ and audio/ generators, run_tests.sh, shoot.sh, shots/ (stagers)
  tests/         headless test runner and suites
```

## Autoloads

| Autoload | Role |
|---|---|
| `InputSetup` | All key and gamepad bindings, plus the controls list shown in settings |
| `LevelManager` | Run state that survives attempts: checkpoint, keycards, collectibles, Echo capacity |
| `NoiseManager` | Noise bus; guards in the `listeners` group decide what they hear |
| `EchoManager` | Echo recordings across attempts |
| `Effects` | Noise rings and particles |
| `AudioManager` | Buses, positional SFX, ambience, adaptive music |
| `SaveManager` | `user://save.json` and `user://settings.cfg` |
| `ScreenshotTool` | Development captures (inactive unless `BB_SHOT*` env vars are set) |

## One attempt = one World

`Game` instances a new `World` for every attempt. `World` asks `MapGen.prison()` for the
layout (cached), `MapBuilder` turns it into floor and wall `TileMapLayer`s with collision and
`LightOccluder2D`s, then entities are spawned into a y-sorted `Entities` node. Rebuilding
everything makes each attempt start from an identical, deterministic state, which is what
lets Echoes line up.

## Object wiring

Every map entity becomes a `LevelObject` with a stable id. Emitters (levers, breakers,
plates, `Logic` gates) send `output_changed(on)`, and `World._wire_links()` connects them to
each target's `set_input(source, on)`. A receiver is active when ANY input is on (or ALL,
with `require_all`). Doors open when active; lamps, cameras and floodlights switch OFF when
active (a power cut).

## Physics layers

1 world · 2 player · 3 echo · 4 guard · 5 doors · 6 cover · 7 interactable · 8 bars
(bars block movement but not sight or sound).

## Signals over node paths

Systems talk through signals and autoloads: `World.player_caught`, `World.exited`,
`World.zone_changed`, `LevelManager.checkpoint_reached` / `item_collected`,
`NoiseManager.noise_emitted`, `InteractionComponent.used` / `focus_changed`,
`Door.opened` / `closed`.
