# BOUNCE BACK

*Every failure leaves something behind.*

A top-down stealth / puzzle / time-loop game made with **Godot 4.7**. You are a prisoner who
keeps getting caught — and every failed attempt leaves an **Echo**: a glowing replay of exactly
what you did. Rattle the bars with one attempt, and on the next your Echo rattles them for you
while you slip out behind the guard.

> **You don't escape by being faster. You escape by learning from your failures.**

![Gameplay: the Echo rattles the cell bars, the guard goes to check, the prisoner crawls out through the vent](screenshots/gameplay.gif)

| | |
|---|---|
| ![Title screen over the live prison](screenshots/v0.6-title-screen.png) | ![Cell block](screenshots/v1.0-cell-block.png) |
| ![Security wing: cameras and the control room](screenshots/v1.0-security-wing.png) | ![The yard: floodlights and buildings](screenshots/v1.0-yard.png) |

All screenshots and the GIF are captured from the running game (`tools/shoot.sh`, Godot's movie writer).

## Status

**v1.0 — complete.** Five zones from your cell to the road outside, an intro, story beats, an
ending and credits. 32 automated tests pass, including bot playthroughs that solve every zone.

## Core mechanics

- **Echoes.** Each attempt is recorded frame by frame at a fixed 60 Hz: position, facing,
  animation, hidden/sneak flags, plus timestamped interactions, noises and throws. When you're
  caught — or press **R** to *bounce back* on purpose — that attempt replays as an Echo
  alongside your next one. Echoes press pressure plates, pull levers, open vents, rattle bars,
  throw bottles and make the same footstep noise. They can't pick anything up, can't be
  caught and can't leave the prison.
- **Echo capacity** starts at 1. Two hidden Echo shards raise it to 3. The oldest Echo drops
  off when you're over the limit; reaching a checkpoint releases all Echoes; **X** dissolves them.
- **Guards** run a six-state machine (patrol → suspicious → investigate → chase → search →
  return) with a field-of-view cone, a close "feel" radius, line of sight blocked by walls,
  doors and cover, flashlights, and a suspicion meter. In darkness they only see you inside
  their flashlight beam. The indicator over their head goes white / yellow / orange / red.
- **Noise.** Walking, running, doors, vents, levers and smashed bottles all make noise, shown
  as an expanding ring. Walls halve how far a sound carries. Sneaking is silent.
- **Light and fog of war.** The prison is dark: you see what your own light, the lamps, guard
  flashlights and glowing Echoes reveal, with real wall shadows. Smash a lamp with a bottle
  to make a dark spot. **L** toggles lighting.
- **Security.** Sweeping cameras (cut them with the breaker), yard floodlights (cut the
  generator), keycard doors, timed gates, AND-gated pressure plates, lockers and beds to hide in.

## The prison

One 85 × 55-tile map built in code: rooms carved from rectangles and ellipses, walls generated
around open floor, doors in carved gaps, buildings inside the yard, a perimeter wall and an
outside area past the gate.

1. **The Cell** — tutorial. Your first try through the vent fails; your Echo rattles the bars.
2. **The Cell Block** — a dark sneak lane, and a timed gate whose lever is too far away for one person.
3. **The Security Wing** — cameras, and a control room that needs two Echoes on two plates.
4. **The Yard** — floodlight towers, buildings, patrols, and the generator shed.
5. **The Gate / Outside** — cut the lights and hold both gate plates with Echoes, then run.

A full spoiler walkthrough is in [docs/WALKTHROUGH.md](docs/WALKTHROUGH.md).

## Controls

| Key | Action |
|---|---|
| WASD / Arrows | Move |
| Shift | Run (fast, loud) |
| Ctrl / C | Sneak (silent, harder to spot) |
| E | Interact / hide / pick up / read |
| Q | Throw a held bottle |
| R | Bounce back: restart the attempt, leaving an Echo |
| X | Dissolve all Echoes |
| L | Toggle lighting |
| Esc | Pause (resume, restart, settings, main menu) |
| F3 | Echo debug overlay (paths, events, noise radii, guard states) |

Gamepad: left stick, A/X interact, B sneak, RB run, Y throw, Back restart, Start pause.

## Installation

1. Install [Godot 4.7](https://godotengine.org/download) (standard build).
2. Clone this repository and open `project.godot` in Godot, or run it directly:
   ```
   godot --path . res://scenes/menus/MainMenu.tscn
   ```
3. **Windows build:** in Godot, *Editor → Manage Export Templates → Download*, then
   *Project → Export → Windows Desktop → Export Project* (the preset in `export_presets.cfg`
   writes to `builds/BounceBack.exe`). Prebuilt binaries are attached to GitHub Releases
   when available.

The game uses the Mobile (Vulkan) renderer and falls back to OpenGL 3 automatically on
machines without Vulkan.

## Development

```
tools/run_tests.sh                 # headless test suite; fails on any engine error
python tools/art/td_tiles.py       # regenerate tiles (also td_characters.py, td_props.py)
python tools/audio/make_audio.py   # regenerate SFX, ambience and music
tools/shoot.sh out.png 24,27       # real screenshot with the player at a map cell
```

- Architecture: [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md)
- How the Echo system works: [docs/ECHO_SYSTEM.md](docs/ECHO_SYSTEM.md)
- Contributing: [CONTRIBUTING.md](CONTRIBUTING.md)

## Version history

Every milestone is a git tag, so you can check out any stage (`git checkout v0.3`).
Full notes are in [CHANGELOG.md](CHANGELOG.md).

| Tag | Milestone |
|---|---|
| `v0.1` | Initial prototype: side-view movement, ASCII level builder ![](screenshots/v0.1-prototype.png) |
| `v0.2` | Prison environment: original pixel art, interactive objects (side view) |
| `v0.3` | **Switched to top-down 3/4**: procedural prison map, lighting and shadows, guard AI |
| `v0.4` | The Echo system: frame-accurate record and replay that interacts with the world |
| `v0.5` | Full campaign, verified solvable by bot playthroughs |
| `v0.6` | Audio, story, menus, settings and saving |
| `v0.9` | Beta: Mobile renderer (2–3× faster lighting), balance fixes |
| `v1.0` | Release: safe checkpoints, documentation, GIF, export preset |

The view changed from side-scrolling to top-down at v0.3 at the project owner's request.
The earlier versions stay in history as the original prototype.

## Technology

Godot 4.7, typed GDScript. Art made in Python with Pillow (pixel by pixel, using
[pixel-art-studio](https://github.com/Gamezxz/pixel-art-studio)'s `pixelstudio.py`). Audio
synthesised with numpy. No engine plugins.

## Credits and license

Code and original assets: MIT ([LICENSE](LICENSE)). Fonts: Silkscreen and Pixelify Sans (OFL).
Some sound effects: *RPG Sound Pack* by artisticdude (CC0). Full details in
[ASSET_CREDITS.md](ASSET_CREDITS.md).
