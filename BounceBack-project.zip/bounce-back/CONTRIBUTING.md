# Contributing

Thanks for your interest in BOUNCE BACK!

## Setup
1. Install [Godot 4.7](https://godotengine.org/download) (standard build, not .NET).
2. Open `project.godot` in the editor and press Play (main scene: `scenes/menus/MainMenu.tscn`).
3. Optional, for the asset generators: Python 3 with `pillow` and `numpy`.

## Tests
```
tools/run_tests.sh            # whole suite
tools/run_tests.sh zone2      # only tests whose name contains "zone2"
```
The wrapper fails on *any* engine or script error, not only on failed checks. Set `GODOT` to
point at your Godot binary if it isn't at `../tools/`. Tests write to `user://test_save.json`
and never touch a real save. Please run the whole suite before opening a pull request.

## Where things live
- The prison layout is code: `scripts/world/MapGen.gd` (`_layout()`). Carve rooms with
  `carve()` / `ellipse()`, place entities with `add(type, x, y, {...})`, link objects with
  `"targets": [ids]`. `tests/test_world.gd` checks connectivity and placement, and
  `tests/test_solutions.gd` checks that every puzzle can still be solved. Update both when
  you change a zone.
- Read [docs/ARCHITECTURE.md](docs/ARCHITECTURE.md) and [docs/ECHO_SYSTEM.md](docs/ECHO_SYSTEM.md) first.

## Code style
- Typed GDScript, tabs, `snake_case` members, `PascalCase` classes, one responsibility per script.
- Systems communicate through signals and autoloads, not hard-coded node paths.
- Objects an Echo may use must set `echo_compatible = true` explicitly.

## Art and audio
- Original pixel art is drawn by `tools/art/td_*.py`, and original audio by
  `tools/audio/make_audio.py`. Edit the script and re-run it; don't hand-edit the outputs.
- Every third-party asset needs a verified license, recorded in `ASSET_CREDITS.md` with the
  license text next to the files.

## Commits
Short imperative subjects (`Add floodlight power lever`, `Fix Echo stall at bars`).
