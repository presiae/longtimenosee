extends Node
## The generated prison: connectivity, entity placement, links, guard sight and hearing.

var runner


func _world() -> World:
	LevelManager.new_game()
	var w := World.new()
	add_child(w)
	await runner.physics_frames(3)
	return w


func cleanup() -> void:
	for c in get_children():
		c.queue_free()
	await runner.physics_frames(2)


func test_map_is_connected_start_to_exit() -> void:
	var m := MapGen.prison()
	var start := Vector2i(-1, -1)
	var exit := Vector2i(-1, -1)
	for e: Dictionary in m.entities:
		if e.type == "start":
			start = Vector2i(int(e.cell[0]), int(e.cell[1]))
		elif e.type == "exit":
			exit = Vector2i(int(e.cell[0]), int(e.cell[1]))
	var seen := {start: true}
	var q := [start]
	while not q.is_empty():
		var c: Vector2i = q.pop_front()
		for d in [Vector2i.LEFT, Vector2i.RIGHT, Vector2i.UP, Vector2i.DOWN]:
			var n: Vector2i = c + d
			if m.is_floor(n.x, n.y) and not seen.has(n):
				seen[n] = true
				q.append(n)
	runner.check(seen.has(exit), "exit reachable from the cell (ignoring doors)")
	runner.check(seen.size() > 1500, "large walkable map (%d cells)" % seen.size())


func test_entities_stand_on_floor() -> void:
	var m := MapGen.prison()
	var bad := []
	for e: Dictionary in m.entities:
		if e.type in ["hint", "camera"]:
			continue
		var c := Vector2i(int(e.cell[0]), int(e.cell[1]))
		if not m.is_floor(c.x, c.y):
			bad.append("%s@%s" % [e.type, c])
	runner.check(bad.is_empty(), "entities on solid cells: %s" % [bad])


func test_doors_sit_in_wall_gaps() -> void:
	var m := MapGen.prison()
	var bad := []
	for e: Dictionary in m.entities:
		if e.type != "door" or e.get("style", "") == "gate":
			continue
		var c := Vector2i(int(e.cell[0]), int(e.cell[1]))
		var h := not m.is_floor(c.x - 1, c.y) and not m.is_floor(c.x + 1, c.y)
		var v := not m.is_floor(c.x, c.y - 1) and not m.is_floor(c.x, c.y + 1)
		if not (h or v):
			bad.append(str(c))
	runner.check(bad.is_empty(), "doors not in a 1-wide gap: %s" % [bad])


func test_world_builds_and_links() -> void:
	var w := await _world()
	runner.check(w.objects.has("main_gate") and w.objects.has("cell_door"), "key objects exist")
	runner.check(w.get_tree().get_nodes_in_group("guards").size() >= 7, "guards spawned")
	var gate: Door = w.objects["main_gate"]
	runner.check(gate.expected_inputs == 1, "gate wired to its AND gate")
	var andg: LevelObject = w.objects["gate_and"]
	runner.check(andg.expected_inputs == 2 and andg.require_all, "gate AND has two plates")


func test_and_gate_needs_both_plates() -> void:
	var w := await _world()
	var gate: Door = w.objects["main_gate"]
	w.objects["gate_and"].set_input("gate_plate_a", true)
	await runner.physics_frames(2)
	runner.check(not gate.is_open, "one plate is not enough")
	w.objects["gate_and"].set_input("gate_plate_b", true)
	await runner.physics_frames(2)
	runner.check(gate.is_open, "both plates open the gate")


func test_guard_sees_player_in_front_not_behind() -> void:
	var w := await _world()
	var g: GuardAI = w.objects["g_post"]
	g.set_physics_process(false)
	var p := w.player
	p.global_position = g.global_position + Vector2(80, 0)
	g.facing = Vector2.RIGHT
	await runner.physics_frames(2)
	runner.check(DetectionSystem.guard_sees(g, g.eye(), g.facing, p, w) > 0.0, "sees player 80px ahead")
	g.facing = Vector2.LEFT
	runner.check(DetectionSystem.guard_sees(g, g.eye(), g.facing, p, w) == 0.0, "doesn't see player behind")
	p.global_position = g.global_position + Vector2(20, 0)
	await runner.physics_frames(2)
	runner.check(DetectionSystem.guard_sees(g, g.eye(), g.facing, p, w) > 0.0, "close radius notices from behind")


func test_guard_hears_loud_noise_and_investigates() -> void:
	var w := await _world()
	var g: GuardAI = w.objects["g_post"]
	w.player.global_position = MapBuilder.cell_feet(Vector2i(5, 6))
	NoiseManager.emit_noise(MapBuilder.cell_feet(Vector2i(6, 9)), 1.0, null, "bang")
	runner.check(g.fsm.state == GuardStateMachine.S.INVESTIGATE, "guard investigates the bars (%s)" % g.fsm.state_name())
	var x0 := g.global_position.x
	await runner.physics_frames(120)
	runner.check(g.global_position.x < x0 - 40.0, "guard walked toward the noise (%.0f -> %.0f)" % [x0, g.global_position.x])


func test_guard_catches_player_in_view() -> void:
	var w := await _world()
	var caught := []
	w.player_caught.connect(func(r: String) -> void: caught.append(r))
	var g: GuardAI = w.objects["g_post"]
	w.player.global_position = g.global_position + Vector2(90, 0)
	await runner.physics_frames(150)
	runner.check(not caught.is_empty(), "player caught (guard state %s)" % g.fsm.state_name())


func test_hidden_player_is_not_seen() -> void:
	var w := await _world()
	var g: GuardAI = w.objects["g_post"]
	g.set_physics_process(false)
	var p := w.player
	p.global_position = g.global_position + Vector2(60, 0)
	g.facing = Vector2.RIGHT
	p.is_hidden = true
	await runner.physics_frames(2)
	runner.check(DetectionSystem.guard_sees(g, g.eye(), g.facing, p, w) == 0.0, "hidden player invisible")
	p.is_hidden = false
