extends Node
## Save/load round trip, settings persistence, and smoke tests that every menu scene loads
## and runs without errors. Uses separate files so a real save is never touched.

var runner
var _orig_save := ""
var _orig_settings := ""


func _use_test_files() -> void:
	_orig_save = SaveManager.SAVE_PATH
	_orig_settings = SaveManager.SETTINGS_PATH
	SaveManager.SAVE_PATH = "user://test_save.json"
	SaveManager.SETTINGS_PATH = "user://test_settings.cfg"


func cleanup() -> void:
	if _orig_save != "":
		SaveManager.delete_progress()
		DirAccess.remove_absolute(ProjectSettings.globalize_path(SaveManager.SETTINGS_PATH))
		SaveManager.SAVE_PATH = _orig_save
		SaveManager.SETTINGS_PATH = _orig_settings
		_orig_save = ""
		SaveManager.load_settings()
	for c in get_children():
		c.queue_free()
	get_tree().paused = false
	await runner.physics_frames(2)


func test_progress_round_trip() -> void:
	_use_test_files()
	LevelManager.new_game()
	LevelManager.collect("card_red", {"key": "red"})
	LevelManager.collect("shard_1", {"shard": true})
	LevelManager.collect("note_cell", {"note": "note_cell", "title": "T", "text": "X"})
	LevelManager.reach_checkpoint(2)
	LevelManager.attempts_total = 7
	SaveManager.save_progress()
	runner.check(SaveManager.has_save(), "save file written")
	LevelManager.new_game()
	runner.check(LevelManager.checkpoint == 0, "state cleared")
	runner.check(SaveManager.load_progress(), "save loads")
	runner.check(LevelManager.checkpoint == 2, "checkpoint restored")
	runner.check(LevelManager.has_key("red"), "keycard restored")
	runner.check(LevelManager.echo_capacity() == 2, "Echo capacity upgrade restored")
	runner.check(LevelManager.notes().size() == 1, "collected note restored")
	runner.check(LevelManager.attempts_total == 7, "attempt count restored")
	LevelManager.new_game()


func test_settings_persist() -> void:
	_use_test_files()
	SaveManager.set_setting("music_volume", 0.25)
	SaveManager.set_setting("screen_shake", false)
	SaveManager.settings.clear()
	SaveManager.load_settings()
	runner.check(is_equal_approx(float(SaveManager.get_setting("music_volume")), 0.25), "music volume persisted")
	runner.check(SaveManager.get_setting("screen_shake") == false, "screen shake persisted")
	var bus := AudioServer.get_bus_index("Music")
	runner.check(bus != -1 and absf(AudioServer.get_bus_volume_db(bus) - linear_to_db(0.25)) < 0.1, "music bus volume applied")


func test_menu_scenes_run() -> void:
	_use_test_files()
	for path in ["res://scenes/menus/MainMenu.tscn", "res://scenes/menus/Credits.tscn", "res://scenes/menus/Ending.tscn"]:
		var s: Node = load(path).instantiate()
		add_child(s)
		await runner.physics_frames(45)
		runner.check(is_instance_valid(s), "%s runs" % path)
		s.queue_free()
		await runner.physics_frames(2)


func test_game_scene_pause_menu() -> void:
	_use_test_files()
	LevelManager.new_game()
	EchoManager.reset()
	var g: Game = load("res://scenes/Game.tscn").instantiate()
	add_child(g)
	await runner.physics_frames(5)
	g.pause_menu.open()
	runner.check(get_tree().paused, "pause menu pauses the game")
	g.pause_menu.close()
	runner.check(not get_tree().paused, "resume unpauses")
	g.queue_free()
	EchoManager.reset()


func test_story_card_after_first_capture() -> void:
	_use_test_files()
	LevelManager.new_game()
	EchoManager.reset()
	var g: Game = load("res://scenes/Game.tscn").instantiate()
	add_child(g)
	await runner.physics_frames(30)
	g.restart_attempt("caught")
	await runner.physics_frames(60)
	runner.check(g.story_seen.has("echo"), "'BUT SOMETHING FOLLOWED ME BACK' shown after the first capture")
	g.queue_free()
	EchoManager.reset()
