extends Node
## End-to-end playthroughs of the intended puzzle solutions, with a waypoint bot driving the
## player through the real game loop (real guards, real noise, real Echo recording).

var runner
var game: Game
var caught := []


func _start() -> void:
	LevelManager.new_game()
	EchoManager.reset()
	caught.clear()
	game = load("res://scenes/Game.tscn").instantiate()
	add_child(game)
	game.attempt_started.connect(func(_a: int) -> void: _hook())
	await runner.physics_frames(2)
	_hook()


func _hook() -> void:
	game.world.player.bot_input = {"move": Vector2.ZERO}
	if not game.world.player_caught.is_connected(_on_caught):
		game.world.player_caught.connect(_on_caught)


func _on_caught(r: String) -> void:
	caught.append(r)


func cleanup() -> void:
	if is_instance_valid(game):
		game.queue_free()
	EchoManager.reset()
	await runner.physics_frames(2)


func _p() -> PlayerController:
	return game.world.player


## Walk straight toward a cell's feet point. Returns false on timeout or capture.
func go(cell: Vector2i, run := false, sneak := false, max_frames := 600) -> bool:
	var target := MapBuilder.cell_feet(cell)
	for i in max_frames:
		var p := _p()
		if p.caught:
			return false
		var to := target - p.global_position
		if to.length() < 4.0:
			p.bot_input = {"move": Vector2.ZERO}
			return true
		p.bot_input = {"move": to.normalized() * clampf(to.length() / 12.0, 0.35, 1.0), "run": run, "sneak": sneak}
		await get_tree().physics_frame
	return false


func wait(frames: int) -> void:
	_p().bot_input = {"move": Vector2.ZERO}
	await runner.physics_frames(frames)


func interact() -> bool:
	var ok := _p().try_interact()
	if not ok:
		var t: Interactable = _p().interaction.target
		print("    interact failed at ", MapBuilder.world_to_cell(_p().global_position), " target=", t.object_id if t else "none")
	return ok


func _vent_route() -> bool:
	if not await go(Vector2i(8, 5)):
		return false
	if not interact():
		return false
	for c in [Vector2i(10, 5), Vector2i(16, 5), Vector2i(16, 9), Vector2i(19, 10), Vector2i(22, 10)]:
		if not await go(c):
			return false
	return true


func test_zone1_first_attempt_gets_caught() -> void:
	await _start()
	var ok := await _vent_route()
	runner.check(not ok and not caught.is_empty(), "the post guard catches a prisoner who just runs (caught=%s)" % [caught])


func test_zone1_echo_rattles_bars_and_you_slip_out() -> void:
	await _start()
	# Attempt 1: rattle the bars, then bounce back.
	runner.check(await go(Vector2i(6, 7)), "reach the cell bars")
	runner.check(interact(), "rattle the bars")
	await wait(30)
	game.restart_attempt("restart")
	await runner.physics_frames(1)
	_hook()
	runner.check(get_tree().get_nodes_in_group("echo").size() == 1, "the Echo is here")
	# Attempt 2: while the Echo rattles the bars, take the vent.
	var ok := await _vent_route()
	runner.check(ok, "escaped through the vent while the guard checked the bars (caught=%s)" % [caught])
	await wait(10)
	runner.check(LevelManager.checkpoint >= 1, "reached the cell block checkpoint")


# ---------------------------------------------------------------- later zones
# Zones 2-5 check that every Echo puzzle is mechanically solvable. Guards are frozen here
# so the run is deterministic; stealth around them is covered by the guard tests and the
# live Zone 1 playthrough above.

var frozen := false


func _start_at(checkpoint: int, shards: int) -> void:
	LevelManager.new_game()
	EchoManager.reset()
	LevelManager.checkpoint = checkpoint
	for i in shards:
		LevelManager.collected_global["shard_%d" % (i + 1)] = {"shard": true}
	caught.clear()
	frozen = true
	game = load("res://scenes/Game.tscn").instantiate()
	add_child(game)
	game.attempt_started.connect(func(_a: int) -> void: _hook_frozen())
	await runner.physics_frames(2)
	_hook_frozen()


func _hook_frozen() -> void:
	_hook()
	for g in get_tree().get_nodes_in_group("guards"):
		g.set_physics_process(false)
	if game.world.exited.is_connected(game._on_exited):
		game.world.exited.disconnect(game._on_exited)


func _route(cells: Array) -> bool:
	for c: Vector2i in cells:
		if not await go(c, false, false, 900):
			print("    bot stuck going to ", c, " at ", MapBuilder.world_to_cell(_p().global_position))
			return false
	return true


func _bounce() -> void:
	game.restart_attempt("restart")
	await runner.physics_frames(1)


func test_zone2_echo_pulls_lever_for_timed_gate() -> void:
	await _start_at(1, 0)
	var to_lever := [Vector2i(24, 11), Vector2i(34, 11), Vector2i(34, 8)]
	runner.check(await _route(to_lever), "reach the store room door")
	runner.check(interact(), "open the store room door")
	runner.check(await _route([Vector2i(34, 6), Vector2i(35, 4)]), "reach the lever")
	runner.check(interact(), "pull the lever")
	var gate: Door = game.world.objects["south_gate"]
	await wait(150)
	runner.check(not gate.is_open, "the gate shut again before anyone could reach it")
	await _bounce()
	runner.check(await _route([Vector2i(24, 12), Vector2i(31, 12), Vector2i(31, 13)]), "wait at the south gate")
	var opened := false
	for i in 900:
		await get_tree().physics_frame
		if game.world.objects["south_gate"].is_open:
			opened = true
			break
	runner.check(opened, "the Echo's lever pull opened the gate")
	runner.check(await _route([Vector2i(31, 15), Vector2i(31, 19)]), "walk through the timed gate")


func test_zone3_two_echoes_and_the_control_room() -> void:
	await _start_at(2, 1)
	for c in get_tree().get_nodes_in_group("cameras"):
		c.set_physics_process(false)
	var hall := [Vector2i(31, 24), Vector2i(30, 27)]
	runner.check(await _route(hall + [Vector2i(10, 27), Vector2i(10, 25), Vector2i(10, 23)]), "Echo 1 route to plate A")
	await wait(900)
	await _bounce()
	for c in get_tree().get_nodes_in_group("cameras"):
		c.set_physics_process(false)
	runner.check(await _route(hall + [Vector2i(18, 27), Vector2i(18, 29), Vector2i(18, 31)]), "Echo 2 route to plate B")
	await wait(900)
	await _bounce()
	for c in get_tree().get_nodes_in_group("cameras"):
		c.set_physics_process(false)
	runner.check(EchoManager.active.size() == 2, "two Echoes walking")
	runner.check(await _route(hall + [Vector2i(25, 28)]), "player waits at the control room")
	var door: Door = game.world.objects["control_door"]
	var opened := false
	for i in 1200:
		await get_tree().physics_frame
		if door.is_open:
			opened = true
			break
	runner.check(opened, "both Echoes on both plates opened the control room")
	runner.check(await _route([Vector2i(25, 30), Vector2i(23, 31)]) and interact(), "take the red keycard")
	runner.check(LevelManager.has_key("red"), "holding the red keycard")
	runner.check(await _route([Vector2i(28, 31)]) and interact(), "take the second Echo shard")
	runner.check(LevelManager.echo_capacity() == 3, "Echo capacity is now 3")
	await wait(1200)   # echoes finish; the door closes behind you
	runner.check(not door.is_open, "door closed after the Echoes faded")
	runner.check(await _route([Vector2i(27, 30)]) and interact(), "inside lever opens the door")
	await wait(20)
	runner.check(await _route([Vector2i(25, 29), Vector2i(25, 27), Vector2i(41, 27)]), "out to the red door")
	runner.check(interact(), "unlock the red door with the keycard")
	await wait(30)
	runner.check(await _route([Vector2i(45, 27), Vector2i(47, 27)]), "into the yard")
	runner.check(LevelManager.checkpoint == 3, "yard checkpoint reached")


func test_zone4_floodlights_gate_and_escape() -> void:
	await _start_at(3, 2)
	var exited := []
	# Echo A: cut the floodlights, then hold plate A.
	runner.check(await _route([Vector2i(56, 27), Vector2i(61, 31), Vector2i(66, 31), Vector2i(66, 29), Vector2i(68, 27)]), "reach the generator lever")
	runner.check(interact(), "cut the floodlight power")
	runner.check(not game.world.objects["tower_1"].enabled and not game.world.objects["tower_2"].enabled, "both floodlights off")
	runner.check(await _route([Vector2i(66, 29), Vector2i(66, 31), Vector2i(66, 39), Vector2i(64, 39)]), "Echo A to plate A")
	await wait(1500)
	await _bounce()
	_hook_frozen()
	# Echo B: hold plate B.
	runner.check(await _route([Vector2i(56, 27), Vector2i(61, 31), Vector2i(67, 32), Vector2i(72, 33), Vector2i(76, 33), Vector2i(76, 39)]), "Echo B to plate B")
	await wait(1500)
	await _bounce()
	_hook_frozen()
	game.world.exited.connect(func() -> void: exited.append(true))
	runner.check(EchoManager.active.size() == 2, "two Echoes walking")
	runner.check(await _route([Vector2i(56, 27), Vector2i(61, 31), Vector2i(67, 32), Vector2i(70, 34), Vector2i(70, 39)]), "player waits at the gate")
	var gate: Door = game.world.objects["main_gate"]
	var opened := false
	for i in 1500:
		await get_tree().physics_frame
		if gate.is_open:
			opened = true
			break
	runner.check(opened, "two Echoes on the gate plates opened the main gate")
	runner.check(not game.world.objects["tower_2"].enabled, "Echo A cut the floodlights first")
	runner.check(await _route([Vector2i(70, 42), Vector2i(70, 46), Vector2i(70, 50), Vector2i(82, 50)]), "through the gate and down the road")
	await wait(5)
	runner.check(not exited.is_empty(), "reached the exit: the game can be finished")


func test_zone2_live_guards_wait_in_locker() -> void:
	# Echo recorded with guards frozen; the real attempt runs with LIVE guards: sneak to the
	# locker beside the gate, wait inside, step out when the Echo's lever pull opens it.
	await _start_at(1, 0)
	await wait(900)   # give my future self time to reach the locker
	runner.check(await _route([Vector2i(24, 11), Vector2i(34, 11), Vector2i(34, 8)]) and interact(), "Echo: open store door")
	runner.check(await _route([Vector2i(34, 6), Vector2i(35, 4)]) and interact(), "Echo: pull lever")
	await wait(30)
	frozen = false
	game.attempt_started.connect(func(_a: int) -> void: _hook(), CONNECT_ONE_SHOT)
	game.restart_attempt("restart")
	await runner.physics_frames(1)
	for g in get_tree().get_nodes_in_group("guards"):
		g.set_physics_process(true)
	_hook()
	var ok := true
	for c in [Vector2i(22, 13), Vector2i(26, 13), Vector2i(26, 12), Vector2i(28, 12), Vector2i(28, 13), Vector2i(31, 13)]:
		ok = ok and await go(c, false, true, 1200)   # sneak along the dark south wall
	if ok:
		var locker: HidingSpot = game.world.objects["gate_locker"]
		ok = locker.try_interact(_p())
	runner.check(ok and caught.is_empty(), "reached the gate locker unseen (caught=%s)" % [caught])
	if not ok:
		return
	var gate: Door = game.world.objects["south_gate"]
	var opened := false
	for i in 900:
		await get_tree().physics_frame
		if gate.is_open:
			opened = true
			break
	runner.check(opened, "gate opened by the Echo while hiding")
	game.world.objects["gate_locker"].try_interact(_p())
	runner.check(await _route([Vector2i(31, 14), Vector2i(31, 17)]), "slipped through before it closed")
	runner.check(caught.is_empty(), "never caught (caught=%s)" % [caught])


func test_every_checkpoint_is_a_safe_restart() -> void:
	# Respawning must never put you straight into a guard's arms (no capture loops).
	for cp in [0, 1, 2, 3]:
		await _start_at(cp, 2)
		for g in get_tree().get_nodes_in_group("guards"):
			g.set_physics_process(true)
		await wait(600)
		runner.check(caught.is_empty(), "idle 10 s at checkpoint %d with live guards: not caught (%s)" % [cp, caught])
		game.queue_free()
		EchoManager.reset()
		await runner.physics_frames(2)
