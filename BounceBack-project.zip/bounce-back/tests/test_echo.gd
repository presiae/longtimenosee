extends Node
## The Echo system: recording, faithful playback, interactions, plates, noise, stalls,
## capacity and checkpoint release. Drives the player with scripted input.

var runner
var game: Game


func _start() -> void:
	LevelManager.new_game()
	EchoManager.reset()
	game = load("res://scenes/Game.tscn").instantiate()
	add_child(game)
	await runner.physics_frames(2)
	_prep()


func _prep() -> void:
	game.world.player.bot_input = {"move": Vector2.ZERO}
	# Keep tests deterministic: freeze guards unless a test wants them.
	for g in get_tree().get_nodes_in_group("guards"):
		g.set_physics_process(false)


func cleanup() -> void:
	if is_instance_valid(game):
		game.queue_free()
	EchoManager.reset()
	await runner.physics_frames(2)


func _drive(frames: int, input: Vector2, sneak := false, run := false) -> void:
	game.world.player.bot_input = {"move": input, "sneak": sneak, "run": run}
	await runner.physics_frames(frames)
	game.world.player.bot_input = {"move": Vector2.ZERO}


func _restart() -> void:
	game.restart_attempt("restart")
	await runner.physics_frames(1)
	_prep()


func _echo() -> Echo:
	var list := get_tree().get_nodes_in_group("echo")
	return list[0] if not list.is_empty() else null


func test_recording_captures_movement() -> void:
	await _start()
	await _drive(40, Vector2.RIGHT)
	await _drive(20, Vector2.DOWN)
	var rec: EchoRecording = EchoManager.recorder.recording
	runner.check(rec.frame_count() >= 60, "recorded %d frames" % rec.frame_count())
	runner.check(rec.positions[rec.frame_count() - 1].distance_to(game.world.player.global_position) < 0.01, "last frame = player position")


func test_echo_replays_path_exactly() -> void:
	await _start()
	await _drive(20, Vector2(1, 0))
	await _drive(30, Vector2(1, 0.5))
	var path: PackedVector2Array = EchoManager.recorder.recording.positions.duplicate()
	await _restart()
	var e := _echo()
	runner.check(e != null, "an Echo spawned on the next attempt")
	if e == null:
		return
	var max_err := 0.0
	for i in 45:
		await get_tree().physics_frame
		max_err = maxf(max_err, e.global_position.distance_to(path[e.frame]))
	runner.check(max_err < 0.01, "echo follows its recording exactly (max error %.4f px)" % max_err)
	runner.check(e.frame >= 44, "playback advanced in step with physics (frame %d)" % e.frame)


func test_echo_repeats_interaction_with_vent() -> void:
	await _start()
	var p: PlayerController = game.world.player
	var vent: Vent = game.world.objects["cell_vent"]
	# Walk to the vent, open it, then bounce back.
	p.global_position = vent.global_position + Vector2(-28, 6)
	await _drive(15, Vector2.ZERO)
	runner.check(p.try_interact(), "player pries the vent open")
	await _drive(20, Vector2.ZERO)
	await _restart()
	var vent2: Vent = game.world.objects["cell_vent"]
	runner.check(not vent2.is_open, "vent closed again in the new attempt")
	await runner.physics_frames(30)
	runner.check(vent2.is_open, "the Echo pried the vent open at the same moment")


func test_echo_cannot_pick_up_items() -> void:
	await _start()
	var e := Echo.new()
	var rec := EchoRecording.new()
	rec.add_frame(Vector2.ZERO, Vector2.DOWN, "idle_down", 0)
	e.setup(rec, game.world, 0)
	game.world.entities.add_child(e)
	var bottle: Pickup = null
	for o in game.world.objects.values():
		if o is Pickup and o.kind == "bottle":
			bottle = o
			break
	runner.check(not bottle.try_interact(e), "echo can't take a bottle")
	var gate: Door = game.world.objects["main_gate"]
	runner.check(not gate.try_interact(e), "echo can't use a switch-only gate")


func test_echo_holds_pressure_plate() -> void:
	await _start()
	var plate: PressurePlate = game.world.objects["plate_a"]
	var p: PlayerController = game.world.player
	p.global_position = plate.global_position + Vector2(0, 40)
	await _drive(10, Vector2.ZERO)
	await _drive(28, Vector2.UP)     # onto the plate
	await _drive(60, Vector2.ZERO)   # stand on it
	await _restart()
	game.world.player.global_position = MapBuilder.cell_feet(Vector2i(36, 27))
	var plate2: PressurePlate = game.world.objects["plate_a"]
	await runner.physics_frames(50)
	var e := _echo()
	runner.check(plate2.is_pressed(), "Echo stands on the plate in the next attempt (echo at %s, plate at %s)" % [e.global_position if e else "none", plate2.global_position])


func test_two_echoes_open_control_room() -> void:
	await _start()
	LevelManager.collected_global["shard_test"] = {"shard": true}   # capacity 2
	var w: World = game.world
	for plate_id in ["plate_a", "plate_b"]:
		var pl: PressurePlate = game.world.objects[plate_id]
		game.world.player.global_position = pl.global_position + Vector2(0, 4)
		await _drive(90, Vector2.ZERO)
		await _restart()
	runner.check(EchoManager.recordings.size() == 2, "two Echoes stored")
	game.world.player.global_position = MapBuilder.cell_feet(Vector2i(36, 27))
	await runner.physics_frames(30)
	var door: Door = game.world.objects["control_door"]
	runner.check(door.is_open, "both Echoes on both plates open the control room")
	LevelManager.collected_global.erase("shard_test")


func test_echo_noise_lures_guard() -> void:
	await _start()
	var p: PlayerController = game.world.player
	var bars: NoiseSource = game.world.objects["bars"]
	p.global_position = bars.global_position + Vector2(0, -6)
	await _drive(5, Vector2.ZERO)
	runner.check(p.try_interact(), "player rattles the bars")
	await _drive(30, Vector2.ZERO)
	await _restart()
	var g: GuardAI = game.world.objects["g_post"]
	g.set_physics_process(true)
	var x0 := g.global_position.x
	await runner.physics_frames(150)
	runner.check(g.global_position.x < x0 - 60.0, "the Echo's rattle drew the post guard away (%.0f -> %.0f)" % [x0, g.global_position.x])


func test_blocked_echo_stalls_then_dissolves() -> void:
	await _start()
	var rec := EchoRecording.new()
	var door: Door = game.world.objects["store_door"]   # manual door, closed
	for i in 60:
		rec.add_frame(door.global_position + Vector2(0, 40 - i * 1.5), Vector2.UP, "walk_up", 0)
	var e := Echo.new()
	e.setup(rec, game.world, 0)
	game.world.entities.add_child(e)
	await runner.physics_frames(40)
	runner.check(e.stalled_t > 0.0, "echo stalls at the closed door")
	await runner.physics_frames(150)
	runner.check(not is_instance_valid(e) or e._done, "stalled echo dissolves gracefully")


func test_capacity_drops_oldest() -> void:
	await _start()
	await _drive(40, Vector2.RIGHT)
	await _restart()
	var first := EchoManager.recordings[0]
	await _drive(40, Vector2.LEFT)
	await _restart()
	runner.check(EchoManager.recordings.size() == 1, "capacity 1 keeps one Echo")
	runner.check(EchoManager.recordings[0] != first, "the newest attempt replaced the oldest")


func test_checkpoint_releases_echoes() -> void:
	await _start()
	await _drive(40, Vector2.RIGHT)
	await _restart()
	runner.check(EchoManager.recordings.size() == 1, "one Echo stored")
	LevelManager.reach_checkpoint(1)
	runner.check(EchoManager.recordings.is_empty(), "checkpoint released the Echoes")
	runner.check(EchoManager.recorder.recording.start_checkpoint == 1, "recording restarts from the checkpoint")


func test_short_attempts_leave_no_echo() -> void:
	await _start()
	await _drive(5, Vector2.RIGHT)
	await _restart()
	runner.check(EchoManager.recordings.is_empty(), "a tiny attempt doesn't create an Echo")
