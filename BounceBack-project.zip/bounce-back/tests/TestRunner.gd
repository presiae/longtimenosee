extends Node
## Headless test runner. Run with:
##   godot --headless res://tests/TestRunner.tscn
## Every test_* method on every suite is awaited in turn. Exit code = failures.

const SUITES := [
	"res://tests/test_world.gd",
	"res://tests/test_echo.gd",
	"res://tests/test_solutions.gd",
	"res://tests/test_save_ui.gd",
]

var failures := 0
var passes := 0
var _current := ""


func _ready() -> void:
	await get_tree().process_frame
	# Never touch the player's real save or settings while testing.
	SaveManager.SAVE_PATH = "user://test_save.json"
	SaveManager.SETTINGS_PATH = "user://test_settings.cfg"
	var only := OS.get_environment("BB_TEST")
	for path: String in SUITES:
		var script: GDScript = load(path)
		if script == null or not script.can_instantiate():
			failures += 1
			print("  FAIL ", path, " — suite failed to load")
			continue
		var suite: Node = script.new()
		suite.set("runner", self)
		add_child(suite)
		for m in suite.get_method_list():
			var mname: String = m.name
			if not mname.begins_with("test_"):
				continue
			if only != "" and not mname.contains(only):
				continue
			_current = "%s::%s" % [path.get_file(), mname]
			var before := failures
			await suite.call(mname)
			if failures == before:
				passes += 1
				print("  PASS ", _current)
			if suite.has_method("cleanup"):
				await suite.cleanup()
		suite.queue_free()
	SaveManager.delete_progress()
	print("\nRESULT: %d passed, %d failed" % [passes, failures])
	get_tree().quit(failures)


func check(cond: bool, msg: String) -> bool:
	if not cond:
		failures += 1
		print("  FAIL ", _current, " â€” ", msg)
	return cond


func physics_frames(n: int) -> void:
	for i in n:
		await get_tree().physics_frame
