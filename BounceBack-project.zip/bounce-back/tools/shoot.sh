#!/usr/bin/env bash
# Usage: tools/shoot.sh <out.png> <cell x,y> [frames] [extra env...]
# Captures a real in-game screenshot with the player placed at a map cell.
cd "$(dirname "$0")/.."
GODOT="${GODOT:-../tools/Godot_v4.7.2-stable_win64_console.exe}"
out="$1"; cell="$2"; frames="${3:-70}"
case "$out" in /*) ;; *) out="$(cygpath -m "$PWD")/$out" ;; esac
BB_SHOT_SCRIPT=res://tools/shots/place.gd BB_SHOT_CELL="$cell" BB_SHOT="$out" BB_SHOT_SCALE=1 \
  BB_SHOT_FRAMES="$frames" timeout 90 "$GODOT" res://scenes/Game.tscn 2>&1 | grep -E "ERROR|saved"
