"""Original procedural audio for BOUNCE BACK (numpy). Writes 16-bit mono WAVs.

  assets/audio/sfx/*.wav       short effects
  assets/audio/ambient/*.wav   seamless zone ambience loops
  assets/audio/music/*.wav     three intensity layers that play in sync (calm / tension / chase)
Run from repo root:  python tools/audio/make_audio.py
"""
import os, wave
import numpy as np

SR = 22050
rng = np.random.default_rng(1979)
OUT = "assets/audio"


def save(path, x, sr=SR, peak=0.9):
    x = np.asarray(x, dtype=np.float64)
    m = np.max(np.abs(x)) or 1.0
    x = np.clip(x / m * peak, -1, 1)
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with wave.open(path, "wb") as w:
        w.setnchannels(1)
        w.setsampwidth(2)
        w.setframerate(sr)
        w.writeframes((x * 32767).astype("<i2").tobytes())


def t(sec):
    return np.arange(int(sec * SR)) / SR


def ts(n):
    """Time axis for exactly n samples."""
    return np.arange(int(n)) / SR


def env(n, a=0.005, d=0.2, curve=4.0):
    tt = np.arange(n) / SR
    att = np.clip(tt / max(a, 1e-4), 0, 1)
    dec = np.exp(-np.maximum(tt - a, 0) / max(d, 1e-4) * (curve / 4.0) * 4.0 / 4.0)
    return att * dec


def lowpass(x, cutoff):
    a = np.exp(-2 * np.pi * cutoff / SR)
    y = np.zeros_like(x)
    acc = 0.0
    for i in range(len(x)):
        acc = (1 - a) * x[i] + a * acc
        y[i] = acc
    return y


def lp_fast(x, cutoff):
    """Vectorised-enough one-pole low-pass using scipy-free recursion in chunks."""
    a = np.exp(-2 * np.pi * cutoff / SR)
    b = 1 - a
    y = np.empty_like(x)
    acc = 0.0
    for i, v in enumerate(x):
        acc = b * v + a * acc
        y[i] = acc
    return y


def highpass(x, cutoff):
    return x - lp_fast(x, cutoff)


def noise(n):
    return rng.uniform(-1, 1, n)


def saw(f, tt):
    return 2 * ((tt * f) % 1.0) - 1


# ------------------------------------------------------------------ SFX
def footstep(hard=1.0, n_sec=0.12, tone=180):
    n = int(n_sec * SR)
    x = lp_fast(noise(n), 900 * hard) * env(n, 0.002, 0.03)
    x += 0.4 * np.sin(2 * np.pi * tone * ts(n)) * env(n, 0.001, 0.02)
    return x


def door_slide(open_=True):
    d = 0.75
    tt = t(d)
    n = len(tt)
    rumble = lp_fast(noise(n), 300) * (0.6 + 0.4 * np.sin(2 * np.pi * 9 * tt))
    servo_f = (140 if open_ else 190) + (60 if open_ else -50) * tt / d
    servo = 0.25 * saw(servo_f, tt)
    clunk_n = int(0.15 * SR)
    clunk = np.zeros(n)
    c = (lp_fast(noise(clunk_n), 500) + 0.6 * np.sin(2 * np.pi * 70 * ts(clunk_n))) * env(clunk_n, 0.001, 0.05)
    clunk[n - clunk_n:] += c
    e = np.clip(np.minimum(tt / 0.05, (d - tt) / 0.1), 0, 1)
    return (rumble + servo) * e * 0.7 + clunk * 1.2


def glass():
    d = 0.9
    n = int(d * SR)
    x = highpass(noise(n), 2500) * env(n, 0.001, 0.12)
    for k in range(9):
        f = rng.uniform(2500, 7000)
        start = int(rng.uniform(0, 0.25) * SR)
        m = n - start
        x[start:] += 0.35 * np.sin(2 * np.pi * f * ts(m)) * env(m, 0.001, rng.uniform(0.05, 0.25))
    return x


def bang():
    d = 0.8
    n = int(d * SR)
    x = lp_fast(noise(n), 1400) * env(n, 0.001, 0.08)
    for f in (92, 151, 236, 397):
        x += 0.5 * np.sin(2 * np.pi * f * ts(n)) * env(n, 0.001, 0.35)
    return x


def alarm():
    d = 2.0
    tt = t(d)
    f = 650 + 250 * np.sign(np.sin(2 * np.pi * 2 * tt))
    ph = np.cumsum(2 * np.pi * f / SR)
    x = np.sign(np.sin(ph)) * 0.5 + np.sin(ph * 2) * 0.2
    return lp_fast(x, 2500) * np.clip(np.minimum(tt / 0.02, (d - tt) / 0.2), 0, 1)


def alert():
    """Guard spots you: a sharp dissonant sting."""
    d = 0.7
    tt = t(d)
    n = len(tt)
    x = sum(saw(f, tt) for f in (233, 247, 466, 493)) * 0.25
    x = lp_fast(x, 3000) * env(n, 0.003, 0.25)
    x += lp_fast(noise(n), 4000) * env(n, 0.001, 0.03) * 0.6
    return x


def huh():
    """Suspicion: a rising questioning blip."""
    d = 0.35
    tt = t(d)
    f = 300 + 260 * (tt / d) ** 2
    ph = np.cumsum(2 * np.pi * f / SR)
    return (np.sin(ph) + 0.3 * np.sin(2 * ph)) * env(len(tt), 0.01, 0.12) * 0.7


def echo_spawn():
    """Shimmering reversed swell — an Echo arrives."""
    d = 1.3
    tt = t(d)
    x = np.zeros(len(tt))
    for k, f in enumerate((523, 659, 784, 1047, 1319)):
        x += np.sin(2 * np.pi * f * tt + k) * (0.6 + 0.4 * np.sin(2 * np.pi * (3 + k) * tt))
    sw = (tt / d) ** 2.2
    x *= sw * np.clip((d - tt) / 0.08, 0, 1)
    x += highpass(noise(len(tt)), 3000) * sw * 0.15
    return x


def checkpoint():
    d = 1.2
    tt = t(d)
    x = np.zeros(len(tt))
    for i, f in enumerate((392, 523, 659, 784)):
        s = int(i * 0.08 * SR)
        m = len(tt) - s
        x[s:] += np.sin(2 * np.pi * f * ts(m)) * env(m, 0.005, 0.5)
    return x


def shard():
    d = 1.5
    tt = t(d)
    x = np.zeros(len(tt))
    for i, f in enumerate((659, 988, 1319, 1976)):
        s = int(i * 0.06 * SR)
        m = len(tt) - s
        x[s:] += np.sin(2 * np.pi * f * ts(m)) * env(m, 0.003, 0.6) * (1.0 - i * 0.15)
    return x


def power(down=True):
    d = 0.9
    tt = t(d)
    f = (220 * np.exp(-tt * 3) + 40) if down else (40 + 200 * (tt / d))
    ph = np.cumsum(2 * np.pi * f / SR)
    x = saw(1, ph / (2 * np.pi)) * 0.4 + np.sin(ph) * 0.4
    return lp_fast(x, 1500) * np.clip(np.minimum(tt / 0.01, (d - tt) / 0.2), 0, 1)


def plate():
    n = int(0.25 * SR)
    return (lp_fast(noise(n), 600) * env(n, 0.001, 0.04) + 0.6 * np.sin(2 * np.pi * 110 * ts(n)) * env(n, 0.001, 0.08))


def beep(f=1300, d=0.12):
    tt = t(d)
    return np.sign(np.sin(2 * np.pi * f * tt)) * 0.4 * env(len(tt), 0.002, 0.05)


def keycard():
    return np.concatenate([beep(1500, 0.08), np.zeros(int(0.03 * SR)), beep(2000, 0.12)])


def vent():
    d = 0.6
    n = int(d * SR)
    x = lp_fast(noise(n), 2200) * env(n, 0.002, 0.15)
    for f in (310, 470, 830):
        x += 0.3 * np.sin(2 * np.pi * f * ts(n)) * env(n, 0.002, 0.2)
    return x


def paper():
    n = int(0.4 * SR)
    return highpass(noise(n), 1800) * env(n, 0.02, 0.12) * (0.5 + 0.5 * np.sin(2 * np.pi * 23 * ts(n)))


def caught():
    d = 1.6
    tt = t(d)
    x = sum(np.sin(2 * np.pi * f * tt) for f in (98, 104, 147))
    x = x * env(len(tt), 0.005, 0.7)
    x += lp_fast(noise(len(tt)), 900) * env(len(tt), 0.001, 0.15)
    return x


def bounce():
    """Restart whoosh: time rewinding."""
    d = 0.8
    tt = t(d)
    f = 900 * np.exp(-tt * 3) + 120
    ph = np.cumsum(2 * np.pi * f / SR)
    x = np.sin(ph) * 0.5 + highpass(noise(len(tt)), 1500) * 0.3 * (1 - tt / d)
    return x * np.clip(np.minimum(tt / 0.02, (d - tt) / 0.2), 0, 1)


# ------------------------------------------------------------------ ambience (seamless loops)
def loopable(x, fade=0.5):
    """Crossfade the tail into the head so the loop has no seam."""
    f = int(fade * SR)
    head = x[:f].copy()
    x = x[f:]
    ramp = np.linspace(0, 1, f)
    x[-f:] = x[-f:] * (1 - ramp) + head * ramp
    return x


def ambience(kind, d=24.0):
    tt = t(d + 0.5)
    n = len(tt)
    base = lp_fast(noise(n), 220) * 0.5
    if kind == "cell":
        base += 0.12 * np.sin(2 * np.pi * 60 * tt) + 0.05 * np.sin(2 * np.pi * 120 * tt)  # electrical hum
        for k in range(4):   # distant footsteps
            s = int(rng.uniform(2, d - 3) * SR)
            for j in range(5):
                st = footstep(0.5) * 0.25
                p = s + int(j * 0.55 * SR)
                if p + len(st) < n:
                    base[p:p + len(st)] += st
        for k in range(2):   # far-off door clank
            s = int(rng.uniform(3, d - 3) * SR)
            b = bang() * 0.12
            base[s:s + len(b)] += lp_fast(b, 500)[: max(0, min(len(b), n - s))]
    elif kind == "block":
        base += 0.08 * np.sin(2 * np.pi * 50 * tt)
        for k in range(6):
            s = int(rng.uniform(1, d - 2) * SR)
            b = lp_fast(bang(), 700) * 0.1
            base[s:s + len(b)] += b[: max(0, min(len(b), n - s))]
    elif kind == "security":
        base += 0.07 * np.sin(2 * np.pi * 120 * tt)
        for k in range(10):
            s = int(rng.uniform(0.5, d - 1) * SR)
            b = beep(rng.choice([900, 1200, 1600]), 0.07) * 0.12
            base[s:s + len(b)] += b[: max(0, min(len(b), n - s))]
    elif kind == "yard":
        wind = lp_fast(noise(n), 500) * (0.6 + 0.4 * np.sin(2 * np.pi * 0.07 * tt) * np.sin(2 * np.pi * 0.13 * tt))
        base = base * 0.4 + wind
        for k in range(14):  # crickets
            s = int(rng.uniform(0, d - 1) * SR)
            m = int(0.25 * SR)
            c = np.sin(2 * np.pi * 4200 * t(0.25)) * (np.sin(2 * np.pi * 30 * t(0.25)) > 0) * env(m, 0.01, 0.15) * 0.05
            base[s:s + m] += c[: max(0, min(m, n - s))]
    elif kind == "outside":
        wind = lp_fast(noise(n), 700) * (0.7 + 0.3 * np.sin(2 * np.pi * 0.05 * tt))
        base = base * 0.3 + wind * 0.8
        for k in range(10):
            s = int(rng.uniform(0, d - 1) * SR)
            m = int(0.4 * SR)
            f = rng.uniform(2200, 3400)
            c = np.sin(2 * np.pi * (f + 400 * np.sin(2 * np.pi * 9 * t(0.4))) * t(0.4)) * env(m, 0.02, 0.12) * 0.06
            base[s:s + m] += c[: max(0, min(m, n - s))]
    return loopable(base)


# ------------------------------------------------------------------ music (3 synced layers)
BPM = 84
BEAT = 60 / BPM
BARS = 8
LEN = BARS * 4 * BEAT
CHORDS = [(62, 65, 69), (58, 62, 65), (55, 58, 62), (57, 61, 64)]   # Dm  Bb  Gm  A


def mtof(m):
    return 440 * 2 ** ((m - 69) / 12)


def music_calm():
    tt = t(LEN)
    x = np.zeros(len(tt))
    bar = 4 * BEAT
    for b in range(BARS):
        ch = CHORDS[(b // 2) % 4]
        s, e = int(b * bar * SR), int((b + 1) * bar * SR)
        seg = tt[s:e] - tt[s]
        for m in ch:
            for det in (-0.08, 0.08):
                x[s:e] += saw(mtof(m - 12) * (1 + det / 100), seg) * 0.12
        x[s:e] += np.sin(2 * np.pi * mtof(ch[0] - 24) * seg) * 0.35
        fade = np.clip(np.minimum(seg / 0.6, (bar - seg) / 0.6), 0, 1)
        x[s:e] *= fade
    x = lp_fast(x, 700)
    # sparse bell melody
    mel = [74, None, 72, None, 69, None, 70, None, 69, None, 67, None, 65, None, 69, None]
    for i, m in enumerate(mel * (BARS // 4)):
        if m is None:
            continue
        s = int(i * 2 * BEAT * SR)
        n = int(2 * BEAT * SR)
        if s + n > len(x):
            break
        x[s:s + n] += np.sin(2 * np.pi * mtof(m) * ts(n)) * env(n, 0.01, 0.9) * 0.12
    return x


def music_tension():
    tt = t(LEN)
    x = np.zeros(len(tt))
    eighth = BEAT / 2
    for i in range(int(LEN / eighth)):
        b = int(i * eighth / (4 * BEAT))
        root = CHORDS[(b // 2) % 4][0] - 24
        s = int(i * eighth * SR)
        n = int(eighth * SR * 0.9)
        seg = ts(n)
        tone = (saw(mtof(root), seg) * 0.5 + np.sin(2 * np.pi * mtof(root) * seg))
        x[s:s + n] += lp_fast(tone, 500 + 300 * (i % 2)) * env(n, 0.003, 0.12) * 0.5
        h = highpass(noise(int(0.04 * SR)), 6000) * env(int(0.04 * SR), 0.001, 0.01) * (0.18 if i % 2 else 0.1)
        x[s:s + len(h)] += h
    return x


def music_chase():
    tt = t(LEN)
    x = np.zeros(len(tt))
    six = BEAT / 4
    for i in range(int(LEN / six)):
        s = int(i * six * SR)
        if i % 4 == 0:
            n = int(0.2 * SR)
            k = np.sin(2 * np.pi * (50 + 120 * np.exp(-t(0.2) * 30)) * t(0.2)) * env(n, 0.001, 0.08)
            x[s:s + n] += k * 0.9
        if i % 8 == 4:
            n = int(0.18 * SR)
            x[s:s + n] += (lp_fast(noise(n), 3500) * 0.6 + np.sin(2 * np.pi * 190 * t(0.18)) * 0.3) * env(n, 0.001, 0.06)
        b = int(i * six / (4 * BEAT))
        root = CHORDS[(b // 2) % 4][0] - 12
        if i % 2 == 0:
            n = int(six * 2 * SR * 0.8)
            m = root + (12 if i % 8 == 6 else 0)
            x[s:s + n] += lp_fast(saw(mtof(m), ts(n)), 1100) * env(n, 0.002, 0.08) * 0.35
        if i % 16 == 0:
            n = int(0.5 * SR)
            stab = sum(saw(mtof(mm), t(0.5)) for mm in (root + 12, root + 13, root + 19))
            x[s:s + n] += lp_fast(stab, 2000) * env(n, 0.002, 0.2) * 0.15
    return x


if __name__ == "__main__":
    sfx = {
        "step": footstep(0.8), "step2": footstep(0.9, tone=160), "step_run": footstep(1.4, 0.1, 210),
        "door_open": door_slide(True), "door_close": door_slide(False), "glass": glass(), "bang": bang(),
        "alarm": alarm(), "alert": alert(), "huh": huh(), "echo_spawn": echo_spawn(),
        "checkpoint": checkpoint(), "shard": shard(), "power_down": power(True), "power_up": power(False),
        "plate": plate(), "keycard": keycard(), "vent": vent(), "paper": paper(), "caught": caught(),
        "bounce": bounce(), "switch": beep(900, 0.06),
    }
    for k, v in sfx.items():
        save(f"{OUT}/sfx/{k}.wav", v, peak=0.8)
    for kind in ("cell", "block", "security", "yard", "outside"):
        save(f"{OUT}/ambient/amb_{kind}.wav", ambience(kind), peak=0.5)
        print("ambience", kind)
    save(f"{OUT}/music/layer_calm.wav", music_calm(), peak=0.6)
    save(f"{OUT}/music/layer_tension.wav", music_tension(), peak=0.55)
    save(f"{OUT}/music/layer_chase.wav", music_chase(), peak=0.7)
    print("done:", len(sfx), "sfx, 5 ambiences, 3 music layers")
