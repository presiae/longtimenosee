"""Top-down 3/4 props -> assets/sprites/td/<name>.png (horizontal frame strips)."""
import os
from PIL import Image
from td_common import Canvas, hexc, shade, save_preview, INK

OUT = "assets/sprites/td"
os.makedirs(OUT, exist_ok=True)
STEEL = [hexc(h) for h in ("#151a24", "#232b3a", "#313c50", "#425068", "#5a6c88", "#8a9cb8")]
WOOD = [hexc(h) for h in ("#2a1c14", "#3e2a1c", "#5a4030", "#7a5a3c")]
CLOTH = [hexc(h) for h in ("#2c3236", "#40484c", "#5c6466", "#7c8482")]
PORC = [hexc(h) for h in ("#4a5260", "#7a8494", "#a8b2c0", "#d0d8e0")]
WARM = [hexc(h) for h in ("#8a5a1c", "#e8c170", "#f5dfa0", "#fff8dc")]
RED = [hexc(h) for h in ("#5a1418", "#a02028", "#d0343c", "#ff6a6a")]
GREEN = [hexc(h) for h in ("#14401c", "#2a8a3a", "#5adc6a")]
CYAN = [hexc(h) for h in ("#123a4a", "#1b5c80", "#2aa8c9", "#5ff2ff", "#d8ffff")]
LEAF = [hexc(h) for h in ("#122016", "#1c3020", "#26402a", "#345636")]
sheets = {}


def strip(name, w, h, n, fn, outline=True):
    img = Image.new("RGBA", (w * n, h), (0, 0, 0, 0))
    for f in range(n):
        c = Canvas(img, f * w, 0, w, h)
        fn(c, f)
        if outline:
            c.outline()
    img.save(f"{OUT}/{name}.png")
    sheets[name] = img


def bed(c, f):
    c.box(2, 4, 21, 43, STEEL[2], STEEL[4], STEEL[1])
    c.rect(4, 6, 19, 41, CLOTH[2]); c.vline(4, 6, 41, CLOTH[3])
    c.rect(5, 7, 18, 13, PORC[3]); c.hline(5, 18, 7, hexc("#ffffff"))
    c.rect(4, 18, 19, 41, CLOTH[1]); c.hline(4, 19, 18, CLOTH[2])
    if f == 1:
        c.rect(8, 22, 15, 36, shade(CLOTH[1], 1.2)); c.rect(8, 9, 15, 13, hexc("#2b1d17"))
strip("bed", 24, 46, 2, bed)


def toilet(c, f):
    c.box(5, 2, 18, 8, PORC[2], PORC[3], PORC[0])
    c.disc(11, 15, 7, PORC[2]); c.disc(11, 15, 4, PORC[0]); c.disc(11, 15, 3, hexc("#3a5468"))
strip("toilet", 24, 24, 1, toilet)


def sink(c, f):
    c.box(2, 6, 21, 17, PORC[2], PORC[3], PORC[0]); c.rect(6, 9, 17, 14, PORC[0]); c.rect(10, 3, 12, 8, STEEL[4])
strip("sink", 24, 20, 1, sink)


def locker(c, f):
    c.rect(1, 0, 22, 9, hexc("#2a3632"))                      # top
    c.box(1, 8, 22, 43, hexc("#3a4a44"), hexc("#566a60"), hexc("#222c28"))
    c.vline(11, 8, 43, hexc("#222c28"))
    for y in (12, 14, 16):
        c.hline(3, 9, y, hexc("#222c28")); c.hline(13, 20, y, hexc("#222c28"))
    c.rect(8, 26, 9, 30, STEEL[4]); c.rect(14, 26, 15, 30, STEEL[4])
    if f == 1:
        c.hline(4, 5, 14, WARM[2]); c.hline(7, 8, 14, WARM[2])
strip("locker", 24, 46, 2, locker)


def desk(c, f):
    c.rect(0, 10, 47, 27, WOOD[2]); c.hline(0, 47, 10, WOOD[3]); c.rect(0, 28, 47, 33, WOOD[1])
    for i, x in enumerate((3, 18, 33)):
        c.box(x, 0, x + 11, 9, STEEL[2], STEEL[3], STEEL[0])
        col = hexc("#1a4a3a") if (i + f) % 2 else hexc("#24605a")
        c.rect(x + 1, 1, x + 10, 7, col); c.hline(x + 2, x + 7, 2 + (f + i) % 4, hexc("#6af0c0"))
    c.rect(20, 16, 28, 20, STEEL[1])
    c.rect(6, 15, 13, 21, hexc("#d8d0b8"))
strip("desk", 48, 34, 2, desk)


def crate(c, f):
    c.rect(1, 1, 26, 8, WOOD[3]); c.box(1, 7, 26, 27, WOOD[2], WOOD[3], WOOD[0])
    c.box(4, 10, 23, 24, WOOD[1], WOOD[2], WOOD[0])
    for i in range(14):
        c.put(5 + i, 11 + i, WOOD[3])
strip("crate", 28, 28, 1, crate)


def barrel(c, f):
    c.disc(10, 7, 8, hexc("#3a5a44")); c.disc(10, 7, 6, hexc("#2f4a3a"))
    c.rect(2, 7, 18, 24, hexc("#2f4a3a")); c.vline(2, 7, 24, hexc("#4a6a54")); c.vline(18, 7, 24, hexc("#1a2a20"))
    c.hline(2, 18, 12, STEEL[3]); c.hline(2, 18, 21, STEEL[3])
strip("barrel", 21, 26, 1, barrel)


def table(c, f):
    c.rect(0, 0, 39, 15, WOOD[2]); c.hline(0, 39, 0, WOOD[3]); c.rect(0, 16, 39, 19, WOOD[1])
    c.rect(6, 4, 13, 9, PORC[2]); c.rect(24, 5, 30, 10, hexc("#d8d0b8"))
strip("table", 40, 22, 1, table)


def bench(c, f):
    c.rect(0, 0, 39, 7, STEEL[3]); c.hline(0, 39, 0, STEEL[4]); c.rect(0, 8, 39, 10, STEEL[1])
    c.rect(2, 11, 4, 14, STEEL[1]); c.rect(35, 11, 37, 14, STEEL[1])
strip("bench", 40, 16, 1, bench)


def lever(c, f):
    c.box(4, 10, 19, 27, STEEL[2], STEEL[4], STEEL[0])
    c.rect(9, 14, 14, 17, STEEL[0])
    ang = -1 if f == 0 else 1
    for i in range(8):
        c.put(11 + ang * (i // 2), 15 - i, STEEL[5]); c.put(12 + ang * (i // 2), 15 - i, STEEL[3])
    hx = 11 + ang * 4
    c.rect(hx, 3, hx + 2, 6, RED[2] if f == 0 else GREEN[1])
    c.put(16, 23, RED[3] if f == 0 else GREEN[2])
strip("lever", 24, 30, 2, lever)


def panel(c, f):
    c.box(1, 1, 22, 27, STEEL[2], STEEL[4], STEEL[0])
    c.rect(4, 4, 19, 11, STEEL[0])
    for i, col in enumerate((GREEN, WARM, RED)):
        on = (f == 1) if i == 0 else (f == 0) if i == 2 else True
        c.rect(6 + i * 5, 6, 8 + i * 5, 8, col[2] if on else col[0])
    for i in range(3):
        c.rect(6 + i * 5, 14, 8 + i * 5, 23, STEEL[1])
        y = 14 if f else 19
        c.rect(6 + i * 5, y, 8 + i * 5, y + 3, STEEL[5])
strip("panel", 24, 30, 2, panel)


def plate(c, f):
    c.box(0, 0, 27, 27, STEEL[1], STEEL[2], STEEL[0])
    inset = 3 if f == 0 else 5
    c.box(inset, inset, 27 - inset, 27 - inset, STEEL[3] if f == 0 else STEEL[2], STEEL[5], STEEL[1])
    col = CYAN[3] if f else STEEL[4]
    c.hline(9, 18, 13, col); c.hline(9, 18, 14, col)
strip("plate", 28, 28, 2, plate)


def vent(c, f):
    c.box(0, 0, 27, 27, STEEL[2], STEEL[4], STEEL[0])
    c.rect(3, 3, 24, 24, hexc("#06080c"))
    if f == 0:
        for y in range(4, 24, 4):
            c.hline(3, 24, y, STEEL[3]); c.hline(3, 24, y + 1, STEEL[1])
strip("vent", 28, 28, 2, vent)


# --- doors: horizontal (in a horizontal wall, seen as a face) / vertical (seen from above)
def door_h(style):
    def fn(c, f):
        base = {"bars": STEEL[3], "steel": STEEL[2], "red": STEEL[2], "blue": STEEL[2], "yellow": STEEL[2]}[style]
        c.rect(0, 0, 31, 5, STEEL[1])
        if style == "bars":
            c.hline(0, 31, 6, STEEL[4]); c.hline(0, 31, 30, STEEL[4]); c.hline(0, 31, 18, STEEL[4])
            for x in range(1, 32, 4):
                c.vline(x, 6, 31, STEEL[4]); c.vline(x + 1, 6, 31, STEEL[2])
            c.rect(24, 16, 27, 20, STEEL[1]); c.put(25, 18, WARM[1])
        else:
            c.box(0, 6, 31, 31, base, STEEL[4], STEEL[0])
            c.box(3, 8, 28, 18, STEEL[3], STEEL[4], STEEL[1])
            c.rect(10, 10, 21, 12, STEEL[0])
            for y in range(21, 30, 3):
                c.hline(4, 27, y, STEEL[1])
            if style in ("red", "blue", "yellow"):
                col = {"red": RED[2], "blue": CYAN[2], "yellow": WARM[1]}[style]
                c.rect(1, 19, 30, 19, col)
                c.rect(26, 22, 29, 26, STEEL[0]); c.put(27, 24, col)
    return fn


for st in ("bars", "steel", "red", "blue", "yellow"):
    strip(f"door_h_{st}", 32, 32, 1, door_h(st), outline=False)


def door_v(style):
    def fn(c, f):
        col = {"bars": STEEL[4], "steel": STEEL[3], "red": RED[2], "blue": CYAN[2], "yellow": WARM[1]}[style]
        c.box(11, 0, 20, 31, STEEL[2], STEEL[4], STEEL[0])
        if style == "bars":
            for y in range(2, 31, 4):
                c.hline(12, 19, y, STEEL[5])
        else:
            c.rect(14, 2, 17, 29, STEEL[3]); c.rect(12, 14, 19, 17, col)
    return fn


for st in ("bars", "steel", "red", "blue", "yellow"):
    strip(f"door_v_{st}", 32, 32, 1, door_v(st), outline=False)


def gate(c, f):
    c.rect(0, 0, 95, 7, STEEL[1])
    c.box(0, 8, 95, 39, STEEL[2], STEEL[4], STEEL[0])
    for x in range(3, 94, 5):
        c.vline(x, 10, 37, STEEL[3]); c.vline(x + 1, 10, 37, STEEL[1])
    for x in range(0, 96, 6):
        c.rect(x, 22, x + 2, 24, WARM[1]); c.rect(x + 3, 22, x + 5, 24, INK)
    c.vline(47, 8, 39, STEEL[0]); c.vline(48, 8, 39, STEEL[4])
strip("gate", 96, 40, 1, gate, outline=False)


def lamp(c, f):  # ceiling light fixture seen from below/above
    c.box(2, 2, 21, 9, STEEL[3], STEEL[4], STEEL[1])
    c.rect(4, 4, 19, 7, WARM[3] if f == 0 else (hexc("#4a4a40") if f == 1 else hexc("#2a2a26")))
    if f == 2:
        c.put(6, 5, hexc("#8a8a7a")); c.put(13, 6, hexc("#8a8a7a"))
strip("lamp", 24, 12, 3, lamp)


def camera(c, f):
    c.rect(9, 0, 14, 5, STEEL[2])
    c.box(4, 5, 19, 14, PORC[1], PORC[2], PORC[0])
    c.rect(8, 14, 15, 17, STEEL[0])
    c.put(11, 16, RED[3] if f == 0 else hexc("#3a3a3a")); c.put(12, 16, RED[2] if f == 0 else hexc("#3a3a3a"))
strip("camera", 24, 20, 2, camera)


def tower(c, f):  # floodlight tower 48x96
    for leg in (8, 37):
        c.rect(leg, 40, leg + 2, 95, STEEL[2]); c.vline(leg, 40, 95, STEEL[3])
    for y in range(44, 94, 12):
        for i in range(29):
            c.put(10 + i, y + i * 10 // 29, STEEL[1]); c.put(38 - i, y + i * 10 // 29, STEEL[1])
    c.rect(2, 0, 45, 6, STEEL[2]); c.hline(2, 45, 0, STEEL[4])
    c.rect(5, 7, 42, 30, hexc("#1a1e2a")); c.rect(8, 10, 39, 22, hexc("#2a2410"))
    c.rect(10, 12, 37, 20, WARM[1] if f == 0 else hexc("#2a2a26"))
    c.box(1, 30, 46, 36, STEEL[3], STEEL[4], STEEL[1])
    for x in range(4, 46, 5):
        c.vline(x, 24, 30, STEEL[3])
    c.box(16, 36, 31, 42, STEEL[3], STEEL[4], STEEL[1])
    c.rect(19, 38, 28, 40, WARM[3] if f == 0 else hexc("#3a3a30"))
strip("tower", 48, 96, 2, tower)


def small(name, fn, w=12, h=12):
    strip(name, w, h, 1, fn)


small("bottle", lambda c, f: (c.rect(5, 0, 6, 2, hexc("#2a6a4a")), c.rect(3, 3, 8, 10, hexc("#2f7a54")), c.vline(3, 3, 10, hexc("#5ab884")), c.put(6, 5, hexc("#a8f0c8"))))
small("keycard", lambda c, f: (c.rect(1, 3, 10, 9, WARM[3]), c.rect(1, 3, 10, 4, hexc("#c0c8d0")), c.hline(2, 8, 7, PORC[1])))
small("note", lambda c, f: (c.rect(1, 1, 10, 10, hexc("#d8ccaa")), c.hline(3, 8, 3, hexc("#6a5a48")), c.hline(3, 8, 5, hexc("#6a5a48")), c.hline(3, 6, 7, hexc("#6a5a48"))))


def shard(c, f):
    pts = [(5, 0), (6, 0), (4, 1), (7, 1), (3, 2), (8, 2), (3, 3), (8, 3), (3, 4), (8, 4), (4, 5), (7, 5), (4, 6), (7, 6), (5, 7), (6, 7), (5, 8), (6, 8)]
    for p in pts:
        c.put(p[0], p[1] + 1, CYAN[3])
    c.rect(4, 3, 7, 6, CYAN[2]); c.rect(5, 2, 6, 7, CYAN[4])
strip("shard", 12, 12, 1, shard, outline=False)


def checkpoint(c, f):  # chalk circle with tallies on the floor
    col = hexc("#8a90a0") if f == 0 else CYAN[3]
    for y in range(28):
        for x in range(28):
            d = ((x - 13.5) ** 2 + (y - 13.5) ** 2) ** 0.5
            if 11.5 < d < 13:
                c.put(x, y, col)
    for k in range(4):
        c.vline(8 + k * 3, 9, 18, col)
    for i in range(14):
        c.put(7 + i, 17 - i * 2 // 3, col)
strip("checkpoint", 28, 28, 2, checkpoint, outline=False)


def tree(c, f):
    c.rect(21, 44, 26, 61, WOOD[1]); c.vline(21, 44, 61, WOOD[2])
    for (cx, cy, r, col) in ((24, 26, 20, LEAF[0]), (18, 22, 13, LEAF[1]), (30, 24, 12, LEAF[1]),
                             (24, 16, 12, LEAF[2]), (17, 15, 6, LEAF[3]), (28, 12, 6, LEAF[3])):
        c.disc(cx, cy, r, col)
strip("tree", 48, 64, 1, tree)


def bush(c, f):
    for (cx, cy, r, col) in ((12, 12, 10, LEAF[0]), (8, 9, 6, LEAF[1]), (16, 8, 6, LEAF[2]), (11, 6, 3, LEAF[3])):
        c.disc(cx, cy, r, col)
strip("bush", 24, 22, 1, bush)


def car(c, f):
    body = hexc("#2a3a5a")
    c.rect(2, 10, 61, 35, body); c.hline(2, 61, 10, shade(body, 1.4))
    c.rect(14, 2, 46, 12, shade(body, 0.8)); c.rect(16, 4, 44, 10, hexc("#1a2638"))
    c.rect(8, 22, 55, 24, shade(body, 0.7))
    for x in (8, 46):
        c.rect(x, 33, x + 9, 38, INK)
    c.rect(56, 14, 60, 17, WARM[2]); c.rect(2, 14, 5, 17, RED[2])
    c.rect(28, 0, 34, 2, RED[2] if f == 0 else CYAN[2])
strip("car", 64, 40, 2, car)


def sign(c, f):
    c.rect(14, 18, 17, 31, STEEL[2])
    c.box(0, 0, 31, 18, hexc("#1a3a24"), GREEN[1], hexc("#0a1a10"))
    c.rect(4, 6, 27, 11, GREEN[2])
strip("sign", 32, 32, 1, sign)


def generator(c, f):
    c.rect(0, 0, 39, 9, STEEL[3]); c.box(0, 9, 39, 29, STEEL[2], STEEL[4], STEEL[0])
    for x in range(4, 36, 4):
        c.vline(x, 12, 26, STEEL[1])
    c.rect(30, 2, 35, 6, WARM[1] if f == 0 else RED[2])
strip("generator", 40, 30, 2, generator)


def hoop(c, f):
    c.rect(14, 10, 17, 47, STEEL[3]); c.box(4, 0, 27, 12, PORC[3], hexc("#ffffff"), PORC[1])
    c.rect(11, 12, 20, 14, RED[2])
strip("hoop", 32, 48, 1, hoop)


def weights(c, f):
    c.rect(0, 8, 31, 10, STEEL[4]); c.rect(2, 2, 6, 16, INK); c.rect(25, 2, 29, 16, INK)
strip("weights", 32, 18, 1, weights)


def poster(c, f):
    c.rect(1, 1, 18, 22, hexc("#c8b890")); c.rect(3, 3, 16, 9, hexc("#8a3028")); [c.hline(3, 14, y, hexc("#5a5040")) for y in (12, 15, 18)]
strip("poster", 20, 24, 1, poster)

# contact sheet
x = y = rowh = 0
sheet = Image.new("RGBA", (520, 400), hexc("#222738"))
for n, im in sheets.items():
    if x + im.width > 520:
        x = 0; y += rowh + 4; rowh = 0
    sheet.alpha_composite(im, (x, y)); x += im.width + 4; rowh = max(rowh, im.height)
sheet = sheet.crop((0, 0, 520, y + rowh + 2))
save_preview(sheet, "tools/art/out/td_props_preview.png", 2)
print("wrote", len(sheets), "props")
