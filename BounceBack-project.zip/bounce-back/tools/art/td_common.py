"""Shared helpers + palette for the top-down art scripts."""
import random
from PIL import Image


def hexc(h, a=255):
    h = h.lstrip("#")
    return tuple(int(h[i:i + 2], 16) for i in (0, 2, 4)) + (a,)


def shade(c, k):
    """Multiply RGB by k (k<1 darker, >1 lighter)."""
    return tuple(max(0, min(255, int(v * k))) for v in c[:3]) + (c[3],)


INK = hexc("#0b0d17")


class Canvas:
    """Pixel canvas with an origin offset, so frames/tiles can share code."""

    def __init__(self, img, ox=0, oy=0, w=32, h=32):
        self.img, self.p = img, img.load()
        self.ox, self.oy, self.w, self.h = ox, oy, w, h

    def at(self, ox, oy, w=None, h=None):
        return Canvas(self.img, ox, oy, w or self.w, h or self.h)

    def put(self, x, y, c):
        if 0 <= x < self.w and 0 <= y < self.h:
            self.p[self.ox + x, self.oy + y] = c

    def get(self, x, y):
        return self.p[self.ox + x, self.oy + y]

    def rect(self, x0, y0, x1, y1, c):
        for y in range(y0, y1 + 1):
            for x in range(x0, x1 + 1):
                self.put(x, y, c)

    def hline(self, x0, x1, y, c):
        self.rect(x0, y, x1, y, c)

    def vline(self, x, y0, y1, c):
        self.rect(x, y0, x, y1, c)

    def box(self, x0, y0, x1, y1, fill, light, dark):
        self.rect(x0, y0, x1, y1, fill)
        self.hline(x0, x1, y0, light); self.vline(x0, y0, y1, light)
        self.hline(x0, x1, y1, dark); self.vline(x1, y0, y1, dark)

    def noise(self, cols, density, seed, x0=0, y0=0, x1=None, y1=None):
        r = random.Random(seed)
        for y in range(y0, (y1 if y1 is not None else self.h - 1) + 1):
            for x in range(x0, (x1 if x1 is not None else self.w - 1) + 1):
                if r.random() < density:
                    self.put(x, y, r.choice(cols))

    def disc(self, cx, cy, r, c):
        for y in range(-r, r + 1):
            for x in range(-r, r + 1):
                if x * x + y * y <= r * r + r:
                    self.put(cx + x, cy + y, c)

    def outline(self, col=INK):
        pts = []
        for y in range(self.h):
            for x in range(self.w):
                if self.get(x, y)[3] == 0:
                    for dx, dy in ((1, 0), (-1, 0), (0, 1), (0, -1)):
                        nx, ny = x + dx, y + dy
                        if 0 <= nx < self.w and 0 <= ny < self.h and self.get(nx, ny)[3] > 200 and self.get(nx, ny) != col:
                            pts.append((x, y)); break
        for x, y in pts:
            self.put(x, y, col)


def save_preview(img, path, scale=4, bg="#20242f"):
    big = img.resize((img.width * scale, img.height * scale), Image.NEAREST)
    out = Image.new("RGBA", big.size, hexc(bg))
    out.alpha_composite(big)
    out.save(path)
