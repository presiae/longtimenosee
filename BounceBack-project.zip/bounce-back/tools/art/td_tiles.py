"""Top-down 3/4 tileset, 32px cells, 8x8 atlas -> assets/tilesets/td_tiles.png

Atlas contract (mirrored in scripts/world/MapBuilder.gd):
  row 0  interior floors : concrete, concrete2, cell tile, corridor checker, metal grate, dark tile, wood, carpet
  row 1  exterior ground : grass, grass2, dirt, gravel path, asphalt, asphalt line, yard sand, puddle
  row 2  concrete wall   : top, face, face+pipes, face+barred window
  row 3  brick wall      : top, face, face+moss, face+notice
  row 4  perimeter stone : top, face, face+stain, face+razor
  row 5  chain fence     : face (see-through)
Walls: TOP is drawn where the cell below is also wall; FACE where the cell below is open,
which gives the 3/4 look.
"""
import os, random
from PIL import Image
from td_common import Canvas, hexc, shade, save_preview

T = 32
img = Image.new("RGBA", (T * 8, T * 8), (0, 0, 0, 0))
C = Canvas(img)


def tile(col, row):
    return C.at(col * T, row * T, T, T)


# ---------------------------------------------------------------- interior floors
conc = [hexc(h) for h in ("#2a2f3c", "#323848", "#3a4152", "#444c5f")]
for v in range(2):
    t = tile(v, 0)
    t.rect(0, 0, 31, 31, conc[1])
    t.noise([conc[0], conc[2]], 0.20, 3 + v)
    t.hline(0, 31, 31, conc[0]); t.vline(31, 0, 31, conc[0])
    if v == 1:
        for i, (x, y) in enumerate([(6, 9), (7, 10), (8, 10), (9, 11), (10, 13), (10, 14), (11, 15)]):
            t.put(x, y, conc[0])
t = tile(2, 0)  # cell tile: 4 squares
ct = [hexc(h) for h in ("#2c3236", "#363e42", "#40484c")]
t.rect(0, 0, 31, 31, ct[1])
for i in (0, 16):
    t.hline(0, 31, i, ct[0]); t.vline(i, 0, 31, ct[0])
    t.hline(0, 31, i + 1, ct[2]); t.vline(i + 1, 0, 31, ct[2])
t.noise([ct[0]], 0.05, 9)
t = tile(3, 0)  # corridor checker
a, b = hexc("#30364a"), hexc("#272c3c")
for y in range(32):
    for x in range(32):
        t.put(x, y, a if ((x // 16) + (y // 16)) % 2 == 0 else b)
t.noise([shade(a, 0.85)], 0.06, 11)
t = tile(4, 0)  # metal grate
m = [hexc(h) for h in ("#1c222e", "#2a3242", "#3a4558", "#56647e")]
t.rect(0, 0, 31, 31, m[1])
for y in range(2, 32, 4):
    t.hline(1, 30, y, m[0]); t.hline(1, 30, y + 1, m[2])
t.box(0, 0, 31, 31, m[1], m[3], m[0])
for p in ((2, 2), (29, 2), (2, 29), (29, 29)):
    t.put(*p, m[3])
t = tile(5, 0)  # dark tile
dt = [hexc(h) for h in ("#1a1e26", "#20252f", "#282e3a")]
t.rect(0, 0, 31, 31, dt[1])
for i in range(0, 32, 8):
    t.hline(0, 31, i, dt[0]); t.vline(i, 0, 31, dt[0])
t.noise([dt[2]], 0.05, 13)
t = tile(6, 0)  # wood planks (offices)
w = [hexc(h) for h in ("#2e2018", "#3e2c20", "#4c3828", "#5a4430")]
for y in range(32):
    plank = y // 8
    for x in range(32):
        t.put(x, y, w[1 + (plank % 2)])
    if y % 8 == 0:
        t.hline(0, 31, y, w[0])
for plank in range(4):
    off = (plank * 13) % 32
    t.vline(off, plank * 8, plank * 8 + 7, w[0])
t.noise([w[3]], 0.04, 15)
t = tile(7, 0)  # worn carpet
cp = [hexc(h) for h in ("#3a1e22", "#4a262a", "#5a3034")]
t.rect(0, 0, 31, 31, cp[1]); t.noise([cp[0], cp[2]], 0.3, 17)

# ---------------------------------------------------------------- exterior
gr = [hexc(h) for h in ("#1c2a1c", "#243424", "#2e422c", "#3a5236")]
for v in range(2):
    t = tile(v, 1)
    t.rect(0, 0, 31, 31, gr[1])
    t.noise([gr[0], gr[2]], 0.35, 21 + v)
    r = random.Random(30 + v)
    for _ in range(10 if v else 6):
        x, y = r.randrange(32), r.randrange(30)
        t.put(x, y, gr[3]); t.put(x, y + 1, gr[2])
dirt = [hexc(h) for h in ("#2a221a", "#342a20", "#3e3226")]
t = tile(2, 1); t.rect(0, 0, 31, 31, dirt[1]); t.noise([dirt[0], dirt[2]], 0.3, 25)
gv = [hexc(h) for h in ("#2e3036", "#3a3c42", "#484a50")]
t = tile(3, 1); t.rect(0, 0, 31, 31, gv[1]); t.noise([gv[0], gv[2]], 0.45, 27)
asp = [hexc(h) for h in ("#1c1e24", "#22252c", "#2a2e36")]
for v in range(2):
    t = tile(4 + v, 1); t.rect(0, 0, 31, 31, asp[1]); t.noise([asp[0], asp[2]], 0.25, 29 + v)
    if v:
        t.rect(14, 4, 17, 27, hexc("#8a7a3c"))
sand = [hexc(h) for h in ("#33302a", "#3c3830", "#46423a")]
t = tile(6, 1); t.rect(0, 0, 31, 31, sand[1]); t.noise([sand[0], sand[2]], 0.3, 33)
t = tile(7, 1); t.rect(0, 0, 31, 31, dirt[1]); t.noise([dirt[0]], 0.3, 35)
for y in range(8, 24):
    for x in range(6, 26):
        if ((x - 16) / 10) ** 2 + ((y - 16) / 8) ** 2 < 1:
            t.put(x, y, hexc("#1e2a34"))
t.hline(10, 18, 12, hexc("#3a5468"))


# ---------------------------------------------------------------- walls
def wall_set(row, top_cols, face_cols, kind):
    tp = tile(0, row)
    tp.rect(0, 0, 31, 31, top_cols[1])
    tp.noise([top_cols[0], top_cols[2]], 0.12, 40 + row)
    for v in range(1, 4):
        f = tile(v, row)
        # 6px lip of the wall top, then the face below it
        f.rect(0, 0, 31, 5, top_cols[1]); f.noise([top_cols[0], top_cols[2]], 0.12, 50 + row, 0, 0, 31, 5)
        f.hline(0, 31, 5, top_cols[2])
        if kind == "concrete":
            f.rect(0, 6, 31, 31, face_cols[1])
            f.noise([face_cols[0], face_cols[2]], 0.15, 60 + v)
            f.hline(0, 31, 18, face_cols[0])
            f.vline(15, 6, 31, face_cols[0])
        elif kind == "brick":
            f.rect(0, 6, 31, 31, face_cols[0])
            for rr in range(6):
                y0 = 6 + rr * 4 + 1
                off = 0 if rr % 2 == 0 else 5
                for bx in range(-1, 4):
                    x0 = bx * 10 + off
                    cc = face_cols[1] if (bx + rr + v) % 3 else face_cols[2]
                    for yy in range(y0, min(y0 + 3, 32)):
                        for xx in range(max(x0, 0), min(x0 + 9, 32)):
                            f.put(xx, yy, cc)
        else:  # stone
            f.rect(0, 6, 31, 31, face_cols[1])
            for y0 in (6, 19):
                f.hline(0, 31, y0, face_cols[0])
            for x0 in (0, 16):
                f.vline(x0 + (8 if True else 0), 7, 18, face_cols[0])
            f.vline(0, 20, 31, face_cols[0]); f.vline(16, 20, 31, face_cols[0])
            f.noise([face_cols[2], face_cols[0]], 0.1, 70 + v)
        f.hline(0, 31, 31, shade(face_cols[0], 0.7))   # ground contact shadow
        f.hline(0, 31, 30, shade(face_cols[0], 0.85))
        if v == 2 and kind == "concrete":   # pipes
            for y, c in ((10, "#56647e"), (11, "#3a4558"), (12, "#2a3242")):
                f.hline(0, 31, y, hexc(c))
        if v == 3 and kind == "concrete":   # barred window
            f.rect(9, 9, 22, 20, hexc("#121824")); f.rect(10, 10, 21, 13, hexc("#26364c"))
            for x in (12, 15, 18, 21):
                f.vline(x, 9, 20, hexc("#56647e"))
        if v == 2 and kind == "brick":
            f.noise([hexc("#2c3e2c"), hexc("#384a34")], 0.10, 77)
        if v == 3 and kind == "brick":
            f.rect(10, 10, 21, 22, hexc("#c8b890")); f.rect(11, 11, 20, 14, hexc("#8a3028"))
            for y in (16, 18, 20):
                f.hline(12, 19, y, hexc("#5a5040"))
        if v == 3 and kind == "stone":
            for x in range(0, 32, 4):
                f.put(x, 1, hexc("#8a9cb8")); f.put(x + 1, 0, hexc("#8a9cb8")); f.put(x + 2, 2, hexc("#5a6c88"))
        if v == 2 and kind == "stone":
            f.noise([hexc("#1e2420")], 0.2, 79, 4, 20, 14, 31)


wall_set(2, [hexc(h) for h in ("#14171f", "#1a1e28", "#222734")],
         [hexc(h) for h in ("#2c3242", "#394052", "#465068")], "concrete")
wall_set(3, [hexc(h) for h in ("#161214", "#1c171a", "#241e22")],
         [hexc(h) for h in ("#2a1c1e", "#4a2f30", "#5c3b37")], "brick")
wall_set(4, [hexc(h) for h in ("#121418", "#191c22", "#20242c")],
         [hexc(h) for h in ("#22262e", "#363c48", "#444b58")], "stone")
# chain fence (face only, mostly transparent)
f = tile(0, 5)
for y in range(4, 31):
    for x in range(32):
        if (x + y) % 6 == 0 or (x - y) % 6 == 0:
            f.put(x, y, hexc("#7a8496", 220))
for x in (0, 31):
    f.vline(x, 0, 31, hexc("#5a6478"))
f.hline(0, 31, 4, hexc("#8a94a8"))
for x in range(0, 32, 3):
    f.put(x, 1, hexc("#aab4c4")); f.put(x + 1, 2, hexc("#8a94a8"))

os.makedirs("assets/tilesets", exist_ok=True)
img.save("assets/tilesets/td_tiles.png")
os.makedirs("tools/art/out", exist_ok=True)
save_preview(img, "tools/art/out/td_tiles_preview.png", 3)
print("wrote td_tiles", img.size)
