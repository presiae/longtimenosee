"""Top-down 3/4 character sheets: 32x32 frames, rows = <anim>_<dir>, dir in down/up/side.
Side frames face RIGHT; the engine flips them for left.
Outputs assets/sprites/td_<name>.png + .json  {"cell":[32,32], "anims": {name: {row,frames,fps,loop}}}
"""
import json, os
from PIL import Image
from td_common import Canvas, hexc, shade, save_preview, INK

W = H = 32
PRIS = dict(skin=hexc("#d9a07a"), skin_d=hexc("#a8694d"), hair=hexc("#2b1d17"), hair_l=hexc("#4a3226"),
            suit=hexc("#d0682c"), suit_l=hexc("#ee9447"), suit_d=hexc("#8f3a1d"), shoe=hexc("#1d1a22"),
            patch=hexc("#e9dcc0"), guard=False)
GUARD = dict(skin=hexc("#c9906c"), skin_d=hexc("#91593f"), hair=hexc("#1c1c24"), hair_l=hexc("#1c1c24"),
             suit=hexc("#33456b"), suit_l=hexc("#4a6190"), suit_d=hexc("#222e4a"), shoe=hexc("#121218"),
             patch=hexc("#e8c170"), cap=hexc("#1e2740"), cap_l=hexc("#2f3c5e"), belt=hexc("#121218"),
             torch=hexc("#8a92a4"), lens=hexc("#fff4c8"), guard=True)

LEG_CYCLE = [(0, 2), (0, 0), (2, 0), (0, 0)]   # (left lift, right lift) per walk frame
ARM_CYCLE = [1, 0, -1, 0]


def draw(c, P, d, ph=0, mode="walk", moving=True):
    g = P["guard"]
    low = 3 if mode == "sneak" else 0
    bob = 1 if (moving and ph in (1, 3)) else 0
    top = 6 + low + bob
    ll, rl = LEG_CYCLE[ph] if moving else (0, 0)
    arm = ARM_CYCLE[ph] if moving else 0
    feet = 30
    if d in ("down", "up"):
        # legs
        for (x0, lift) in ((12, ll), (17, rl)):
            y1 = feet - lift
            c.rect(x0, top + 18, x0 + 2, y1 - 2, P["suit_d"])
            c.rect(x0, y1 - 1, x0 + 2, y1, P["shoe"])
        # torso
        c.rect(10, top + 10, 21, top + 18, P["suit"])
        c.vline(10, top + 10, top + 18, P["suit_l"]); c.vline(21, top + 10, top + 18, P["suit_d"])
        c.hline(10, 21, top + 18, P["suit_d"])
        if g:
            c.hline(10, 21, top + 17, P["belt"]); c.put(15, top + 17, hexc("#c9a44a"))
            if d == "down":
                c.put(18, top + 12, P["patch"])
        else:
            if d == "down":
                c.put(15, top + 10, P["skin"]); c.put(16, top + 10, P["skin"]); c.put(15, top + 11, P["skin_d"])
                c.rect(17, top + 13, 19, top + 14, P["patch"])
            else:
                c.rect(13, top + 12, 18, top + 15, P["patch"]); c.rect(14, top + 13, 17, top + 14, P["suit_d"])
        # arms
        if mode == "caught":
            for x0 in (8, 22):
                c.rect(x0, top + 1, x0 + 1, top + 11, P["suit_l"]); c.rect(x0, top - 1, x0 + 1, top, P["skin"])
        else:
            for x0, s in ((8, arm), (22, -arm)):
                c.rect(x0, top + 11 + s, x0 + 1, top + 16 + s, P["suit_l"] if x0 == 8 else P["suit"])
                c.rect(x0, top + 17 + s, x0 + 1, top + 17 + s, P["skin"])
            if g and d == "down" and mode != "catch":
                c.rect(22, top + 16 - arm, 23, top + 20 - arm, P["torch"]); c.put(22, top + 20 - arm, P["lens"]); c.put(23, top + 20 - arm, P["lens"])
            if mode in ("interact", "catch"):
                c.rect(13, top + 15, 18, top + 17, P["skin"])
        # head
        c.rect(10, top, 21, top + 9, P["skin"])
        c.hline(10, 21, top + 9, P["skin_d"])
        if g:
            c.rect(9, top - 1, 22, top + 2, P["cap"]); c.hline(10, 21, top - 1, P["cap_l"])
            if d == "down":
                c.rect(9, top + 3, 22, top + 3, P["cap"])
            else:
                c.rect(10, top + 3, 21, top + 7, P["hair"])
        else:
            c.rect(10, top - 1, 21, top + 2, P["hair"]); c.hline(12, 19, top - 1, P["hair_l"])
            if d == "up":
                c.rect(10, top + 3, 21, top + 8, P["hair"]); c.hline(11, 20, top + 4, P["hair_l"])
            else:
                c.put(10, top + 3, P["hair"]); c.put(21, top + 3, P["hair"])
        if d == "down":
            eye = INK
            look = 0 if mode != "search" else (-1 if ph < 2 else 1)
            c.rect(12 + look, top + 5, 13 + look, top + 6, eye); c.rect(18 + look, top + 5, 19 + look, top + 6, eye)
            c.hline(14, 17, top + 8, P["skin_d"])
            c.put(10, top + 5, P["skin_d"]); c.put(21, top + 5, P["skin_d"])
    else:  # side, facing right
        # back leg then front leg
        for x0, lift, col in ((13, ll, P["suit_d"]), (16, rl, P["suit"])):
            step = (2 if lift else -1) if moving else 0
            y1 = feet - (1 if lift else 0)
            c.rect(x0 + step, top + 18, x0 + 2 + step, y1 - 2, col)
            c.rect(x0 + step, y1 - 1, x0 + 3 + step, y1, P["shoe"])
        c.rect(12, top + 10, 20, top + 18, P["suit"])
        c.vline(12, top + 10, top + 18, P["suit_l"]); c.hline(12, 20, top + 18, P["suit_d"])
        if g:
            c.hline(12, 20, top + 17, P["belt"])
        # arm
        if mode == "caught":
            c.rect(15, top + 1, 16, top + 11, P["suit_l"]); c.rect(15, top - 1, 16, top, P["skin"])
        elif mode in ("interact", "catch"):
            c.rect(16, top + 12, 24, top + 13, P["suit_l"]); c.rect(25, top + 12, 26, top + 13, P["skin"])
        else:
            c.rect(15 + arm, top + 11, 16 + arm, top + 16, P["suit_l"]); c.rect(15 + arm, top + 17, 16 + arm, top + 17, P["skin"])
            if g:
                c.rect(17 + arm, top + 15, 21 + arm, top + 16, P["torch"]); c.put(22 + arm, top + 15, P["lens"]); c.put(22 + arm, top + 16, P["lens"])
        # head
        c.rect(11, top, 21, top + 9, P["skin"])
        c.hline(11, 21, top + 9, P["skin_d"])
        c.put(22, top + 5, P["skin"])  # nose
        if g:
            c.rect(10, top - 1, 21, top + 2, P["cap"]); c.hline(11, 20, top - 1, P["cap_l"])
            c.rect(19, top + 3, 24, top + 3, P["cap"])
            c.rect(10, top + 3, 13, top + 6, P["hair"])
        else:
            c.rect(10, top - 1, 21, top + 2, P["hair"]); c.hline(12, 19, top - 1, P["hair_l"])
            c.rect(10, top + 3, 14, top + 7, P["hair"])
        c.rect(18, top + 4, 19, top + 5, INK)
        c.put(15, top + 5, P["skin_d"])


def anims_for(P):
    g = P["guard"]
    spec = [("idle", 2, 3, True, "walk", False), ("walk", 4, 8, True, "walk", True),
            ("run", 4, 12, True, "walk", True)]
    if g:
        spec += [("search", 4, 4, True, "search", False), ("catch", 2, 6, False, "catch", False)]
    else:
        spec += [("sneak", 4, 7, True, "sneak", True), ("sneakidle", 1, 1, True, "sneak", False),
                 ("interact", 2, 8, False, "interact", False), ("caught", 2, 4, True, "caught", False)]
    return spec


def build(name, P):
    spec = anims_for(P)
    dirs = ("down", "up", "side")
    rows = len(spec) * len(dirs)
    cols = max(s[1] for s in spec)
    sheet = Image.new("RGBA", (W * cols, H * rows), (0, 0, 0, 0))
    meta = {"cell": [W, H], "anims": {}}
    row = 0
    for (an, n, fps, loop, mode, moving) in spec:
        for d in dirs:
            for f in range(n):
                c = Canvas(sheet, f * W, row * H, W, H)
                ph = f % 4 if moving else (f % 2) * 2 if mode == "walk" and n == 2 else f
                if mode == "walk" and not moving:   # idle breathing
                    draw(c, P, d, 0, "walk", False)
                    if f == 1:
                        # shift the upper body down one pixel for a breath
                        tmp = sheet.crop((f * W, row * H, f * W + W, row * H + 22))
                        blank = Image.new("RGBA", (W, 22), (0, 0, 0, 0))
                        sheet.paste(blank, (f * W, row * H))
                        sheet.paste(tmp.crop((0, 0, W, 21)), (f * W, row * H + 1), tmp.crop((0, 0, W, 21)))
                else:
                    draw(c, P, d, ph % 4, mode, moving)
                c.outline()
            meta["anims"][f"{an}_{d}"] = {"row": row, "frames": n, "fps": fps, "loop": loop}
            row += 1
    sheet.save(f"assets/sprites/td_{name}.png")
    with open(f"assets/sprites/td_{name}.json", "w", newline="\n") as fh:
        json.dump(meta, fh, indent=1)
    save_preview(sheet, f"tools/art/out/td_{name}_preview.png", 4)
    print("wrote", name, sheet.size)


def build_echo():
    """Ghost-tinted prisoner (cyan) so echoes read instantly even without shaders."""
    src = Image.open("assets/sprites/td_prisoner.png").convert("RGBA")
    px = src.load()
    for y in range(src.height):
        for x in range(src.width):
            r, g, b, a = px[x, y]
            if a:
                l = (r * 0.3 + g * 0.5 + b * 0.2) / 255
                px[x, y] = (int(40 + 120 * l), int(150 + 105 * l), int(190 + 65 * l), a)
    src.save("assets/sprites/td_echo.png")
    with open("assets/sprites/td_prisoner.json") as f:
        meta = f.read()
    with open("assets/sprites/td_echo.json", "w", newline="\n") as f:
        f.write(meta)


if __name__ == "__main__":
    os.makedirs("assets/sprites", exist_ok=True)
    build("prisoner", PRIS)
    build("guard", GUARD)
    build_echo()
