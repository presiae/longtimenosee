#!/usr/bin/env bash
# Runs the headless test suite and fails on ANY engine/script error, not just failed checks.
# Usage: tools/run_tests.sh [name-filter]      (GODOT env var overrides the binary path)
cd "$(dirname "$0")/.."
GODOT="${GODOT:-../tools/Godot_v4.7.2-stable_win64_console.exe}"
BB_TEST="$1" timeout 600 "$GODOT" --headless res://tests/TestRunner.tscn > tests/last_run.log 2>&1
code=$?
grep -E "PASS|FAIL|RESULT" tests/last_run.log
errors=$(grep -E "SCRIPT ERROR|^ERROR|Parse Error" tests/last_run.log | grep -vc "resources still in use at exit")
if [ "$errors" -gt 0 ]; then
  echo "---- $errors engine errors ----"
  grep -E -A2 "SCRIPT ERROR|^ERROR|Parse Error" tests/last_run.log | head -40
  exit 1
fi
exit $code
