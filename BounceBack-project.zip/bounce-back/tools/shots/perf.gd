extends Node
## Perf probe: at heavy spots, average frame time with all 2D lights on vs. off.
## Run windowed:  BB_SHOT_SCRIPT=res://tools/shots/perf.gd BB_SHOT=x BB_SHOT_FRAMES=999999 godot res://scenes/Game.tscn

const SPOTS := [Vector2i(5, 6), Vector2i(31, 11), Vector2i(24, 27), Vector2i(62, 20)]


func _measure(tree: SceneTree, secs: float) -> float:
	for i in 20:
		await tree.process_frame
	var t0 := Time.get_ticks_usec()
	var frames := 0
	while Time.get_ticks_usec() - t0 < int(secs * 1000000):
		await tree.process_frame
		frames += 1
	return (Time.get_ticks_usec() - t0) / 1000.0 / frames


func _lights(node: Node, on: bool) -> void:
	for c in node.get_children():
		if c is PointLight2D:
			c.visible = on
		_lights(c, on)


func run(tree: SceneTree) -> void:
	for i in 10:
		await tree.process_frame
	var game := tree.current_scene
	game.world.player.controls_enabled = false
	for c in SPOTS:
		game.world.player.global_position = MapBuilder.cell_feet(c)
		game.world.camera.reset_smoothing()
		_lights(game.world, true)
		var on := await _measure(tree, 2.5)
		_lights(game.world, false)
		var off := await _measure(tree, 2.5)
		_lights(game.world, true)
		print("PERF %s: lights on %.1f ms (%.0f fps) | lights off %.1f ms (%.0f fps)" % [c, on, 1000.0 / on, off, 1000.0 / off])
	tree.quit()
