extends Node
## Screenshot stager. BB_SHOT_CELL="x,y" teleports the player to a map cell;
## BB_SHOT_FACING="x,y" sets facing; BB_SHOT_NOLIGHT=1 turns the darkness off.


func run(tree: SceneTree) -> void:
	for i in 4:
		await tree.process_frame
	var game := tree.current_scene
	var w: World = game.get("world")
	if w == null:
		return
	var cell := OS.get_environment("BB_SHOT_CELL")
	if cell != "":
		var c := cell.split(",")
		w.player.global_position = MapBuilder.cell_feet(Vector2i(int(c[0]), int(c[1])))
		w.camera.reset_smoothing()
	var f := OS.get_environment("BB_SHOT_FACING")
	if f != "":
		var v := f.split(",")
		w.player.facing = Vector2(float(v[0]), float(v[1]))
	if OS.get_environment("BB_SHOT_NOLIGHT") == "1":
		w.canvas_mod.visible = false
	w.player.controls_enabled = false
