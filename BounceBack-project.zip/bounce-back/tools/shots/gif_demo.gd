extends Node
## Staging for the README GIF: first attempt rattles the bars, bounce back, then the Echo
## distracts the guard while the prisoner crawls out through the vent.


func _go(game: Node, cell: Vector2i, frames: int, sneak := false) -> void:
	var target := MapBuilder.cell_feet(cell)
	for i in frames:
		var p: PlayerController = game.world.player
		var to := target - p.global_position
		p.bot_input = {"move": to.normalized() if to.length() > 4.0 else Vector2.ZERO, "sneak": sneak}
		await get_tree().physics_frame


func run(tree: SceneTree) -> void:
	for i in 3:
		await tree.process_frame
	var game := tree.current_scene
	await _go(game, Vector2i(6, 7), 45)
	game.world.player.try_interact()
	await _go(game, Vector2i(6, 7), 25)
	game.restart_attempt("restart")
	await tree.physics_frame
	await _go(game, Vector2i(8, 5), 95)
	game.world.player.try_interact()
	for c in [Vector2i(10, 5), Vector2i(16, 5), Vector2i(16, 9), Vector2i(19, 10), Vector2i(22, 10)]:
		await _go(game, c, 140)
