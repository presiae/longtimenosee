extends Node
## Screenshot stager: record a bars-rattling attempt, bounce back, and let the Echo
## distract the post guard while the player heads for the vent.


func _go(game: Node, cell: Vector2i, frames: int) -> void:
	var target := MapBuilder.cell_feet(cell)
	for i in frames:
		var p: PlayerController = game.world.player
		var to := target - p.global_position
		p.bot_input = {"move": to.normalized() if to.length() > 4.0 else Vector2.ZERO}
		await get_tree().physics_frame


func run(tree: SceneTree) -> void:
	for i in 3:
		await tree.process_frame
	var game := tree.current_scene
	await _go(game, Vector2i(6, 7), 50)
	game.world.player.try_interact()
	await _go(game, Vector2i(6, 7), 30)
	game.restart_attempt("restart")
	await tree.physics_frame
	await _go(game, Vector2i(8, 5), 60)
	game.world.player.try_interact()
	await _go(game, Vector2i(8, 5), 40)
