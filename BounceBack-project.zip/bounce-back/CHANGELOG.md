# Changelog

All notable changes to BOUNCE BACK. Versions are tagged in git (`git checkout v0.1` etc.).

## [0.1.0] — Initial Prototype
### Added
- Godot 4.7 project (480×270 pixel-perfect viewport, integer scaling, GL Compatibility renderer).
- `PlayerController`: acceleration/deceleration, run, crouch-crawl with low-ceiling check,
  variable jump height, coyote time, jump buffering, heavier fall gravity.
- `LevelBuilder`: ASCII level files in `data/levels/*.json` → `TileMapLayer` terrain with
  one-way platforms and entity anchors.
- `CameraRig`: smoothed follow, velocity look-ahead, trauma-based screen shake.
- Input map registered in code (`InputSetup`), keyboard + gamepad.
- Headless test runner (`tests/TestRunner.tscn`) with movement tests.
- `ScreenshotTool` for capturing real screenshots from the running game.
